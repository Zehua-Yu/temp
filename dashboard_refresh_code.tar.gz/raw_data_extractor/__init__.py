"""
raw_data_extractor

重构后的原始数据提取/分析包：
- rde_cli: 命令行入口
- rde_io: 解析与读取
- rde_analysis: 分析算法
- rde_utils: 通用工具
- rde_reporting: 报告输出
"""

