"""
rde_utils/config_utils.py

集中管理 raw_data_extractor 的配置加载逻辑。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


def _load_extractor_config() -> Dict[str, Any]:
    """
    读取固定配置文件（找不到则使用默认值）。
    配置文件路径：与调用方脚本同目录 `raw_extractor_config.json`
    """
    cfg_path = Path(__file__).resolve().parent.parent / "raw_extractor_config.json"
    default_cfg: Dict[str, Any] = {
        "mz": {"tol_ppm": 1.0, "tol_da": 0.0},
        "rt": {"tolerance_min": 1.0, "dad_merge_tol_min": 0.05},
        "blank_interference": {"top_n_spectrum": 10, "max_interference_peaks": 5, "cumulative_threshold": 0.9},
        "sample": {"top_k": 5, "area_merge_mode": "max"},
        "ms1": {"topn": 10, "keep": 5},
        "background_ions": {
            "enable": True,
            "scan_step": 10,
            "topk_per_scan": 200,
            "presence_threshold": 0.8,
            "edge_coverage_ratio": 0.05,
            "filter_min_duration_ratio": 0.5,
            "filter_min_avg_intensity": 15000.0,
            "filter_max_peak_ratio": 100.0,
        },
        "ms2": {"rt_tol_min": 0.3, "precursors_per_rt": 1, "frag_topn": 5},
        "adducts": {"enable": True, "max_candidates": 5, "ppm_tol": 10.0},
    }
    if not cfg_path.exists():
        return default_cfg

    def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        out: Dict[str, Any] = {k: v for k, v in base.items()}
        for k, v in (override or {}).items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = deep_merge(out[k], v)  # type: ignore[arg-type]
            else:
                out[k] = v
        return out

    try:
        obj = json.loads(cfg_path.read_text(encoding="utf-8"))
        if not isinstance(obj, dict):
            return default_cfg
        return deep_merge(default_cfg, obj)
    except Exception:
        return default_cfg


# 给未来的更规范命名做准备（不破坏现有调用）
load_extractor_config = _load_extractor_config
