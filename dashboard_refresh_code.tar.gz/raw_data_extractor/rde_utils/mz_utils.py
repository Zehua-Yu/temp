"""
rde_utils/mz_utils.py

统一 m/z 匹配与误差计算（ppm / 可选Da兜底）。

约定：
- ppm = (obs - ref) / ref * 1e6
- ppm 匹配：abs(obs-ref) <= ref * ppm_tol * 1e-6
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple


def mz_error_ppm(*, obs_mz: float, ref_mz: float) -> Optional[float]:
    """
    返回 ppm 误差；ref_mz<=0 或无效时返回 None。
    """
    try:
        o = float(obs_mz)
        r = float(ref_mz)
    except Exception:
        return None
    if r <= 0:
        return None
    return (o - r) / r * 1e6


def mz_match_ppm(*, obs_mz: float, ref_mz: float, ppm_tol: float) -> bool:
    """
    仅用 ppm 容差判断是否命中。
    """
    try:
        o = float(obs_mz)
        r = float(ref_mz)
        tol = float(ppm_tol)
    except Exception:
        return False
    if not (r > 0 and tol >= 0):
        return False
    return abs(o - r) <= r * tol * 1e-6


def mz_match(
    *,
    obs_mz: float,
    ref_mz: float,
    ppm_tol: float,
    da_tol: float = 0.0,
) -> Tuple[bool, Optional[float], str]:
    """
    统一匹配入口：
    - 先 ppm；若未命中且 da_tol>0，再用绝对Da兜底

    返回：(hit, ppm_error, hit_mode)
    - hit_mode: "ppm" | "da" | ""
    """
    ppm_err = mz_error_ppm(obs_mz=obs_mz, ref_mz=ref_mz)
    if mz_match_ppm(obs_mz=obs_mz, ref_mz=ref_mz, ppm_tol=ppm_tol):
        return True, ppm_err, "ppm"

    try:
        da = abs(float(obs_mz) - float(ref_mz))
        da_tol2 = float(da_tol)
    except Exception:
        return False, ppm_err, ""
    if da_tol2 > 0 and da <= da_tol2:
        return True, ppm_err, "da"
    return False, ppm_err, ""


@dataclass(frozen=True)
class MzMatchDetail:
    obs_mz: float
    ref_mz: float
    hit: bool
    ppm_error: Optional[float]
    hit_mode: str  # "ppm" | "da" | ""

