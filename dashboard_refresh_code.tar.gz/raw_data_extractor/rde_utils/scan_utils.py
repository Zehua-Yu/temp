"""
rde_utils/scan_utils.py

集中管理 scan 选择与索引构建逻辑，避免脚本间重复实现。
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from typing import TYPE_CHECKING, List, Optional, Tuple

import numpy as np

from ..rde_io.agilent_d_reader import ScanRecord

if TYPE_CHECKING:
    from ..rde_io.agilent_d_reader import AgilentDReader


@dataclass(frozen=True)
class MS1ScanIndex:
    """
    MS1 scan 的 RT 索引（用于加速“窗口内找最佳 scan”）。

    关键点：为保证与线性扫描的结果一致，保留“原始顺序”作为稳定的平局裁决。
    """

    rts_sorted: np.ndarray  # 按 rt_min 升序；同 rt 时按 order 升序
    order_sorted: np.ndarray  # 对应原始顺序（越小越靠前）
    scans_sorted: List[ScanRecord]


def build_ms1_scan_index(ms1_scans: List[ScanRecord]) -> MS1ScanIndex:
    if not ms1_scans:
        return MS1ScanIndex(rts_sorted=np.array([], dtype=float), order_sorted=np.array([], dtype=int), scans_sorted=[])
    rts = np.array([float(s.rt_min) for s in ms1_scans], dtype=float)
    order = np.arange(len(ms1_scans), dtype=int)
    idx = np.lexsort((order, rts))  # sort by (rt, order)
    scans_sorted = [ms1_scans[int(i)] for i in idx.tolist()]
    return MS1ScanIndex(rts_sorted=rts[idx], order_sorted=order[idx], scans_sorted=scans_sorted)


def pick_best_ms1_scan(
    ms1_scans: List[ScanRecord],
    *,
    rt_start: float,
    rt_end: float,
    rt_apex: float,
    max_rt_distance: float = 0.04,
) -> Optional[ScanRecord]:
    """
    线性版本：优先在 [apex, apex+max_rt_distance] 窄窗口内选 base_peak_value 最大的 scan；
    窄窗口无命中则在原始窗口内选距 apex 最近的；仍无则全局选距 apex 最近的。
    """
    # 第一优先：窄窗口
    narrow_start = max(rt_start, rt_apex)
    narrow_end = min(rt_end, rt_apex + max_rt_distance)
    in_narrow = [s for s in ms1_scans if narrow_start <= s.rt_min <= narrow_end]
    if in_narrow:
        return max(in_narrow, key=lambda s: (s.base_peak_value, -abs(s.rt_min - rt_apex)))
    # 第二优先：原始窗口内距 apex 最近
    in_rng = [s for s in ms1_scans if rt_start <= s.rt_min <= rt_end]
    if in_rng:
        return min(in_rng, key=lambda s: abs(s.rt_min - rt_apex))
    # 第三优先：全局最近
    if ms1_scans:
        return min(ms1_scans, key=lambda s: abs(s.rt_min - rt_apex))
    return None


def pick_best_ms1_scan_indexed(
    ms1_index: MS1ScanIndex,
    *,
    rt_start: float,
    rt_end: float,
    rt_apex: float,
    max_rt_distance: float = 0.04,
) -> Optional[ScanRecord]:
    """
    优先在 [apex, apex+max_rt_distance] 窄窗口内选 base_peak_value 最大的 scan；
    窄窗口无命中则在原始窗口内选距 apex 最近的；仍无则全局选距 apex 最近的。
    """
    if not ms1_index.scans_sorted:
        return None

    rts = ms1_index.rts_sorted

    # 第一优先：窄窗口（与原始窗口取交集）
    narrow_start = max(float(rt_start), float(rt_apex))
    narrow_end = min(float(rt_end), float(rt_apex) + max_rt_distance)
    lo = int(bisect_left(rts, narrow_start))
    hi = int(bisect_right(rts, narrow_end))
    if lo < hi:
        best_scan: Optional[ScanRecord] = None
        best_key: Optional[Tuple[float, float, int]] = None
        for scan, order in zip(ms1_index.scans_sorted[lo:hi], ms1_index.order_sorted[lo:hi].tolist()):
            key = (float(scan.base_peak_value or 0.0), -abs(float(scan.rt_min) - float(rt_apex)), -int(order))
            if best_key is None or key > best_key:
                best_key = key
                best_scan = scan
        return best_scan

    # 第二优先：原始窗口内选距 apex 最近的
    lo2 = int(bisect_left(rts, float(rt_start)))
    hi2 = int(bisect_right(rts, float(rt_end)))
    if lo2 < hi2:
        best_scan2: Optional[ScanRecord] = None
        best_key2: Optional[Tuple[float, int]] = None
        for scan, order in zip(ms1_index.scans_sorted[lo2:hi2], ms1_index.order_sorted[lo2:hi2].tolist()):
            key2 = (abs(float(scan.rt_min) - float(rt_apex)), int(order))
            if best_key2 is None or key2 < best_key2:
                best_key2 = key2
                best_scan2 = scan
        return best_scan2

    # 第三优先：全局选距 apex 最近的（原有 fallback）
    best_scan3: Optional[ScanRecord] = None
    best_key3: Optional[Tuple[float, int]] = None
    for scan, order in zip(ms1_index.scans_sorted, ms1_index.order_sorted.tolist()):
        key3 = (abs(float(scan.rt_min) - float(rt_apex)), int(order))
        if best_key3 is None or key3 < best_key3:
            best_key3 = key3
            best_scan3 = scan
    return best_scan3


def collect_ms1_scans_in_window(
    ms1_index: MS1ScanIndex,
    *,
    rt_start: float,
    rt_end: float,
    rt_apex: float,
    max_rt_distance: float = 0.04,
) -> List[ScanRecord]:
    """
    返回 [apex, apex+max_rt_distance] ∩ [rt_start, rt_end] 内的所有 MS1 scan。
    若窄窗口空 → 返回原始窗口内距 apex 最近的 1 个 scan。
    若原始窗口也空 → 返回全局距 apex 最近的 1 个 scan。
    """
    if not ms1_index.scans_sorted:
        return []

    rts = ms1_index.rts_sorted

    # 第一优先：窄窗口
    narrow_start = max(float(rt_start), float(rt_apex))
    narrow_end = min(float(rt_end), float(rt_apex) + max_rt_distance)
    lo = int(bisect_left(rts, narrow_start))
    hi = int(bisect_right(rts, narrow_end))
    if lo < hi:
        return list(ms1_index.scans_sorted[lo:hi])

    # 第二优先：原始窗口内距 apex 最近的 1 个
    lo2 = int(bisect_left(rts, float(rt_start)))
    hi2 = int(bisect_right(rts, float(rt_end)))
    if lo2 < hi2:
        best = min(
            ms1_index.scans_sorted[lo2:hi2],
            key=lambda s: abs(float(s.rt_min) - float(rt_apex)),
        )
        return [best]

    # 第三优先：全局最近 1 个
    best = min(
        ms1_index.scans_sorted,
        key=lambda s: abs(float(s.rt_min) - float(rt_apex)),
    )
    return [best]


def average_centroid_peaks(
    d_reader: "AgilentDReader",
    scans: List[ScanRecord],
    ppm_tol: float = 5.0,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    读取多个 scan 的质心峰，按 m/z 对齐后取平均。

    对齐逻辑：将所有峰按 m/z 排序后贪心聚类（相邻差 < ppm_tol 归为同一组）。
    每组：mz = 强度加权平均，intensity = 总强度 / scan 数量。
    返回 (mz_arr, int_arr)，未排序（交由调用方处理）。
    """
    if not scans:
        return np.array([], dtype=np.float64), np.array([], dtype=np.float64)

    n_scans = len(scans)

    # 单 scan 快速路径
    if n_scans == 1:
        return d_reader.read_centroid_peaks(scans[0])

    # 收集所有峰
    all_mz: List[float] = []
    all_int: List[float] = []
    for s in scans:
        mz, inten = d_reader.read_centroid_peaks(s)
        if mz.size > 0:
            all_mz.extend(mz.tolist())
            all_int.extend(inten.tolist())

    if not all_mz:
        return np.array([], dtype=np.float64), np.array([], dtype=np.float64)

    # 按 m/z 排序
    mz_arr = np.array(all_mz, dtype=np.float64)
    int_arr = np.array(all_int, dtype=np.float64)
    order = np.argsort(mz_arr)
    mz_arr = mz_arr[order]
    int_arr = int_arr[order]

    # 贪心聚类
    cluster_mz: List[float] = []
    cluster_int: List[float] = []
    i = 0
    n = len(mz_arr)
    while i < n:
        grp_mz = [float(mz_arr[i])]
        grp_int = [float(int_arr[i])]
        j = i + 1
        anchor = float(mz_arr[i])
        while j < n:
            diff_ppm = abs(float(mz_arr[j]) - anchor) / anchor * 1e6
            if diff_ppm <= ppm_tol:
                grp_mz.append(float(mz_arr[j]))
                grp_int.append(float(int_arr[j]))
                j += 1
            else:
                break
        # 强度加权平均 m/z
        total_int = sum(grp_int)
        if total_int > 0:
            avg_mz = sum(m * it for m, it in zip(grp_mz, grp_int)) / total_int
        else:
            avg_mz = sum(grp_mz) / len(grp_mz)
        # intensity = 总强度 / scan 数
        avg_int = total_int / n_scans
        cluster_mz.append(avg_mz)
        cluster_int.append(avg_int)
        i = j

    return np.array(cluster_mz, dtype=np.float64), np.array(cluster_int, dtype=np.float64)

