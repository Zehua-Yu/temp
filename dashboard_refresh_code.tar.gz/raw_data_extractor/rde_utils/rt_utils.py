"""
rde_utils/rt_utils.py

集中管理 RT 字符串解析/规范化逻辑，避免脚本间重复实现。
"""

from __future__ import annotations

from typing import List, Optional


def parse_rt_value(rt_str: object) -> Optional[float]:
    """
    兼容 `pdf_parser.py` 的 RT 解析思路：提取字符串中的所有数字/区间，并取平均值。

    支持：
    - "8.080"
    - "7.976-8.215"
    - "0.763, 0.851-0.892"
    """
    if rt_str is None:
        return None
    if isinstance(rt_str, (int, float)):
        return float(rt_str)
    s = str(rt_str).strip()
    if not s:
        return None
    s = s.replace("...", "")
    parts = [p.strip() for p in s.split(",") if p.strip()]
    vals: List[float] = []
    for part in parts:
        if "-" in part:
            lr = [x.strip() for x in part.split("-", 1)]
            try:
                a = float(lr[0])
                b = float(lr[1])
                vals.extend([a, b])
            except Exception:
                continue
        else:
            try:
                vals.append(float(part))
            except Exception:
                continue
    if not vals:
        return None
    return sum(vals) / len(vals)

