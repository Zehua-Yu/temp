"""
rde_utils

通用工具：RT/mz 解析、scan 索引、配置加载等。
"""

