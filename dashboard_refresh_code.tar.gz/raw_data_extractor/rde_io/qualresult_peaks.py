"""
rde_io/qualresult_peaks.py

从 Agilent MassHunter Qual 保存的 `QualResult.bin` 中抽取 chromatogram 的 peak 表，
并尽量与 MassHunter PDF 报告峰表保持一致（字段/四舍五入/筛选逻辑）。

核心约定（来自样例数据验证）：
- Peak 的 ResultAttributeValueDictionary 中，key=204 通常可用于区分“报告/选中”的 peak。
  - 例如同名的两条 `+ BPC Scan` chromatogram 会各自有一套 peak，
    其中一套 peak 的 204=True（对应报告），另一套为 204=False（不在报告）。

导出字段（尽量贴近 PDF 的 BPC/TIC/UV 峰表）：
- Peak No, Start, RT, End, Height, Area, Area %, Area Sum %
其中：
- Start/RT/End 以分钟；RT 默认保留 3 位小数（优先使用 key=138 的字符串）
- Height/Area 默认按整数输出（MassHunter PDF 常如此显示）
- Area %：key=5（相对最大峰面积的百分比）
- Area Sum %：key=7（占总面积百分比）

如果你的不同版本 MassHunter key-id 有变化，可在本模块顶部常量区调整。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from .dotnet_nrbf import BinaryObjectString, MemberReference, NrbfContext, parse_nrbf_file


# ---- ResultAttribute key-id 映射（样例数据验证过） ----
KEY_START_RT_MIN = 60
KEY_APEX_RT_MIN = 17
KEY_END_RT_MIN = 27
KEY_HEIGHT = 31
KEY_AREA = 4
KEY_AREA_PCT_OF_MAX = 5
KEY_AREA_PCT_OF_TOTAL = 7
KEY_HEIGHT_PCT_OF_MAX = 32
KEY_APEX_RT_STR_3DP = 138  # e.g. "21.060"
KEY_REPORT_SELECTED = 204  # bool：通常用作“勾选/入报告”
KEY_BASE_PEAK_MZ = 16  # 对 MS BPC/TIC 峰常见：base peak m/z（用于提示）


@dataclass(frozen=True)
class ChromatogramInfo:
    object_id: int
    class_name: str
    title: str
    short_title: str
    sub_y_unit: str


@dataclass(frozen=True)
class PeakRow:
    chrom_object_id: int
    chrom_title: str
    peak_no: int
    start_rt_min: float
    apex_rt_min: float
    end_rt_min: float
    height: Optional[float]
    area: Optional[float]
    area_pct_of_max: Optional[float]
    area_pct_of_total: Optional[float]
    height_pct_of_max: Optional[float]
    apex_rt_str: Optional[str]
    base_peak_mz: Optional[float]
    report_selected: Optional[bool]
    attrs: Dict[int, object]

    def rt_display_3dp(self) -> str:
        if self.apex_rt_str:
            return self.apex_rt_str
        return f"{self.apex_rt_min:.3f}"


def _deref(ctx: NrbfContext, x: object) -> object:
    if isinstance(x, MemberReference):
        return ctx.objects.get(x.IdRef)
    return x


def _get_string(ctx: NrbfContext, x: object) -> Optional[str]:
    x = _deref(ctx, x)
    if isinstance(x, BinaryObjectString):
        return x.Value
    return None


def _obj_members(obj) -> Dict[str, object]:
    ci = getattr(obj, "ClassInfo", None)
    md = getattr(obj, "memberdata", None)
    if not ci or md is None:
        return {}
    return dict(zip(ci.MemberNames, md))


def _value_dict(ctx: NrbfContext, dict_obj) -> Dict[int, object]:
    """
    解析 `Agilent...ResultAttributeValueDictionary`：
    - key：`Agilent...ResultAttribute` 枚举值（value__ -> int）
    - value：primitive / string / reference
    """
    ci = getattr(dict_obj, "ClassInfo", None)
    md = getattr(dict_obj, "memberdata", None)
    if not ci or md is None:
        return {}
    m = dict(zip(ci.MemberNames, md))
    out: Dict[int, object] = {}
    for mn in ci.MemberNames:
        if not mn.startswith("ResultAttributeValueDictionaryKey"):
            continue
        n = int(mn.split("Key")[-1])
        key_obj = _deref(ctx, m.get(mn))
        val_obj = _deref(ctx, m.get(f"ResultAttributeValueDictionaryValue{n}"))
        if key_obj is None or val_obj is None:
            continue
        kci = getattr(key_obj, "ClassInfo", None)
        kmd = getattr(key_obj, "memberdata", None)
        if not kci or kmd is None or "value__" not in kci.MemberNames:
            continue
        key_id = int(kmd[kci.MemberNames.index("value__")])
        if isinstance(val_obj, BinaryObjectString):
            out[key_id] = val_obj.Value
        else:
            out[key_id] = val_obj
    return out


def _extract_chrom_peak_value_dicts(ctx: NrbfContext, chrom_obj) -> Optional[List[Dict[int, object]]]:
    """
    Chromatogram -> FXDataBase+m_resultList -> ChromPeakList -> PeakListBase+m_list -> List<IPeak> -> _items

    返回 list[dict]，每个 dict 为该 peak 的 ResultAttributeValueDictionary（key_id->value）
    """
    ci = chrom_obj.ClassInfo
    md = chrom_obj.memberdata
    if "FXDataBase+m_resultList" not in ci.MemberNames:
        return None
    rl = _deref(ctx, md[ci.MemberNames.index("FXDataBase+m_resultList")])
    if rl is None or not hasattr(rl, "ClassInfo"):
        return None
    if "CoreList<T>+m_list" not in rl.ClassInfo.MemberNames:
        return None
    lst = _deref(ctx, rl.memberdata[rl.ClassInfo.MemberNames.index("CoreList<T>+m_list")])
    if lst is None or not hasattr(lst, "ClassInfo") or "_items" not in lst.ClassInfo.MemberNames:
        return None
    items = _deref(ctx, lst.memberdata[lst.ClassInfo.MemberNames.index("_items")])
    if items is None or not hasattr(items, "arraydata"):
        return None

    first_ref = next((x for x in items.arraydata if isinstance(x, MemberReference)), None)
    if first_ref is None:
        return []
    peak_list = ctx.objects.get(first_ref.IdRef)
    if peak_list is None or not hasattr(peak_list, "ClassInfo"):
        return None
    if "ChromPeakList" not in peak_list.ClassInfo.Name:
        return None
    if "PeakListBase+m_list" not in peak_list.ClassInfo.MemberNames:
        return None
    pk_list = _deref(ctx, peak_list.memberdata[peak_list.ClassInfo.MemberNames.index("PeakListBase+m_list")])
    if pk_list is None or not hasattr(pk_list, "ClassInfo") or "_items" not in pk_list.ClassInfo.MemberNames:
        return None
    pk_items = _deref(ctx, pk_list.memberdata[pk_list.ClassInfo.MemberNames.index("_items")])
    if pk_items is None or not hasattr(pk_items, "arraydata"):
        return None

    peak_refs = [x for x in pk_items.arraydata if isinstance(x, MemberReference)]
    peak_objs = [ctx.objects.get(x.IdRef) for x in peak_refs]
    peak_objs = [p for p in peak_objs if p is not None and hasattr(p, "ClassInfo")]

    out: List[Dict[int, object]] = []
    for p in peak_objs:
        if "PeakBase+m_valueDict" not in p.ClassInfo.MemberNames:
            continue
        vd = _deref(ctx, p.memberdata[p.ClassInfo.MemberNames.index("PeakBase+m_valueDict")])
        if vd is None:
            continue
        out.append(_value_dict(ctx, vd))
    return out


def iter_chromatograms_with_peaks(ctx: NrbfContext) -> Iterable[Tuple[ChromatogramInfo, List[PeakRow]]]:
    for oid, obj in ctx.objects.items():
        ci = getattr(obj, "ClassInfo", None)
        md = getattr(obj, "memberdata", None)
        if not ci or md is None:
            continue
        if ci.Name not in (
            "Agilent.MassSpectrometry.DataAnalysis.Chromatogram",
            "Agilent.MassSpectrometry.DataAnalysis.MSChromatogram",
        ):
            continue

        mem = _obj_members(obj)
        title = _get_string(ctx, mem.get("XYDataBase+m_title")) or ""
        short = _get_string(ctx, mem.get("XYDataBase+m_shortTitle")) or ""
        suby = _get_string(ctx, mem.get("XYDataBase+m_subYValueLabel")) or ""

        peak_dicts = _extract_chrom_peak_value_dicts(ctx, obj)
        if peak_dicts is None:
            continue

        chrom = ChromatogramInfo(
            object_id=int(oid),
            class_name=ci.Name,
            title=title,
            short_title=short,
            sub_y_unit=suby,
        )

        peaks: List[PeakRow] = []
        for idx, d in enumerate(peak_dicts, start=1):

            def gf(k: int) -> Optional[float]:
                v = d.get(k)
                if v is None:
                    return None
                try:
                    return float(v)
                except Exception:
                    return None

            def gb(k: int) -> Optional[bool]:
                v = d.get(k)
                if isinstance(v, bool):
                    return v
                return None

            def gs(k: int) -> Optional[str]:
                v = d.get(k)
                if isinstance(v, str):
                    return v
                return None

            peaks.append(
                PeakRow(
                    chrom_object_id=int(oid),
                    chrom_title=title,
                    peak_no=int(idx),
                    start_rt_min=float(gf(KEY_START_RT_MIN) or 0.0),
                    apex_rt_min=float(gf(KEY_APEX_RT_MIN) or 0.0),
                    end_rt_min=float(gf(KEY_END_RT_MIN) or 0.0),
                    height=gf(KEY_HEIGHT),
                    area=gf(KEY_AREA),
                    area_pct_of_max=gf(KEY_AREA_PCT_OF_MAX),
                    area_pct_of_total=gf(KEY_AREA_PCT_OF_TOTAL),
                    height_pct_of_max=gf(KEY_HEIGHT_PCT_OF_MAX),
                    apex_rt_str=gs(KEY_APEX_RT_STR_3DP),
                    base_peak_mz=gf(KEY_BASE_PEAK_MZ),
                    report_selected=gb(KEY_REPORT_SELECTED),
                    attrs=d,
                )
            )

        yield chrom, peaks


def load_pdf_like_peaks(qual_bin: Path) -> Tuple[List[ChromatogramInfo], List[PeakRow]]:
    """
    读取 `QualResult.bin` 并返回：
    - chromatograms：所有含 peak 表的 chromatogram 信息
    - peaks_pdf：筛选后的“与 PDF 报告一致”的 peak（优先使用 key=204==True 过滤；
      若全文件没有出现 key=204，则回退为不过滤）
    """
    ctx = parse_nrbf_file(str(qual_bin))

    chroms: List[ChromatogramInfo] = []
    all_peaks: List[PeakRow] = []
    for c, peaks in iter_chromatograms_with_peaks(ctx):
        chroms.append(c)
        all_peaks.extend(peaks)

    has_selected_flag = any(p.report_selected is not None for p in all_peaks)
    if not has_selected_flag:
        return chroms, all_peaks

    peaks_pdf = [p for p in all_peaks if p.report_selected is True]
    return chroms, peaks_pdf


def is_bpc_chrom(chrom_title: str, chrom_short: str) -> bool:
    t = (chrom_short or chrom_title or "").lower()
    return " bpc " in f" {t} " or "base peak" in t


def is_tic_chrom(chrom_title: str, chrom_short: str) -> bool:
    t = (chrom_short or chrom_title or "").lower()
    return " tic " in f" {t} " or "total ion" in t

