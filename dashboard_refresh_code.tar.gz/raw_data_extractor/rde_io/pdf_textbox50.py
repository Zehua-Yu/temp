"""
rde_io/pdf_textbox50.py

从 MassHunter 导出的 `*_Analysis.pdf` 中抽取 Textbox50 的色谱峰表（BPC / DAD）。

该逻辑原本内嵌在 `raw_blank_analysis.py`，后抽出以便复用/维护。

波长泛化：不再写死 210/254，而是从上下文自动提取实际波长（如 220、230、254 等）。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd


@dataclass(frozen=True)
class SimplePeak:
    """
    用于从 PDF 表格"移植"出来的色谱峰信息，保持与 PeakRow 类似的接口，
    以便复用 `_build_esi_info_for_peaks()`。
    """

    peak_no: int
    start_rt_min: float
    apex_rt_min: float
    end_rt_min: float
    apex_rt_str: Optional[str] = None

    def rt_display_3dp(self) -> str:
        if self.apex_rt_str:
            return self.apex_rt_str
        return f"{self.apex_rt_min:.3f}"


def _guess_analysis_pdf_path(d_path: Path) -> Optional[Path]:
    """
    根据 `.d` 目录路径猜测同目录的 Analysis PDF。
    优先使用优化版 `*_Analysis_优化.pdf`，回退到 `*_Analysis.pdf`。
    例如：20250911135147-BK2.d -> 20250911135147-BK2_Analysis_优化.pdf 或 _Analysis.pdf
    """
    stem = d_path.with_suffix("").name  # 去掉 .d
    parent = d_path.parent
    for suffix in ("_Analysis_优化.pdf", "_Analysis.pdf"):
        pdf = parent / f"{stem}{suffix}"
        if pdf.exists():
            return pdf
    return None


def _extract_text_lines_from_pdf(pdf_path: Path) -> List[str]:
    """
    从 PDF 中抽取纯文本行（移植自 `pdf_report_extractor/pdf_parser.py::extract_text` 的核心逻辑）。
    """
    import fitz  # PyMuPDF（项目内 pdf_parser.py 也使用它）

    doc = fitz.open(str(pdf_path))
    all_lines: List[str] = []
    for page in doc:
        page_text = page.get_text()
        page_lines = page_text.split("\n")

        # 过滤页面文本，删除页眉页码相关信息（与 pdf_parser.py 保持一致：遇到关键标题跳过后4行）
        filtered: List[str] = []
        i = 0
        while i < len(page_lines):
            if "MassHunter Qualitative Analysis" in page_lines[i]:
                i += 4
                if i >= len(page_lines):
                    break
                continue
            filtered.append(page_lines[i].strip())
            i += 1
        all_lines.extend(filtered)
    doc.close()
    return all_lines


def _detect_table_type_from_context(text_lines: List[str], textbox50_line_idx: int) -> str:
    """
    通过检查 Textbox50 上方若干行的文本内容来判断表格类型。
    从 Textbox50 往上逐行搜索，找到最近的 DAD/BPC 标识行。
    返回: "BPC" / "DAD_{wavelength}nm"（如 "DAD_220nm"）/ "unknown"
    """
    # 从 Textbox50 往上搜索，最多50行，找到最近的标识
    start = max(0, textbox50_line_idx - 50)
    for i in range(textbox50_line_idx - 1, start - 1, -1):
        line = text_lines[i].lower()
        # 检测 DAD 波长
        m = re.search(r"sig=(\d+)(?:\.\d+)?", line)
        if m and "dad" in line:
            wl = m.group(1)
            return f"DAD_{wl}nm"
        # 检测 BPC/TIC
        if "bpc" in line or "base peak" in line or "tic" in line or "total ion" in line:
            return "BPC"
    return "unknown"


def _parse_textbox50_tables(text_lines: List[str]) -> Dict[str, Any]:
    """
    解析 Textbox50 的色谱峰表（BPC / DAD）。
    基于标题内容判断表格类型，自动识别任意 DAD 波长。
    返回 dict，key 格式为 "BPC_Peaks" 或 "DAD_Peaks_{wl}nm"（如 "DAD_Peaks_220nm"）。
    """
    key_info: Dict[str, Any] = {"BPC_Peaks": None}
    i = 0

    tables_found: List[Dict[str, Any]] = []

    while i < len(text_lines):
        if "Textbox50" not in (text_lines[i] or ""):
            i += 1
            continue

        detected_type = _detect_table_type_from_context(text_lines, i)
        if detected_type == "unknown":
            i += 1
            continue

        # 跳过标题行（Textbox50 + 表格标题行 + 7个字段名行，共9行）
        i += 9

        # 读取 8 行为一条记录
        current_table_data: List[List[object]] = []
        while i + 7 < len(text_lines):
            if "Textbox50" in (text_lines[i] or ""):
                break
            eight = [str(text_lines[i + j]).strip() for j in range(8)]
            if any(not x for x in eight):
                break

            peak_row: List[object] = []
            valid = True
            for j, line in enumerate(eight):
                try:
                    if "." in line:
                        peak_row.append(float(line))
                    else:
                        peak_row.append(int(line) if j == 0 else float(line))
                except Exception:
                    valid = False
                    break
            if not valid or len(peak_row) != 8:
                break
            current_table_data.append(peak_row)
            i += 8

        if current_table_data:
            tables_found.append({"type": detected_type, "data": current_table_data})

    # 将收集的表格写入 key_info
    cols = ["Peak", "Start", "RT", "End", "Height", "Area", "Area_Percent", "Area_Sum"]
    for t in tables_found:
        ttype = t["type"]
        df = pd.DataFrame(t["data"], columns=cols)
        if ttype == "BPC":
            if key_info["BPC_Peaks"] is None:
                key_info["BPC_Peaks"] = df
        elif ttype.startswith("DAD_"):
            # 动态 key：如 "DAD_220nm" → "DAD_Peaks_220nm"
            peaks_key = f"DAD_Peaks_{ttype[4:]}"  # "DAD_220nm" → "DAD_Peaks_220nm"
            if peaks_key not in key_info or key_info[peaks_key] is None:
                key_info[peaks_key] = df

    return key_info


def _coerce_pdf_peak_table(df: pd.DataFrame) -> pd.DataFrame:
    """
    将从 PDF Textbox50 抽取的表格规范化到 raw_blank_analysis 使用的列类型/格式：
    - Start/End: float
    - RT: 3位小数的字符串（与 PeakRow.rt_display_3dp() 的风格一致）
    """
    if df is None or df.empty:
        return pd.DataFrame()
    out = df.copy()
    for c in ["Peak"]:
        out[c] = pd.to_numeric(out[c], errors="coerce").astype("Int64")
    for c in ["Start", "End", "Height", "Area", "Area_Percent", "Area_Sum", "RT"]:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce")
    # RT 转成 3dp 字符串
    out["RT"] = out["RT"].apply(lambda x: f"{float(x):.3f}" if pd.notna(x) else "")
    # Int64 -> int
    out["Peak"] = out["Peak"].apply(lambda x: int(x) if pd.notna(x) else None)
    return out
