"""
rde_io/agilent_d_reader.py

纯 Python 读取 Agilent MassHunter `.d` 目录中的 MS scan 元信息与质心峰（MSPeak.bin）。

目标：
- 提供“按需读取单个 scan 的质心峰”能力，用于 BPC 峰的 MS1/MS2 TOP-N 分析
- 不做全量 CSV 导出（那会产生很多冗余中间文件）

依赖：
    pip install numpy
"""

from __future__ import annotations

import mmap
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from xml.etree import ElementTree as ET

import numpy as np


@dataclass(frozen=True)
class ScanRecord:
    scan_id: int
    scan_method_id: int
    time_segment_id: int
    rt_min: float
    ms_level: int
    scan_type: int
    tic: float
    base_peak_mz: float
    base_peak_value: float
    calibration_id: int
    cycle_number: int
    ion_mode: int
    ion_polarity: int
    fragmentor: float
    collision_energy: float
    precursor_mz: float  # mz_of_interest in MSScan.bin
    mz_isolation_width: float
    abundance_limit: float
    sampling_period: float
    threshold: float
    charge_state: int
    chrom_scale_factor: float
    masscal_offset: int
    actuals_offset: int
    num_actuals_per_scan: int
    ddscan_id: int
    ddscan_id2: int
    ddscan_id3: int
    # centroid peaks spectrum info (from the 2nd spectrum struct)
    mspeak_format_id: int
    mspeak_offset: int
    mspeak_bytecount: int
    mspeak_pointcount: int


_MSSCAN_BASE_STRUCT = struct.Struct("<III d H I d d d H I I H f f d f d d d H f Q Q H III")
_MSSCAN_SPECTRUM_STRUCT = struct.Struct("<H Q I I I d d d d d I")
_MSSCAN_RECORD_SIZE = _MSSCAN_BASE_STRUCT.size + 2 * _MSSCAN_SPECTRUM_STRUCT.size  # 274


def _parse_default_mass_calibration(default_masscal_xml: Path) -> Dict[int, Tuple[float, float]]:
    """
    解析 `DefaultMassCal.xml`，返回 { DefaultCalibrationID: (coeff, base) }。
    使用 Step1(Traditional) 两参数，校准公式：
      mz = (coeff * (raw - base))^2
    """
    tree = ET.parse(default_masscal_xml)
    root = tree.getroot()

    def strip_ns(tag: str) -> str:
        return tag.split("}", 1)[1] if "}" in tag else tag

    cal_map: Dict[int, Tuple[float, float]] = {}
    for dc in root.iter():
        if strip_ns(dc.tag) != "DefaultCalibration":
            continue
        dcid_raw = dc.attrib.get("DefaultCalibrationID")
        if not dcid_raw:
            continue
        try:
            dcid = int(dcid_raw)
        except Exception:
            continue

        coeff = None
        base = None
        for step in dc:
            if strip_ns(step.tag) != "Step" or step.attrib.get("Number") != "1":
                continue
            # Values/Value Number="1","2"
            for child in step.iter():
                if strip_ns(child.tag) != "Value":
                    continue
                n = child.attrib.get("Number")
                v = (child.text or "").strip()
                if not n or not v:
                    continue
                try:
                    if n == "1":
                        coeff = float(v)
                    elif n == "2":
                        base = float(v)
                except Exception:
                    pass

        if coeff is not None and base is not None:
            cal_map[dcid] = (coeff, base)

    if not cal_map:
        raise RuntimeError(f"解析 {default_masscal_xml} 失败：未找到可用的默认校准系数。")
    return cal_map


def iter_scan_records(d_path: Path) -> Iterable[ScanRecord]:
    """
    直接解析 `.d/AcqData/MSScan.bin`，迭代所有扫描（MS1 + MS2）的元信息。
    """
    if not d_path.is_dir() or d_path.suffix.lower() != ".d":
        raise ValueError(f"不是有效的 .d 目录：{d_path}")

    acq = d_path / "AcqData"
    msscan = acq / "MSScan.bin"
    msts = acq / "MSTS.xml"
    if not (msscan.exists() and msts.exists()):
        raise FileNotFoundError(f"缺少必要文件：{msscan} 或 {msts}")

    # 扫描总数（包括 MS1 / MS2）
    msts_root = ET.parse(msts).getroot()
    num_scans = 0
    for ts in msts_root.findall("TimeSegment"):
        n = ts.findtext("NumOfScans")
        if n:
            num_scans += int(n)

    with msscan.open("rb") as f:
        # 0x58 处存一个 u32 指针，指向 scan records 开始位置
        f.seek(0x58)
        ptr = struct.unpack("<I", f.read(4))[0]
        f.seek(ptr)

        for _ in range(num_scans):
            rec = f.read(_MSSCAN_RECORD_SIZE)
            if len(rec) != _MSSCAN_RECORD_SIZE:
                break

            base = _MSSCAN_BASE_STRUCT.unpack_from(rec, 0)
            (
                scan_id,
                scan_method_id,
                time_segment_id,
                scan_time_min,
                ms_level,
                scan_type,
                tic,
                base_peak_mz,
                base_peak_value,
                calibration_id,
                cycle_number,
                ion_mode,
                ion_polarity,
                fragmentor,
                collision_energy,
                mz_of_interest,
                mz_isolation_width,
                abundance_limit,
                sampling_period,
                threshold,
                charge_state,
                chrom_scale_factor,
                masscal_offset,
                actuals_offset,
                num_actuals_per_scan,
                ddscan_id,
                ddscan_id2,
                ddscan_id3,
            ) = base

            sp2 = _MSSCAN_SPECTRUM_STRUCT.unpack_from(rec, _MSSCAN_BASE_STRUCT.size + _MSSCAN_SPECTRUM_STRUCT.size)
            (fmt2, off2, bc2, pc2, _ubc2, *_rest) = sp2

            yield ScanRecord(
                scan_id=int(scan_id),
                scan_method_id=int(scan_method_id),
                time_segment_id=int(time_segment_id),
                rt_min=float(scan_time_min),
                ms_level=int(ms_level),
                scan_type=int(scan_type),
                tic=float(tic),
                base_peak_mz=float(base_peak_mz),
                base_peak_value=float(base_peak_value),
                calibration_id=int(calibration_id),
                cycle_number=int(cycle_number),
                ion_mode=int(ion_mode),
                ion_polarity=int(ion_polarity),
                fragmentor=float(fragmentor),
                collision_energy=float(collision_energy),
                precursor_mz=float(mz_of_interest),
                mz_isolation_width=float(mz_isolation_width),
                abundance_limit=float(abundance_limit),
                sampling_period=float(sampling_period),
                threshold=float(threshold),
                charge_state=int(charge_state),
                chrom_scale_factor=float(chrom_scale_factor),
                masscal_offset=int(masscal_offset),
                actuals_offset=int(actuals_offset),
                num_actuals_per_scan=int(num_actuals_per_scan),
                ddscan_id=int(ddscan_id),
                ddscan_id2=int(ddscan_id2),
                ddscan_id3=int(ddscan_id3),
                mspeak_format_id=int(fmt2),
                mspeak_offset=int(off2),
                mspeak_bytecount=int(bc2),
                mspeak_pointcount=int(pc2),
            )


def build_ms2_parent_map(scans: List[ScanRecord]) -> Tuple[Dict[int, Optional[int]], Dict[int, List[int]]]:
    """
    返回：
    - parent_ms1_of_ms2: ms2_scan_id -> parent_ms1_scan_id (可能为 None)
    - children_ms2_of_ms1: ms1_scan_id -> [ms2_scan_id, ...]
    """
    scan_map = {s.scan_id: s for s in scans}
    parent_ms1_of_ms2: Dict[int, Optional[int]] = {}
    children_ms2_of_ms1: Dict[int, List[int]] = {}
    last_ms1_by_cycle: Dict[Tuple[int, int], int] = {}

    for s in scans:
        if s.ms_level == 1:
            last_ms1_by_cycle[(s.time_segment_id, s.cycle_number)] = s.scan_id
            continue
        if s.ms_level != 2:
            continue

        parent = None
        for cand in (s.ddscan_id, s.ddscan_id2, s.ddscan_id3):
            if cand and int(cand) in scan_map and scan_map[int(cand)].ms_level == 1:
                parent = int(cand)
                break
        if parent is None:
            parent = last_ms1_by_cycle.get((s.time_segment_id, s.cycle_number))

        parent_ms1_of_ms2[s.scan_id] = parent
        if parent is not None:
            children_ms2_of_ms1.setdefault(parent, []).append(s.scan_id)

    return parent_ms1_of_ms2, children_ms2_of_ms1


def _read_mspeak_centroid_block(
    *,
    mspeak_bytes,
    offset: int,
    bytecount: int,
    pointcount: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    读取 MSPeak.bin 中的一段质心峰 block，返回 raw_mz 与 intensity。

    常见格式：
      - 12N: [N x float64 raw_mz] + [N x float32 intensity]
      - 16N: [N x float64 raw_mz] + [N x float64 intensity]
    """
    if pointcount <= 0 or bytecount <= 0:
        return np.array([], dtype=np.float64), np.array([], dtype=np.float64)

    start = int(offset)
    end = start + int(bytecount)
    if start < 0:
        return np.array([], dtype=np.float64), np.array([], dtype=np.float64)

    # 用 memoryview 避免切片拷贝（对 bytes/mmap 均适用）
    mv = mspeak_bytes if isinstance(mspeak_bytes, memoryview) else memoryview(mspeak_bytes)
    if end > len(mv):
        return np.array([], dtype=np.float64), np.array([], dtype=np.float64)

    block = mv[start:end]
    n = int(pointcount)

    if bytecount == n * 12:
        raw_mz = np.frombuffer(block, dtype="<f8", count=n, offset=0)
        inten = np.frombuffer(block, dtype="<f4", count=n, offset=8 * n).astype(np.float64, copy=False)
        return raw_mz, inten

    if bytecount == n * 16:
        raw_mz = np.frombuffer(block, dtype="<f8", count=n, offset=0)
        inten = np.frombuffer(block, dtype="<f8", count=n, offset=8 * n).astype(np.float64, copy=False)
        return raw_mz, inten

    return np.array([], dtype=np.float64), np.array([], dtype=np.float64)


def _apply_mass_calibration(
    raw_mz: np.ndarray,
    *,
    calibration_id: int,
    cal_map: Dict[int, Tuple[float, float]],
) -> np.ndarray:
    if raw_mz.size == 0:
        return raw_mz.astype(np.float64, copy=False)
    cal_id = int(calibration_id) if int(calibration_id) in cal_map else min(cal_map.keys())
    coeff, base = cal_map[cal_id]
    return (coeff * (raw_mz - base)) ** 2


class AgilentDReader:
    """
    针对单个 `.d` 的轻量 reader（复用 MSPeak.bin bytes 与校准表）。
    """

    def __init__(self, d_path: Path) -> None:
        self.d_path = d_path
        acq = d_path / "AcqData"
        mspeak_path = acq / "MSPeak.bin"
        # MSPeak.bin 可能很大：优先 mmap，失败则回退到 read_bytes
        self._mspeak_file = None
        self._mspeak_mm = None
        self._mspeak_view = None
        try:
            self._mspeak_file = mspeak_path.open("rb")
            self._mspeak_mm = mmap.mmap(self._mspeak_file.fileno(), 0, access=mmap.ACCESS_READ)
            self._mspeak_view = memoryview(self._mspeak_mm)
            self.mspeak_bytes = self._mspeak_view
        except Exception:
            # 回退：一次性读入（兼容网络盘/权限受限等场景）
            if self._mspeak_mm is not None:
                try:
                    self._mspeak_mm.close()
                except Exception:
                    pass
            if self._mspeak_file is not None:
                try:
                    self._mspeak_file.close()
                except Exception:
                    pass
            self._mspeak_file = None
            self._mspeak_mm = None
            self._mspeak_view = None
            self.mspeak_bytes = mspeak_path.read_bytes()
        self.cal_map = _parse_default_mass_calibration(acq / "DefaultMassCal.xml")

    def close(self) -> None:
        if getattr(self, "_mspeak_view", None) is not None:
            try:
                self._mspeak_view.release()
            except Exception:
                pass
            self._mspeak_view = None
        if getattr(self, "_mspeak_mm", None) is not None:
            try:
                self._mspeak_mm.close()
            except Exception:
                pass
            self._mspeak_mm = None
        if getattr(self, "_mspeak_file", None) is not None:
            try:
                self._mspeak_file.close()
            except Exception:
                pass
            self._mspeak_file = None

    def __enter__(self) -> "AgilentDReader":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def read_centroid_peaks(self, scan: ScanRecord) -> Tuple[np.ndarray, np.ndarray]:
        raw_mz, inten = _read_mspeak_centroid_block(
            mspeak_bytes=self.mspeak_bytes,
            offset=scan.mspeak_offset,
            bytecount=scan.mspeak_bytecount,
            pointcount=scan.mspeak_pointcount,
        )
        if raw_mz.size == 0 or inten.size == 0:
            return np.array([], dtype=np.float64), np.array([], dtype=np.float64)
        mz = _apply_mass_calibration(raw_mz, calibration_id=scan.calibration_id, cal_map=self.cal_map)
        m = np.isfinite(mz) & np.isfinite(inten) & (inten > 0)
        if not np.any(m):
            return np.array([], dtype=np.float64), np.array([], dtype=np.float64)
        return mz[m], inten[m]


def cluster_isotope_peaks(
    spectrum_data: List[Dict[str, float]],
    *,
    mass_tolerance: float = 0.005,
    expected_mass_diffs: Optional[List[float]] = None,
) -> List[Dict[str, object]]:
    """
    对质谱峰进行“同位素峰聚类”，逻辑对齐 `pdf_parser.py::_cluster_isotope_peaks`（去掉 x_coord 约束）。
    """
    if not spectrum_data:
        return []

    if expected_mass_diffs is None:
        expected_mass_diffs = [
            1.003355,  # 13C vs 12C (z=1)
            0.501677,  # 13C vs 12C (z=2)
            0.334452,  # 13C vs 12C (z=3)
            1.995796,  # 34S vs 32S (z=1)
            0.997898,  # 34S vs 32S (z=2)
            1.006277,  # 15N vs 14N (z=1)
            0.503139,  # 15N vs 14N (z=2)
            2.004245,  # 37Cl vs 35Cl (z=1)
            1.002123,  # 37Cl vs 35Cl (z=2)
        ]

    # 1) 按 m/z 排序
    sorted_data = sorted(spectrum_data, key=lambda x: float(x["mz"]))
    mzs = np.array([float(x["mz"]) for x in sorted_data], dtype=float)
    intens = np.array([float(x["intensity"]) for x in sorted_data], dtype=float)

    def is_potential_isotope_peak(base_peak: Dict[str, float], cand_peak: Dict[str, float], mz_diff: float) -> bool:
        # 1. m/z 差值匹配
        if not any(abs(mz_diff - exp) <= mass_tolerance for exp in expected_mass_diffs):
            return False
        # 2. 强度关系（与 pdf_parser.py 保持一致范围）
        bi = float(base_peak["intensity"])
        ci = float(cand_peak["intensity"])
        if bi <= 0:
            return False
        ratio = ci / bi
        if ratio < 0.05 or ratio > 1.8:
            return False
        return True

    # 2) 滑动窗口聚类
    clusters: List[List[int]] = []
    used = set()
    for i, base in enumerate(sorted_data):
        if i in used:
            continue
        cluster = [i]
        used.add(i)
        base_mz = float(base["mz"])
        base_i = float(base["intensity"])
        j = i + 1
        max_search_mz = base_mz + 3.5
        # 利用已排序 mzs 限定搜索上界，减少循环次数与字典访问
        j_end = int(np.searchsorted(mzs, max_search_mz, side="right"))
        while j < j_end:
            if j in used:
                j += 1
                continue
            cand_mz = float(mzs[j])
            cand_i = float(intens[j])
            mz_diff = cand_mz - base_mz
            # inline is_potential_isotope_peak：减少 dict/float 开销
            if any(abs(mz_diff - exp) <= mass_tolerance for exp in expected_mass_diffs):
                if base_i > 0:
                    ratio = cand_i / base_i
                    if 0.05 <= ratio <= 1.8:
                        cluster.append(j)
                        used.add(j)
            j += 1
        clusters.append(cluster)

    # 3) 聚类代表峰 + 聚类统计
    clustered_results: List[Dict[str, object]] = []
    for cluster_idx, idxs in enumerate(clusters):
        if len(idxs) == 1:
            p = dict(sorted_data[idxs[0]])
            p["isotope_cluster_id"] = cluster_idx
            p["isotope_cluster_size"] = 1
            clustered_results.append(p)
            continue

        peaks = [sorted_data[k] for k in idxs]
        rep = dict(max(peaks, key=lambda x: float(x["intensity"])))
        rep["isotope_cluster_id"] = cluster_idx
        rep["isotope_cluster_size"] = len(peaks)
        rep["isotope_cluster_mz_range"] = [min(float(x["mz"]) for x in peaks), max(float(x["mz"]) for x in peaks)]
        rep["isotope_cluster_total_intensity"] = sum(float(x["intensity"]) for x in peaks)
        clustered_results.append(rep)

    # 4) 按聚类总强度（若无则代表峰强度）降序
    clustered_results.sort(key=lambda x: float(x.get("isotope_cluster_total_intensity", x["intensity"])), reverse=True)
    return clustered_results


def top_n_peaks(mz: np.ndarray, inten: np.ndarray, n: int) -> List[Tuple[float, float, float]]:
    """
    返回 [(mz, intensity, rel_intensity), ...]，按 intensity 降序，rel_intensity 以 base-peak=1.0。
    """
    if mz.size == 0 or inten.size == 0:
        return []
    k = max(0, int(n))
    if k <= 0:
        return []
    k = min(k, int(inten.size))
    # 只取 top-k：argpartition O(n)，再对 k 个元素排序
    idxs = np.argpartition(inten, -k)[-k:]
    idxs = idxs[np.argsort(inten[idxs])[::-1]]
    if idxs.size == 0:
        return []
    bpi = float(inten[int(idxs[0])])
    out: List[Tuple[float, float, float]] = []
    for i in idxs:
        ii = int(i)
        rel = float(inten[ii] / bpi) if bpi > 0 else 0.0
        out.append((float(mz[ii]), float(inten[ii]), rel))
    return out


def top_n_peaks_isotope_clustered(
    mz: np.ndarray,
    inten: np.ndarray,
    n: int,
    *,
    preselect: int = 200,
) -> List[Dict[str, object]]:
    """
    先从原始质心峰中取强度最高的 preselect 个作为候选，再做同位素峰聚类，
    最终返回 TOP-N “聚类代表峰”。
    """
    if mz.size == 0 or inten.size == 0:
        return []

    k = max(0, int(preselect))
    if k <= 0:
        return []
    k = min(k, int(inten.size))
    idxs = np.argpartition(inten, -k)[-k:]
    idxs = idxs[np.argsort(inten[idxs])[::-1]]
    if idxs.size == 0:
        return []

    candidates = [{"mz": float(mz[int(i)]), "intensity": float(inten[int(i)])} for i in idxs]
    clustered = cluster_isotope_peaks(candidates)
    clustered = clustered[: max(0, int(n))]
    if not clustered:
        return []

    bpi = float(clustered[0]["intensity"]) if float(clustered[0]["intensity"]) > 0 else 1.0
    for p in clustered:
        p["rel"] = float(p["intensity"]) / bpi
    return clustered

