"""
rde_io/dotnet_nrbf.py

用于解析 .NET BinaryFormatter (MS-NRBF / NRBF) 数据流的最小实现（纯 Python）。

本模块仅提供当前项目解析 Agilent MassHunter `QualResult.bin` 所需的能力：
- `parse_nrbf_file(path) -> NrbfContext`：解析（可能串联多个 payload 的）NRBF 文件
- `NrbfContext.objects`：解析出的对象表（object_id -> object/record）
- 基本 record 类型：ClassWithId / ClassWithMembersAndTypes / BinaryObjectString / MemberReference / Array 等

说明：
`QualResult.bin` 通常是多个 NRBF payload 串联；本实现按顺序读取，直到 EOF。
"""

from __future__ import annotations

import datetime
import io
import struct
from collections import namedtuple
from enum import Enum
from typing import Any, Dict, Tuple


class RecordType(Enum):
    SerializedStreamHeader = 0
    ClassWithId = 1
    SystemClassWithMembers = 2
    ClassWithMembers = 3
    SystemClassWithMembersAndTypes = 4
    ClassWithMembersAndTypes = 5
    BinaryObjectString = 6
    BinaryArray = 7
    MemberPrimitiveTyped = 8
    MemberReference = 9
    ObjectNull = 10
    MessageEnd = 11
    BinaryLibrary = 12
    ObjectNullMultiple256 = 13
    ObjectNullMultiple = 14
    ArraySinglePrimitive = 15
    ArraySingleObject = 16
    ArraySingleString = 17
    MethodCall = 21
    MethodReturn = 22


class BinaryType(Enum):
    Primitive = 0
    String = 1
    Object = 2
    SystemClass = 3
    Class = 4
    ObjectArray = 5
    StringArray = 6
    PrimitiveArray = 7


class BinaryArrayType(Enum):
    Single = 0
    Jagged = 1
    Rectangular = 2
    SingleOffset = 3
    JaggedOffset = 4
    RectangularOffset = 5


class PrimitiveType(Enum):
    Boolean = 1
    Byte = 2
    Char = 3
    Decimal = 5
    Double = 6
    Int16 = 7
    Int32 = 8
    Int64 = 9
    SByte = 10
    Single = 11
    TimeSpan = 12
    DateTime = 13
    UInt16 = 14
    UInt32 = 15
    UInt64 = 16
    Null = 17
    String = 18


def _readstruct(f: io.BufferedReader, fmt: str) -> Tuple[Any, ...]:
    fmt = "<" + fmt
    return struct.unpack(fmt, f.read(struct.calcsize(fmt)))


def _readvarint7(f: io.BufferedReader) -> int:
    n = 0
    shift = 0
    while True:
        c = f.read(1)
        if not c:
            raise EOFError()
        c0 = c[0]
        n |= (c0 & 0x7F) << shift
        if (c0 & 0x80) == 0:
            return n
        shift += 7
        if shift > 35:
            raise ValueError("invalid 7-bit encoded int")


def _readvarstr(f: io.BufferedReader) -> str:
    n = _readvarint7(f)
    return f.read(n).decode("utf-8", errors="replace")


class NrbfContext:
    def __init__(self) -> None:
        self.libraries: Dict[int, Any] = {}
        self.objects: Dict[int, Any] = {}


class SerializedStreamHeader(namedtuple("SerializedStreamHeader", "TopId HeaderId MajorVersion MinorVersion")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        (top_id, header_id, major, minor) = _readstruct(f, "iiii")
        return cls(top_id, header_id, major, minor)


class BinaryLibrary(namedtuple("BinaryLibrary", "LibraryId LibraryName")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        (library_id,) = _readstruct(f, "i")
        library_name = _readvarstr(f)
        ret = cls(library_id, library_name)
        ctx.libraries[library_id] = ret
        return ret


class ClassInfo(namedtuple("ClassInfo", "ObjectId Name MemberCount MemberNames")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        (obj_id,) = _readstruct(f, "i")
        name = _readvarstr(f)
        (member_count,) = _readstruct(f, "i")
        members = [_readvarstr(f) for _ in range(member_count)]
        return cls(obj_id, name, member_count, members)


class ClassTypeInfo(namedtuple("ClassTypeInfo", "TypeName LibraryId")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        name = _readvarstr(f)
        (library_id,) = _readstruct(f, "i")
        return cls(name, library_id)


def _additional_type_info(f: io.BufferedReader, type_enum: BinaryType, ctx: NrbfContext):
    if type_enum in (BinaryType.Primitive, BinaryType.PrimitiveArray):
        info = PrimitiveType(f.read(1)[0])
    elif type_enum == BinaryType.SystemClass:
        info = _readvarstr(f)
    elif type_enum == BinaryType.Class:
        info = ClassTypeInfo.fromfile(f, ctx)
    else:
        info = None
    return info


class MemberTypeInfo(namedtuple("MemberTypeInfo", "BinaryTypeEnums AdditionalInfos")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, classinfo: ClassInfo, ctx: NrbfContext):
        types = [BinaryType(f.read(1)[0]) for _ in range(classinfo.MemberCount)]
        infos = [_additional_type_info(f, t, ctx) for t in types]
        return cls(types, infos)


def _read_primitive(f: io.BufferedReader, type_enum: PrimitiveType):
    if type_enum == PrimitiveType.Boolean:
        return bool(_readstruct(f, "b")[0])
    if type_enum == PrimitiveType.Byte:
        return _readstruct(f, "B")[0]
    if type_enum == PrimitiveType.SByte:
        return _readstruct(f, "b")[0]
    if type_enum == PrimitiveType.UInt16:
        return _readstruct(f, "H")[0]
    if type_enum == PrimitiveType.Int16:
        return _readstruct(f, "h")[0]
    if type_enum == PrimitiveType.UInt32:
        return _readstruct(f, "I")[0]
    if type_enum == PrimitiveType.Int32:
        return _readstruct(f, "i")[0]
    if type_enum == PrimitiveType.UInt64:
        return _readstruct(f, "Q")[0]
    if type_enum == PrimitiveType.Int64:
        return _readstruct(f, "q")[0]
    if type_enum == PrimitiveType.Single:
        return _readstruct(f, "f")[0]
    if type_enum == PrimitiveType.Double:
        return _readstruct(f, "d")[0]
    if type_enum == PrimitiveType.Char:
        return _readstruct(f, "H")[0]
    if type_enum == PrimitiveType.DateTime:
        # ticks + kind (参考常见实现)
        val = _readstruct(f, "Q")[0]
        kind = val >> 62
        val &= ~(3 << 62)
        if val & (1 << 61):
            val -= 1 << 62
        _ = kind
        td = datetime.timedelta(microseconds=val / 10.0)
        return datetime.datetime(1, 1, 1) + td
    raise ValueError(f"Can't read primitives of type {type_enum.name}")


def _read_record(f: io.BufferedReader, ctx: NrbfContext):
    b = f.read(1)
    if not b:
        raise EOFError()
    rtype = RecordType(b[0])
    cls = _RECORD_CLASSES[rtype]
    return cls.fromfile(f, ctx)


def _read_typed_member(f: io.BufferedReader, type_enum: BinaryType, info, ctx: NrbfContext):
    if type_enum == BinaryType.Primitive:
        return _read_primitive(f, info)
    # 其他类型：作为 record（MemberReference / BinaryObjectString / Array / Class...）
    return _read_record(f, ctx)


class ClassWithMembersAndTypes(namedtuple("ClassWithMembersAndTypes", "ClassInfo MemberTypeInfo LibraryId")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        classinfo = ClassInfo.fromfile(f, ctx)
        memberinfo = MemberTypeInfo.fromfile(f, classinfo, ctx)
        (library_id,) = _readstruct(f, "i")
        ret = cls(classinfo, memberinfo, library_id)
        ctx.objects[classinfo.ObjectId] = ret
        ret.memberdata = ret.read_members(f, ctx)
        return ret

    def read_members(self, f: io.BufferedReader, ctx: NrbfContext):
        mi = self.MemberTypeInfo
        return [_read_typed_member(f, mi.BinaryTypeEnums[i], mi.AdditionalInfos[i], ctx) for i in range(self.ClassInfo.MemberCount)]


class SystemClassWithMembersAndTypes(namedtuple("SystemClassWithMembersAndTypes", "ClassInfo MemberTypeInfo")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        classinfo = ClassInfo.fromfile(f, ctx)
        memberinfo = MemberTypeInfo.fromfile(f, classinfo, ctx)
        ret = cls(classinfo, memberinfo)
        ctx.objects[classinfo.ObjectId] = ret
        ret.memberdata = ret.read_members(f, ctx)
        return ret

    def read_members(self, f: io.BufferedReader, ctx: NrbfContext):
        mi = self.MemberTypeInfo
        return [_read_typed_member(f, mi.BinaryTypeEnums[i], mi.AdditionalInfos[i], ctx) for i in range(self.ClassInfo.MemberCount)]


class ClassWithId(namedtuple("ClassWithId", "ObjectId MetadataId")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        (obj_id, md_id) = _readstruct(f, "ii")
        ret = cls(obj_id, md_id)
        ctx.objects[obj_id] = ret
        ret.classref = ctx.objects.get(md_id)
        if ret.classref is None:
            # 允许后续再补（少数流里会先引用后定义）
            raise ValueError(f"Missing metadata object id={md_id}")
        ret.memberdata = ret.classref.read_members(f, ctx)
        return ret

    @property
    def ClassInfo(self):
        return self.classref.ClassInfo


class MemberReference(namedtuple("MemberReference", "IdRef")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        return cls(_readstruct(f, "i")[0])


class BinaryObjectString(namedtuple("BinaryObjectString", "ObjectId Value")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        (obj_id,) = _readstruct(f, "i")
        value = _readvarstr(f)
        ret = cls(obj_id, value)
        ctx.objects[obj_id] = ret
        return ret


class ObjectNull(namedtuple("ObjectNull", "")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        return cls()


class ObjectNullMultiple(namedtuple("ObjectNullMultiple", "NullCount")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        return cls(_readstruct(f, "i")[0])


class ObjectNullMultiple256(namedtuple("ObjectNullMultiple256", "NullCount")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        return cls(_readstruct(f, "b")[0])


class ArrayInfo(namedtuple("ArrayInfo", "ObjectId Length")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        return cls(*_readstruct(f, "ii"))


class ArraySinglePrimitive(namedtuple("ArraySinglePrimitive", "ArrayInfo PrimitiveTypeEnum")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        arrinfo = ArrayInfo.fromfile(f, ctx)
        ptype = PrimitiveType(f.read(1)[0])
        ret = cls(arrinfo, ptype)
        ctx.objects[arrinfo.ObjectId] = ret
        ret.arraydata = [_read_primitive(f, ptype) for _ in range(arrinfo.Length)]
        return ret


class ArraySingleObject(namedtuple("ArraySingleObject", "ArrayInfo")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        arrinfo = ArrayInfo.fromfile(f, ctx)
        ret = cls(arrinfo)
        ctx.objects[arrinfo.ObjectId] = ret
        ret.arraydata = []
        i = 0
        while i < arrinfo.Length:
            obj = _read_record(f, ctx)
            if isinstance(obj, (ObjectNullMultiple, ObjectNullMultiple256)):
                i += obj.NullCount
            else:
                i += 1
            ret.arraydata.append(obj)
        return ret


class ArraySingleString(namedtuple("ArraySingleString", "ArrayInfo")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        arrinfo = ArrayInfo.fromfile(f, ctx)
        ret = cls(arrinfo)
        ctx.objects[arrinfo.ObjectId] = ret
        ret.arraydata = []
        i = 0
        while i < arrinfo.Length:
            obj = _read_record(f, ctx)
            if isinstance(obj, (ObjectNullMultiple, ObjectNullMultiple256)):
                i += obj.NullCount
            else:
                i += 1
            ret.arraydata.append(obj)
        return ret


class BinaryArray(namedtuple("BinaryArray", "ObjectId BinaryArrayTypeEnum Rank Lengths LowerBounds TypeEnum AdditionalTypeInfo")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        (obj_id, ba_type, rank) = _readstruct(f, "ibi")
        ba_type = BinaryArrayType(ba_type)
        lengths = _readstruct(f, "i" * rank)
        if ba_type in (BinaryArrayType.SingleOffset, BinaryArrayType.JaggedOffset, BinaryArrayType.RectangularOffset):
            lower = _readstruct(f, "i" * rank)
        else:
            lower = None

        type_enum = BinaryType(f.read(1)[0])
        info = _additional_type_info(f, type_enum, ctx)

        ret = cls(obj_id, ba_type, rank, lengths, lower, type_enum, info)
        ctx.objects[obj_id] = ret
        ret.arraydata = ret.read_arraydata(f, ctx)
        return ret

    def read_arraydata(self, f: io.BufferedReader, ctx: NrbfContext):
        n = 1
        for i in self.Lengths:
            n *= i
        i = 0
        data = []
        while i < n:
            obj = _read_typed_member(f, self.TypeEnum, self.AdditionalTypeInfo, ctx)
            if isinstance(obj, (ObjectNullMultiple, ObjectNullMultiple256)):
                i += obj.NullCount
            else:
                i += 1
            data.append(obj)
        return data


class MemberPrimitiveTyped(namedtuple("MemberPrimitiveTyped", "PrimitiveTypeEnum Value")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        ptype = PrimitiveType(f.read(1)[0])
        val = _read_primitive(f, ptype)
        return cls(ptype, val)


class MessageEnd(namedtuple("MessageEnd", "")):
    @classmethod
    def fromfile(cls, f: io.BufferedReader, ctx: NrbfContext):
        return cls()


_RECORD_CLASSES = {
    RecordType.SerializedStreamHeader: SerializedStreamHeader,
    RecordType.ClassWithId: ClassWithId,
    RecordType.SystemClassWithMembersAndTypes: SystemClassWithMembersAndTypes,
    RecordType.ClassWithMembersAndTypes: ClassWithMembersAndTypes,
    RecordType.BinaryObjectString: BinaryObjectString,
    RecordType.BinaryArray: BinaryArray,
    RecordType.MemberPrimitiveTyped: MemberPrimitiveTyped,
    RecordType.MemberReference: MemberReference,
    RecordType.ObjectNull: ObjectNull,
    RecordType.MessageEnd: MessageEnd,
    RecordType.BinaryLibrary: BinaryLibrary,
    RecordType.ObjectNullMultiple256: ObjectNullMultiple256,
    RecordType.ObjectNullMultiple: ObjectNullMultiple,
    RecordType.ArraySinglePrimitive: ArraySinglePrimitive,
    RecordType.ArraySingleObject: ArraySingleObject,
    RecordType.ArraySingleString: ArraySingleString,
}


def parse_nrbf_file(path: str) -> NrbfContext:
    """
    解析整个文件（可能包含多个 NRBF payload），返回解析上下文（含 objects/libraries）。
    """
    ctx = NrbfContext()
    with open(path, "rb") as fp:
        buf = fp.read()

    f = io.BufferedReader(io.BytesIO(buf))
    while True:
        try:
            b = f.read(1)
            if not b:
                break
            rtype = RecordType(b[0])
            cls = _RECORD_CLASSES.get(rtype)
            if cls is None:
                raise NotImplementedError(f"Unsupported RecordType: {rtype} at {f.tell()-1}")
            _ = cls.fromfile(f, ctx)
        except EOFError:
            break
    return ctx

