"""
rde_io

输入/解析层：读取 Agilent `.d` 与 Qual/PDF 等中间产物，产出结构化数据。
"""

