"""
rde_reporting/report_utils.py

集中管理文本报告输出与格式化函数。

变更：
- 背景离子: 使用 duration_ratio（百分比）而非固定分钟数
- 加合离子: 支持多候选展示（candidate_rank）
- 干扰剔除: 支持 rule2_decimal 类型的格式化
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict, List, Tuple

import pandas as pd

from ..rde_utils.config_utils import load_extractor_config


def extract_report_data(
    *,
    sample_path: str,
    ion_mode: str,
    main_df: pd.DataFrame,
    removed_df: pd.DataFrame,
    bg_df: pd.DataFrame,
    adduct_df: pd.DataFrame,
) -> Dict[str, Any]:
    """
    将 4 个 DataFrame + 元信息转为纯 dict，供 Jinja2 模板渲染。
    """
    import re as _re

    cfg = load_extractor_config()
    bg_cfg = cfg.get("background_ions") if isinstance(cfg.get("background_ions"), dict) else {}
    min_ratio = float(bg_cfg.get("filter_min_duration_ratio", 0.5) or 0.5)
    min_avg = float(bg_cfg.get("filter_min_avg_intensity", 15000.0) or 15000.0)
    max_pr = float(bg_cfg.get("filter_max_peak_ratio", 100.0) or 100.0)

    # --- 背景离子 ---
    background_ions: List[Dict[str, Any]] = []
    bg_label = "filtered"  # "filtered" or "top5_fallback"
    if bg_df is not None and not bg_df.empty:
        df2 = bg_df.copy()
        if "duration_ratio" in df2.columns:
            df2["duration_ratio"] = pd.to_numeric(df2["duration_ratio"], errors="coerce")
        if "avg_intensity" in df2.columns:
            df2["avg_intensity"] = pd.to_numeric(df2["avg_intensity"], errors="coerce")
        if "score" in df2.columns:
            df2["score"] = pd.to_numeric(df2["score"], errors="coerce")
        if "peak_ratio" in df2.columns:
            df2["peak_ratio"] = pd.to_numeric(df2["peak_ratio"], errors="coerce")

        if "duration_ratio" in df2.columns and "avg_intensity" in df2.columns:
            df2 = df2[(df2["duration_ratio"].notna()) & (df2["avg_intensity"].notna())].copy()
            df2 = df2[(df2["duration_ratio"] >= float(min_ratio)) & (df2["avg_intensity"] >= float(min_avg))].copy()
            if "peak_ratio" in df2.columns:
                df2 = df2[df2["peak_ratio"] <= float(max_pr)].copy()

        if df2.empty:
            bg_label = "top5_fallback"
            df2 = bg_df.copy().head(5)

        for _i, r in df2.iterrows():
            try:
                pr_val = r.get("peak_ratio")
                background_ions.append({
                    "mz": float(r.get("mz")),
                    "score": float(r.get("score")),
                    "duration_ratio": float(r.get("duration_ratio")),
                    "duration_min": float(r.get("duration_min")) if r.get("duration_min") is not None and pd.notna(r.get("duration_min")) else None,
                    "avg_intensity": float(r.get("avg_intensity")),
                    "max_intensity": float(r.get("max_intensity")),
                    "peak_ratio": float(pr_val) if pr_val is not None and pd.notna(pr_val) else None,
                })
            except Exception:
                background_ions.append({"raw": str(dict(r))})

    # --- 干扰剔除统计 ---
    removed_summary: Dict[str, Any] = {"total": 0, "by_source": {}}
    if removed_df is not None and not removed_df.empty:
        removed_summary["total"] = len(removed_df)
        try:
            cnts = removed_df.groupby("source").size().to_dict()
            removed_summary["by_source"] = {str(k): int(v) for k, v in cnts.items()}
        except Exception:
            pass

    # --- 峰级数据 ---
    peaks: List[Dict[str, Any]] = []
    removed_map: Dict[tuple, List[Dict[str, Any]]] = {}
    if removed_df is not None and not removed_df.empty:
        for _i, rr in removed_df.iterrows():
            key = (str(rr.get("RT") or ""), str(rr.get("peak_id") or ""))
            removed_map.setdefault(key, []).append(dict(rr))

    if main_df is not None and not main_df.empty:
        for _i, r in main_df.iterrows():
            peak_id = str(r.get("peak_id") or "")
            rt = str(r.get("RT") or "")
            peak_idx = r.get("peak_index")
            try:
                peak_idx_i = int(peak_idx) if peak_idx is not None and pd.notna(peak_idx) else (_i + 1)
            except Exception:
                peak_idx_i = _i + 1

            uv_start = r.get("UV_Start")
            uv_end = r.get("UV_End")
            uv_start_f = float(uv_start) if uv_start is not None and pd.notna(uv_start) else None
            uv_end_f = float(uv_end) if uv_end is not None and pd.notna(uv_end) else None

            # 各波长信息
            area_cols = sorted(
                [c for c in r.index if _re.match(r"^Area_\d+$", str(c))],
                key=lambda c: int(str(c).split("_")[1]),
            )
            wavelengths: List[Dict[str, Any]] = []
            for ac in area_cols:
                wl = str(ac).split("_")[1]
                area_val = r.get(ac)
                height_val = r.get(f"Height_{wl}")
                if area_val is not None and pd.notna(area_val):
                    wl_info: Dict[str, Any] = {"nm": int(wl), "area": float(area_val)}
                    if height_val is not None and pd.notna(height_val):
                        wl_info["height"] = float(height_val)
                    area_sum_val = r.get(f"Area_Sum_{wl}")
                    if area_sum_val is not None and pd.notna(area_sum_val):
                        wl_info["area_sum_pct"] = float(area_sum_val)
                    wavelengths.append(wl_info)

            # MS1 info
            ms1_info = {
                "scan_id": r.get("ms1_scan_id"),
                "rt_min": r.get("ms1_rt_min"),
                "base_mz": r.get("ms1_base_mz"),
                "base_abund": r.get("ms1_base_abund"),
            }

            # MS1 top5
            ion_mode_upper = str(ion_mode).upper()
            if ion_mode_upper.startswith("POS"):
                ion_mode_display = "POS"
            elif ion_mode_upper.startswith("NEG"):
                ion_mode_display = "NEG"
            else:
                ion_mode_display = ion_mode_upper

            t5_raw = str(r.get("ms1_top5_filtered_rel", "") or "").strip()
            t5_tokens = [x for x in (t5_raw.split("|") if "|" in t5_raw else t5_raw.split(",") if "," in t5_raw else [t5_raw]) if x.strip()] if t5_raw else []

            dedup_note_raw = str(r.get("ms1_dedup_note") or "").strip()
            dup_map: Dict[int, str] = {}
            if dedup_note_raw:
                for seg in dedup_note_raw.split("|"):
                    seg = seg.strip()
                    if ":" in seg:
                        try:
                            idx_str, label = seg.split(":", 1)
                            dup_map[int(idx_str)] = label
                        except Exception:
                            pass

            ms1_top5: List[Dict[str, Any]] = []
            for j, t in enumerate(t5_tokens, start=1):
                t = t.strip()
                if "@" not in t:
                    continue
                a, b = t.split("@", 1)
                try:
                    mz = float(a)
                    rel = float(b)
                except Exception:
                    continue
                entry: Dict[str, Any] = {"mz": mz, "rel_pct": rel * 100.0}
                if j in dup_map:
                    entry["is_duplicate"] = True
                    entry["dup_from"] = dup_map[j]
                else:
                    entry["is_duplicate"] = False
                ms1_top5.append(entry)

            # rule2_decimal
            r2_count = r.get("rule2_decimal_removed_count")
            r2_mz = r.get("rule2_decimal_removed_mz")
            rule2: Dict[str, Any] = {"count": 0, "mz_list": ""}
            if r2_count is not None and pd.notna(r2_count) and int(r2_count) > 0:
                rule2 = {"count": int(r2_count), "mz_list": str(r2_mz or "")}

            # 干扰剔除明细
            rem_list = removed_map.get((rt, peak_id), [])
            removed_detail: List[Dict[str, Any]] = []
            by_src: Dict[str, List[Dict[str, Any]]] = {}
            for x in rem_list:
                by_src.setdefault(str(x.get("source") or ""), []).append(x)
            for src, xs in by_src.items():
                items = []
                for x in xs[:30]:
                    try:
                        rmz = float(x.get("removed_mz"))
                        rit = float(x.get("removed_intensity"))
                    except Exception:
                        items.append({"text": str(x)})
                        continue
                    item: Dict[str, Any] = {"removed_mz": rmz, "removed_intensity": rit, "source": src}
                    if src == "rule2_decimal":
                        from ..rde_analysis.raw_blank_core import _first_decimal_digit
                        item["first_decimal"] = _first_decimal_digit(rmz)
                    else:
                        mmz = x.get("matched_mz")
                        item["matched_mz"] = float(mmz) if mmz is not None and pd.notna(mmz) else None
                        ppm_err = x.get("ppm_error")
                        item["ppm_error"] = float(ppm_err) if ppm_err is not None and pd.notna(ppm_err) else None
                    items.append(item)
                removed_detail.append({"source": src, "count": len(xs), "entries": items, "truncated": len(xs) > 30})

            # MS2
            ms2_raw = str(r.get("ms2_frag_top5") or "").strip()
            ms2_fragments: List[Dict[str, Any]] = []
            if ms2_raw:
                parts = [p.strip() for p in ms2_raw.split("||") if p.strip()]
                for p in parts:
                    prec = ""
                    scan = ""
                    frag_str = ""
                    for seg in p.split(";"):
                        seg2 = seg.strip()
                        if seg2.startswith("prec="):
                            prec = seg2.split("=", 1)[1].strip()
                        elif seg2.startswith("scan="):
                            scan = seg2.split("=", 1)[1].strip()
                        elif "frag_top" in seg2 and "=" in seg2:
                            frag_str = seg2.split("=", 1)[1].strip()
                    frags = []
                    if frag_str:
                        for ft in frag_str.split("|"):
                            ft = ft.strip()
                            if "@" not in ft:
                                continue
                            a2, b2 = ft.split("@", 1)
                            try:
                                frags.append({"mz": float(a2), "rel_pct": float(b2) * 100.0})
                            except Exception:
                                continue
                    ms2_fragments.append({
                        "precursor_mz": prec,
                        "scan_id": scan,
                        "fragments": frags,
                    })

            # 加合离子
            adducts: List[Dict[str, Any]] = []
            if adduct_df is not None and not adduct_df.empty:
                try:
                    hit_rows = adduct_df[
                        (adduct_df["RT"].astype(str) == rt) & (adduct_df["peak_id"].astype(str) == peak_id)
                    ].copy()
                    if "candidate_rank" in hit_rows.columns:
                        hit_rows = hit_rows.sort_values("candidate_rank")
                except Exception:
                    hit_rows = pd.DataFrame()
                if hit_rows is not None and not hit_rows.empty:
                    def _opt_float(row, col):
                        v = row.get(col)
                        return float(v) if v is not None and pd.notna(v) else None

                    for _, rr0 in hit_rows.iterrows():
                        ad: Dict[str, Any] = {
                            "candidate_rank": rr0.get("candidate_rank", "?"),
                            "m_mz": _opt_float(rr0, "M_mz"),
                            "hit_2m1": bool(rr0.get("hit_2M+1")),
                            "mz_2m1": _opt_float(rr0, "2M+1_mz"),
                            "ppm_2m1": _opt_float(rr0, "ppm_err_2m1"),
                            "hit_36": bool(rr0.get("hit_M+36")),
                            "mz_36": _opt_float(rr0, "M+36_mz"),
                            "ppm_36": _opt_float(rr0, "ppm_err_36"),
                            "hit_46": bool(rr0.get("hit_M+46")),
                            "mz_46": _opt_float(rr0, "M+46_mz"),
                            "ppm_46": _opt_float(rr0, "ppm_err_46"),
                            "hit_m36": bool(rr0.get("hit_M-36")),
                            "mz_m36": _opt_float(rr0, "M-36_mz"),
                            "ppm_m36": _opt_float(rr0, "ppm_err_m36"),
                            "hit_m46": bool(rr0.get("hit_M-46")),
                            "mz_m46": _opt_float(rr0, "M-46_mz"),
                            "ppm_m46": _opt_float(rr0, "ppm_err_m46"),
                        }
                        adducts.append(ad)

            peaks.append({
                "peak_index": peak_idx_i,
                "peak_id": peak_id,
                "rt": rt,
                "uv_start": uv_start_f,
                "uv_end": uv_end_f,
                "wavelengths": wavelengths,
                "ion_mode": ion_mode_display,
                "ms1_info": ms1_info,
                "ms1_top5": ms1_top5,
                "has_duplicates": bool(dup_map),
                "signal_count": len(ms1_top5),
                "rule2": rule2,
                "removed": removed_detail,
                "ms2_fragments": ms2_fragments,
                "adducts": adducts,
            })

    return {
        "sample_path": str(sample_path),
        "ion_mode": ion_mode,
        "min_duration_ratio": min_ratio,
        "min_avg_intensity": min_avg,
        "max_peak_ratio": max_pr,
        "background_ions": background_ions,
        "bg_label": bg_label,
        "removed_summary": removed_summary,
        "peaks": peaks,
    }


def _wrap_list_tokens(tokens: List[str], *, prefix: str = "  ", width: int = 120) -> str:
    if not tokens:
        return prefix + "(空)"
    out: List[str] = []
    cur = prefix
    for t in tokens:
        t2 = str(t)
        if len(cur) + len(t2) + 1 > width and cur != prefix:
            out.append(cur.rstrip())
            cur = prefix + t2 + " "
        else:
            cur += t2 + " "
    if cur.strip():
        out.append(cur.rstrip())
    return "\n".join(out)


def _wrap_pipe_tokens(tokens: List[str], *, prefix: str = "  ", width: int = 120) -> str:
    if not tokens:
        return prefix + "(空)"
    out: List[str] = []
    cur = prefix
    for i, t in enumerate(tokens):
        t2 = str(t)
        seg = ("|" if i > 0 and cur != prefix else "") + t2
        if len(cur) + len(seg) > width and cur != prefix:
            out.append(cur.rstrip("|"))
            cur = prefix + t2
        else:
            cur += seg
    if cur.strip():
        out.append(cur.rstrip("|"))
    return "\n".join(out)


def _format_mz_rel_lines(tokens: List[str], *, indent: str = "  ", dup_map: dict | None = None) -> List[str]:
    """dup_map: {序号(1-based): '重复@峰#N'} 或 None"""
    if not tokens:
        return [indent + "(空)"]
    parsed: List[Tuple[float, float]] = []
    for t in tokens:
        s = str(t).strip()
        if not s:
            continue
        if "@" not in s:
            continue
        a, b = s.split("@", 1)
        try:
            mz = float(a)
            rel = float(b)
        except Exception:
            continue
        parsed.append((mz, rel))
    if not parsed:
        return [indent + "(空)"]
    mz_w = max(8, max(len(f"{mz:.4f}") for mz, _ in parsed))
    out = [indent + f"{'序号':>2}  {'m/z':<{mz_w}}  {'%':>6}"]
    for i, (mz, rel) in enumerate(parsed, start=1):
        pct = rel * 100.0
        suffix = ""
        if dup_map and i in dup_map:
            suffix = f"  ({dup_map[i]})"
        out.append(indent + f"{i:>2}  {mz:<{mz_w}.4f}  {pct:>6.1f}%{suffix}")
    return out


def _format_ms2_summary(ms2_summary: str) -> List[str]:
    s = (ms2_summary or "").strip()
    if not s:
        return ["  (无/未匹配到MS2)"]
    parts = [p.strip() for p in s.split("||") if p.strip()]
    lines: List[str] = []
    for p in parts:
        prec = ""
        scan = ""
        frag = ""
        for seg in p.split(";"):
            seg2 = seg.strip()
            if seg2.startswith("prec="):
                prec = seg2.split("=", 1)[1].strip()
            elif seg2.startswith("scan="):
                scan = seg2.split("=", 1)[1].strip()
            elif "frag_top" in seg2 and "=" in seg2:
                frag = seg2.split("=", 1)[1].strip()
        header = f"  前体 m/z={prec}" + (f"  (scan={scan})" if scan else "")
        lines.append(header)
        frag_tokens = [x for x in frag.split("|") if x] if frag else []
        for ln in _format_mz_rel_lines(frag_tokens, indent="    "):
            lines.append(ln)
    return lines


def _tokens_from_ms1_str(s: object) -> List[str]:
    if s is None:
        return []
    ss = str(s).strip()
    if not ss:
        return []
    if "|" in ss:
        return [x for x in ss.split("|") if x]
    if "," in ss:
        return [x for x in ss.split(",") if x]
    return [ss]


def _format_removed_detail(x: Dict[str, object]) -> str:
    """格式化一条剔除明细，区分不同来源。"""
    src = str(x.get("source") or "")
    try:
        rmz = float(x.get("removed_mz"))
        rit = float(x.get("removed_intensity"))
    except Exception:
        return str(x)

    if src == "rule2_decimal":
        from ..rde_analysis.raw_blank_core import _first_decimal_digit
        d1 = _first_decimal_digit(rmz)
        return f"{rmz:.4f}@{rit:.0f} [小数首位={d1}]"

    # blank / background
    try:
        mmz = x.get("matched_mz")
        mmz_s = f"{float(mmz):.4f}" if mmz is not None else "?"
    except Exception:
        mmz_s = "?"
    ppm_err = x.get("ppm_error")
    ppm_s = ""
    if ppm_err is not None:
        try:
            if pd.notna(ppm_err):
                ppm_s = f"{float(ppm_err):.1f}ppm"
        except Exception:
            pass
    return f"{rmz:.4f}@{rit:.0f}->{mmz_s}({ppm_s})"


def _write_human_readable_report(
    *,
    out_path: Path,
    sample_path: Path,
    analyzer: Any,
    args: argparse.Namespace,
    main_df: pd.DataFrame,
    removed_df: pd.DataFrame,
    bg_df: pd.DataFrame,
    adduct_df: pd.DataFrame,
) -> None:
    lines: List[str] = []
    lines.append("=" * 100)
    lines.append("raw_blank_analysis_v2 文本报告")
    lines.append("=" * 100)
    lines.append(f"样品: {sample_path}")
    lines.append(f"样品离子模式: {getattr(analyzer, 'sample_ion_mode', 'unknown')}")

    # 220nm 峰面积占比统计
    _sample_data = getattr(analyzer, "sample_data", None) or {}
    _dad220 = _sample_data.get("DAD_Peaks_220nm")
    if _dad220 is not None and isinstance(_dad220, pd.DataFrame) and not _dad220.empty and "Area_Sum" in _dad220.columns:
        _as = pd.to_numeric(_dad220["Area_Sum"], errors="coerce")
        _total_peaks = int((_as.notna()).sum())
        _gt5 = int((_as > 5.0).sum())
        lines.append(f"220nm色谱峰统计: 共{_total_peaks}个峰, 面积占比>5%的峰有{_gt5}个")
    lines.append("")

    lines.append("-" * 100)
    # 背景离子：按阈值全量输出
    cfg = load_extractor_config()
    bg_cfg = cfg.get("background_ions") if isinstance(cfg.get("background_ions"), dict) else {}
    min_ratio = float(bg_cfg.get("filter_min_duration_ratio", 0.5) or 0.5)
    min_avg = float(bg_cfg.get("filter_min_avg_intensity", 15000.0) or 15000.0)
    max_pr = float(bg_cfg.get("filter_max_peak_ratio", 100.0) or 100.0)
    lines.append(f"背景离子（持续时间比≥{min_ratio:.0%} 且 平均强度≥{min_avg:g} 且 peak_ratio≤{max_pr:g}）:")
    if bg_df is None or bg_df.empty:
        lines.append("  (空：未检出或未启用)")
    else:
        df2 = bg_df.copy()
        if "duration_ratio" in df2.columns:
            df2["duration_ratio"] = pd.to_numeric(df2["duration_ratio"], errors="coerce")
        if "avg_intensity" in df2.columns:
            df2["avg_intensity"] = pd.to_numeric(df2["avg_intensity"], errors="coerce")
        if "score" in df2.columns:
            df2["score"] = pd.to_numeric(df2["score"], errors="coerce")
        if "peak_ratio" in df2.columns:
            df2["peak_ratio"] = pd.to_numeric(df2["peak_ratio"], errors="coerce")

        # 先筛选出满足持续比和平均强度条件的候选
        df_candidates = df2.copy()
        if "duration_ratio" in df2.columns and "avg_intensity" in df2.columns:
            df_candidates = df2[(df2["duration_ratio"].notna()) & (df2["avg_intensity"].notna())].copy()
            df_candidates = df_candidates[(df_candidates["duration_ratio"] >= float(min_ratio)) & (df_candidates["avg_intensity"] >= float(min_avg))].copy()

        # 分为：保留的背景离子 vs 被排除的（peak_ratio 过高）
        if "peak_ratio" in df_candidates.columns:
            df_kept = df_candidates[df_candidates["peak_ratio"] <= float(max_pr)].copy()
            df_excluded = df_candidates[df_candidates["peak_ratio"] > float(max_pr)].copy()
        else:
            df_kept = df_candidates.copy()
            df_excluded = pd.DataFrame()

        if df_kept.empty:
            lines.append("  (空：未找到满足阈值的背景离子)")
            lines.append("")
            lines.append("最可能背景离子（持续时间×平均强度 TOP 5）:")
            df_kept = bg_df.copy().head(5)

        for _i, r in df_kept.iterrows():
            try:
                mz0 = float(r.get("mz"))
                dur = r.get("duration_min")
                dr = float(r.get("duration_ratio"))
                mx = float(r.get("max_intensity"))
                av = float(r.get("avg_intensity"))
                sc = float(r.get("score"))
                pr = r.get("peak_ratio")
                dur_s = f"{float(dur):.2f}min" if dur is not None and pd.notna(dur) else ""
                pr_s = f" | peak_ratio={float(pr):.1f}" if pr is not None and pd.notna(pr) else ""
                lines.append(
                    f"  m/z={mz0:.4f} | score={sc:.2f} | 持续比={dr:.0%}"
                    + (f"({dur_s})" if dur_s else "")
                    + f" | 平均强度={av:.0f} | maxI={mx:.0f}"
                    + pr_s
                )
            except Exception:
                lines.append(f"  {dict(r)}")

        # 显示被排除的离子（peak_ratio 过高，疑似目标离子）
        if df_excluded is not None and not df_excluded.empty:
            lines.append("")
            lines.append(f"已排除（peak_ratio>{max_pr:g}，疑似目标离子）:")
            for _i, r in df_excluded.iterrows():
                try:
                    mz0 = float(r.get("mz"))
                    dur = r.get("duration_min")
                    dr = float(r.get("duration_ratio"))
                    mx = float(r.get("max_intensity"))
                    av = float(r.get("avg_intensity"))
                    sc = float(r.get("score"))
                    pr = r.get("peak_ratio")
                    dur_s = f"{float(dur):.2f}min" if dur is not None and pd.notna(dur) else ""
                    pr_s = f" | peak_ratio={float(pr):.1f}" if pr is not None and pd.notna(pr) else ""
                    lines.append(
                        f"  m/z={mz0:.4f} | score={sc:.2f} | 持续比={dr:.0%}"
                        + (f"({dur_s})" if dur_s else "")
                        + f" | 平均强度={av:.0f} | maxI={mx:.0f}"
                        + pr_s
                    )
                except Exception:
                    lines.append(f"  {dict(r)}")
    lines.append("")

    lines.append("-" * 100)
    lines.append("干扰剔除统计（按来源）:")
    if removed_df is None or removed_df.empty:
        lines.append("  (空：本次未剔除任何离子；可能容差很小或空白池/背景池未命中)")
    else:
        lines.append(f"  总剔除条数: {len(removed_df)}")
        try:
            cnts = removed_df.groupby("source").size().to_dict()
        except Exception:
            cnts = {}
        for k, v in (cnts or {}).items():
            lines.append(f"  - {k}: {v}")
    lines.append("")

    lines.append("=" * 100)
    lines.append("峰级详细信息（按TopK输出顺序）")
    lines.append("=" * 100)

    if main_df is None or main_df.empty:
        lines.append("(主结果为空)")
    else:
        removed_map: Dict[Tuple[str, str], List[Dict[str, object]]] = {}
        if removed_df is not None and not removed_df.empty:
            for _i, rr in removed_df.iterrows():
                key = (str(rr.get("RT") or ""), str(rr.get("peak_id") or ""))
                removed_map.setdefault(key, []).append(dict(rr))

        for _i, r in main_df.iterrows():
            peak_id = str(r.get("peak_id") or "")
            rt = str(r.get("RT") or "")
            peak_idx = r.get("peak_index")
            try:
                peak_idx_i = int(peak_idx) if peak_idx is not None and pd.notna(peak_idx) else (_i + 1)
            except Exception:
                peak_idx_i = _i + 1

            uv_start = r.get("UV_Start")
            uv_end = r.get("UV_End")
            uv_start_s = ""
            uv_end_s = ""
            try:
                if uv_start is not None and pd.notna(uv_start):
                    uv_start_s = f"{float(uv_start):.4f}"
            except Exception:
                uv_start_s = ""
            try:
                if uv_end is not None and pd.notna(uv_end):
                    uv_end_s = f"{float(uv_end):.4f}"
            except Exception:
                uv_end_s = ""
            rng = f" ({uv_start_s}-{uv_end_s})" if (uv_start_s and uv_end_s) else ""

            lines.append("")
            lines.append(f"===== UV峰#{peak_idx_i}: RT={rt}min{rng} =====")

            # UV峰信息
            lines.append("[UV峰信息]")
            import re as _re_uv
            area_cols = sorted(
                [c for c in r.index if _re_uv.match(r"^Area_\d+$", str(c))],
                key=lambda c: int(str(c).split("_")[1]),
            )
            any_uv = False
            for ac in area_cols:
                wl = str(ac).split("_")[1]
                area_val = r.get(ac)
                height_val = r.get(f"Height_{wl}")
                if area_val is not None and pd.notna(area_val):
                    any_uv = True
                    h_s = ""
                    try:
                        if height_val is not None and pd.notna(height_val):
                            h_s = f", 峰高={float(height_val):.3g}"
                    except Exception:
                        h_s = ""
                    as_s = ""
                    area_sum_val = r.get(f"Area_Sum_{wl}")
                    try:
                        if area_sum_val is not None and pd.notna(area_sum_val):
                            as_s = f", 占比={float(area_sum_val):.2f}%"
                    except Exception:
                        as_s = ""
                    lines.append(f"  {wl}nm: 面积={float(area_val):.6g}{h_s}{as_s}")
            if not any_uv:
                lines.append("  (无可用UV峰信息)")

            # MS信号分析
            lines.append("[MS信号分析]")
            ion_mode = str(getattr(analyzer, "sample_ion_mode", "unknown")).upper()
            if ion_mode.startswith("POS"):
                ion_mode = "POS"
            elif ion_mode.startswith("NEG"):
                ion_mode = "NEG"
            t5 = _tokens_from_ms1_str(r.get("ms1_top5_filtered_rel", ""))
            lines.append(f"  信号总数: {len(t5)}个")
            lines.append(f"  离子模式: {ion_mode}")
            _scan_count = r.get("ms1_scan_count")
            try:
                _scan_count = int(_scan_count) if _scan_count is not None and pd.notna(_scan_count) else 1
            except Exception:
                _scan_count = 1
            lines.append(
                f"  MS1: scan_id={r.get('ms1_scan_id')}, rt_min={r.get('ms1_rt_min')}, base_mz={r.get('ms1_base_mz')}, base_abund={r.get('ms1_base_abund')}"
            )
            if _scan_count > 1:
                lines.append(f"  ({_scan_count}个scan平均)")

            # 过滤后MS1 top（跨峰去重）
            dedup_note_raw = str(r.get("ms1_dedup_note") or "").strip()
            dup_map: dict = {}
            if dedup_note_raw:
                for seg in dedup_note_raw.split("|"):
                    seg = seg.strip()
                    if ":" in seg:
                        try:
                            idx_str, label = seg.split(":", 1)
                            dup_map[int(idx_str)] = label
                        except Exception:
                            pass
            if dup_map:
                lines.append("[过滤后MS1 top5]  (* 去重：与前序UV峰重复的m/z已标注)")
            else:
                lines.append("[过滤后MS1 top5]")
            for ln in _format_mz_rel_lines(t5, indent="  ", dup_map=dup_map):
                lines.append(ln)

            # rule2_decimal 剔除摘要
            r2_count = r.get("rule2_decimal_removed_count")
            r2_mz = r.get("rule2_decimal_removed_mz")
            if r2_count is not None and pd.notna(r2_count) and int(r2_count) > 0:
                lines.append(f"[rule2_decimal 剔除] 共{int(r2_count)}个")
                if r2_mz:
                    lines.append(f"  m/z: {r2_mz}")

            # 干扰剔除明细
            rem = removed_map.get((rt, peak_id), [])
            if rem:
                lines.append("[干扰剔除明细]")
                by_src: Dict[str, List[Dict[str, object]]] = {}
                for x in rem:
                    by_src.setdefault(str(x.get("source") or ""), []).append(x)
                for src, xs in by_src.items():
                    lines.append(f"  来源={src}（{len(xs)}条）:")
                    toks: List[str] = []
                    for x in xs[:30]:
                        toks.append(_format_removed_detail(x))
                    lines.append(_wrap_list_tokens(toks, prefix="    "))
                    if len(xs) > 30:
                        lines.append(f"    ... 省略 {len(xs) - 30} 条")
            else:
                lines.append("[干扰剔除明细]")
                lines.append("  (无)")

            ms2 = str(r.get("ms2_frag_top5") or "").strip()
            lines.append("[MS2碎片（前五个）]")
            for ln in _format_ms2_summary(ms2):
                lines.append(ln)

            # 加合离子（峰级）— 支持多候选 (2M+1, M+36, M+46, M-36, M-46)
            if adduct_df is not None and not adduct_df.empty:
                try:
                    hit_rows = adduct_df[
                        (adduct_df["RT"].astype(str) == rt) & (adduct_df["peak_id"].astype(str) == peak_id)
                    ].copy()
                    if "candidate_rank" in hit_rows.columns:
                        hit_rows = hit_rows.sort_values("candidate_rank")
                except Exception:
                    hit_rows = pd.DataFrame()
                if hit_rows is not None and not hit_rows.empty:
                    lines.append(f"[加合离子（M+36/M+46/2M+1/M-36/M-46）— {len(hit_rows)}个候选]")

                    def _fmt_mz(val):
                        if val is None or (isinstance(val, float) and not pd.notna(val)):
                            return ""
                        return f"{float(val):.4f}"

                    def _fmt_ppm(val):
                        if val is None:
                            return ""
                        try:
                            if pd.notna(val):
                                return f" ({float(val):.1f}ppm)"
                        except Exception:
                            pass
                        return ""

                    for _, rr0 in hit_rows.iterrows():
                        rank = rr0.get("candidate_rank", "?")
                        m_s = _fmt_mz(rr0.get("M_mz"))
                        lines.append(f"  候选#{rank}: M={m_s}")
                        lines.append(f"    M+36: {'命中' if bool(rr0.get('hit_M+36')) else '未命中'} {_fmt_mz(rr0.get('M+36_mz'))}{_fmt_ppm(rr0.get('ppm_err_36'))}")
                        lines.append(f"    M+46: {'命中' if bool(rr0.get('hit_M+46')) else '未命中'} {_fmt_mz(rr0.get('M+46_mz'))}{_fmt_ppm(rr0.get('ppm_err_46'))}")
                        lines.append(f"    2M+1: {'命中' if bool(rr0.get('hit_2M+1')) else '未命中'} {_fmt_mz(rr0.get('2M+1_mz'))}{_fmt_ppm(rr0.get('ppm_err_2m1'))}")
                        lines.append(f"    M-36: {'命中' if bool(rr0.get('hit_M-36')) else '未命中'} {_fmt_mz(rr0.get('M-36_mz'))}{_fmt_ppm(rr0.get('ppm_err_m36'))}")
                        lines.append(f"    M-46: {'命中' if bool(rr0.get('hit_M-46')) else '未命中'} {_fmt_mz(rr0.get('M-46_mz'))}{_fmt_ppm(rr0.get('ppm_err_m46'))}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_report_from_template(template_str: str, data: Dict[str, Any]) -> str:
    """用 Jinja2 模板渲染报告文本。"""
    import re
    from jinja2 import Environment

    env = Environment(keep_trailing_newline=True)
    tpl = env.from_string(template_str)
    rendered = tpl.render(**data)
    # 清理连续空行（最多保留 1 个）
    rendered = re.sub(r"\n{3,}", "\n\n", rendered)
    return rendered


def _write_human_readable_report_v2(
    *,
    out_path: Path,
    sample_path: Path,
    analyzer: Any,
    args: argparse.Namespace,
    main_df: pd.DataFrame,
    removed_df: pd.DataFrame,
    bg_df: pd.DataFrame,
    adduct_df: pd.DataFrame,
    template_str: str | None = None,
) -> None:
    """模板驱动的报告生成。如果传入 template_str 则用它渲染，否则走原有硬编码逻辑。"""
    if template_str is None:
        return _write_human_readable_report(
            out_path=out_path,
            sample_path=sample_path,
            analyzer=analyzer,
            args=args,
            main_df=main_df,
            removed_df=removed_df,
            bg_df=bg_df,
            adduct_df=adduct_df,
        )

    ion_mode = str(getattr(analyzer, "sample_ion_mode", "unknown"))
    data = extract_report_data(
        sample_path=str(sample_path),
        ion_mode=ion_mode,
        main_df=main_df,
        removed_df=removed_df,
        bg_df=bg_df,
        adduct_df=adduct_df,
    )
    rendered = render_report_from_template(template_str, data)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(rendered, encoding="utf-8")


write_human_readable_report = _write_human_readable_report


# ---------------------------------------------------------------------------
# HTML 报告生成
# ---------------------------------------------------------------------------

def _mz_btn(mz_val: float) -> str:
    """Render an m/z value with an EIC button."""
    s = f"{mz_val:.4f}"
    return (
        f'<span class="mz-link">{s}'
        f'<button class="eic-btn" data-mz="{s}" title="查看EIC">EIC</button>'
        f'</span>'
    )


def render_html_report(
    *,
    out_path: Path,
    sample_path: str,
    ion_mode: str,
    main_df: pd.DataFrame,
    removed_df: pd.DataFrame,
    bg_df: pd.DataFrame,
    adduct_df: pd.DataFrame,
) -> None:
    """Generate a self-contained HTML report with EIC buttons."""
    import html as _html

    data = extract_report_data(
        sample_path=sample_path,
        ion_mode=ion_mode,
        main_df=main_df,
        removed_df=removed_df,
        bg_df=bg_df,
        adduct_df=adduct_df,
    )

    parts: List[str] = []
    _a = parts.append

    # ---- Head ----
    _a('<!DOCTYPE html>')
    _a('<html lang="zh-CN">')
    _a('<head>')
    _a('<meta charset="utf-8">')
    _a('<meta name="viewport" content="width=device-width,initial-scale=1">')
    _a(f'<title>分析报告 — {_html.escape(str(sample_path))}</title>')
    _a('<style>')
    _a(_HTML_REPORT_CSS)
    _a('</style>')
    _a('</head>')
    _a('<body>')

    # ---- Header ----
    _a('<div class="report-wrap">')
    _a('<h1>raw_blank_analysis_v2 分析报告</h1>')
    _a(f'<p class="meta-line"><strong>样品:</strong> {_html.escape(str(data["sample_path"]))}</p>')
    _a(f'<p class="meta-line"><strong>离子模式:</strong> {_html.escape(str(data["ion_mode"]))}</p>')

    # ---- Background ions ----
    bg_ions = data.get("background_ions", [])
    _a('<section class="section">')
    _a(f'<h2>背景离子（{len(bg_ions)} 个）</h2>')
    if bg_ions:
        _a('<table><thead><tr><th>m/z</th><th>score</th><th>持续比</th><th>平均强度</th><th>最大强度</th><th>peak_ratio</th></tr></thead><tbody>')
        for bi in bg_ions:
            mz = bi.get("mz")
            sc = bi.get("score")
            dr = bi.get("duration_ratio")
            av = bi.get("avg_intensity")
            mx = bi.get("max_intensity")
            pr = bi.get("peak_ratio")
            _a(f'<tr><td>{_mz_btn(mz) if mz else ""}</td>'
               f'<td>{sc:.2f}</td>'
               f'<td>{dr:.0%}</td>'
               f'<td>{av:,.0f}</td>'
               f'<td>{mx:,.0f}</td>'
               f'<td>{f"{pr:.1f}" if pr is not None else "—"}</td></tr>')
        _a('</tbody></table>')
    else:
        _a('<p class="muted">未检出背景离子</p>')
    _a('</section>')

    # ---- Excluded ions (high peak_ratio) ----
    # Re-derive from bg_df since extract_report_data doesn't expose excluded list
    excluded_ions: List[Dict[str, Any]] = []
    if bg_df is not None and not bg_df.empty:
        _bg2 = bg_df.copy()
        for col in ("duration_ratio", "avg_intensity", "peak_ratio", "score"):
            if col in _bg2.columns:
                _bg2[col] = pd.to_numeric(_bg2[col], errors="coerce")
        if "duration_ratio" in _bg2.columns and "avg_intensity" in _bg2.columns:
            _cand = _bg2[(_bg2["duration_ratio"] >= data["min_duration_ratio"]) & (_bg2["avg_intensity"] >= data["min_avg_intensity"])].copy()
            if "peak_ratio" in _cand.columns:
                _excl = _cand[_cand["peak_ratio"] > data["max_peak_ratio"]]
                for _, _er in _excl.iterrows():
                    excluded_ions.append({
                        "mz": float(_er.get("mz")),
                        "score": float(_er.get("score")),
                        "duration_ratio": float(_er.get("duration_ratio")),
                        "avg_intensity": float(_er.get("avg_intensity")),
                        "max_intensity": float(_er.get("max_intensity")),
                        "peak_ratio": float(_er.get("peak_ratio")) if pd.notna(_er.get("peak_ratio")) else None,
                    })

    if excluded_ions:
        _a('<section class="section">')
        _a(f'<h2>已排除（peak_ratio&gt;{data["max_peak_ratio"]:.0f}，疑似目标离子，{len(excluded_ions)} 个）</h2>')
        _a('<table><thead><tr><th>m/z</th><th>score</th><th>持续比</th><th>平均强度</th><th>最大强度</th><th>peak_ratio</th></tr></thead><tbody>')
        for ei in excluded_ions:
            _a(f'<tr><td>{_mz_btn(ei["mz"])}</td>'
               f'<td>{ei["score"]:.2f}</td>'
               f'<td>{ei["duration_ratio"]:.0%}</td>'
               f'<td>{ei["avg_intensity"]:,.0f}</td>'
               f'<td>{ei["max_intensity"]:,.0f}</td>'
               f'<td>{"%.1f" % ei["peak_ratio"] if ei["peak_ratio"] is not None else "—"}</td></tr>')
        _a('</tbody></table>')
        _a('</section>')

    # ---- Interference removal summary ----
    rs = data.get("removed_summary", {})
    _a('<section class="section">')
    _a(f'<h2>干扰剔除统计</h2>')
    _a(f'<p>总剔除条数: <strong>{rs.get("total", 0)}</strong></p>')
    by_src = rs.get("by_source", {})
    if by_src:
        _a('<ul>')
        for src, cnt in by_src.items():
            _a(f'<li>{_html.escape(src)}: {cnt}</li>')
        _a('</ul>')
    _a('</section>')

    # ---- Peak details ----
    peaks = data.get("peaks", [])
    _a('<h2 class="peaks-header">峰级详细信息</h2>')
    for pk in peaks:
        idx = pk.get("peak_index", "?")
        rt = pk.get("rt", "?")
        uv_s = pk.get("uv_start")
        uv_e = pk.get("uv_end")
        rt_range = f' ({uv_s:.4f}-{uv_e:.4f})' if uv_s is not None and uv_e is not None else ''

        _a(f'<section class="peak-card">')
        _a(f'<h3>UV峰#{idx}: RT={rt}min{rt_range}</h3>')

        # Wavelength info
        wls = pk.get("wavelengths", [])
        if wls:
            _a('<div class="wl-info">')
            for w in wls:
                pct = w.get("area_sum_pct")
                pct_s = f', 占比={pct:.2f}%' if pct is not None else ''
                _a(f'<span class="wl-pill">{w["nm"]}nm: 面积={w["area"]:.0f}{pct_s}</span>')
            _a('</div>')

        # MS1 info
        ms1 = pk.get("ms1_info", {})
        _a(f'<div class="ms1-meta">')
        _a(f'离子模式: <strong>{pk.get("ion_mode", "")}</strong> | ')
        _a(f'scan_id: {ms1.get("scan_id", "—")} | ')
        base_mz = ms1.get("base_mz")
        _a(f'base_mz: {_mz_btn(float(base_mz)) if base_mz and pd.notna(base_mz) else "—"} | ')
        base_ab = ms1.get("base_abund")
        _a(f'base_abund: {float(base_ab):,.0f}' if base_ab and pd.notna(base_ab) else 'base_abund: —')
        _a('</div>')

        # MS1 top list
        ms1_ions = pk.get("ms1_top5", [])
        if ms1_ions:
            has_dup = pk.get("has_duplicates", False)
            _a(f'<h4>过滤后 MS1 top{len(ms1_ions)}{" (* 去重标注)" if has_dup else ""}</h4>')
            _a('<table class="compact"><thead><tr><th>#</th><th>m/z</th><th>%</th><th>备注</th></tr></thead><tbody>')
            for j, ion in enumerate(ms1_ions, 1):
                dup_note = f' <span class="dup-tag">({_html.escape(ion.get("dup_from", ""))})</span>' if ion.get("is_duplicate") else ''
                _a(f'<tr><td>{j}</td><td>{_mz_btn(ion["mz"])}</td><td>{ion["rel_pct"]:.1f}%</td><td>{dup_note}</td></tr>')
            _a('</tbody></table>')

        # rule2_decimal
        r2 = pk.get("rule2", {})
        if r2.get("count", 0) > 0:
            _a(f'<div class="r2-note">[rule2_decimal 剔除] 共{r2["count"]}个: {_html.escape(r2.get("mz_list", ""))}</div>')

        # Interference removal detail
        rem = pk.get("removed", [])
        if rem:
            _a('<h4>干扰剔除明细</h4>')
            for rd in rem:
                src = rd.get("source", "")
                _a(f'<div class="rem-group">来源={_html.escape(src)}（{rd.get("count", 0)}条）')
                entries = rd.get("entries", [])
                if entries:
                    _a('<div class="rem-entries">')
                    for ent in entries:
                        rmz = ent.get("removed_mz")
                        rit = ent.get("removed_intensity")
                        if rmz is not None:
                            s = f'{_mz_btn(rmz)}@{rit:.0f}' if rit else str(rmz)
                            mmz = ent.get("matched_mz")
                            if mmz is not None:
                                ppm_e = ent.get("ppm_error")
                                s += f'-&gt;{mmz:.4f}({ppm_e:.1f}ppm)' if ppm_e is not None else f'-&gt;{mmz:.4f}'
                            elif ent.get("first_decimal") is not None:
                                s += f' [小数首位={ent["first_decimal"]}]'
                            _a(f'<span class="rem-item">{s}</span>')
                        else:
                            _a(f'<span class="rem-item">{_html.escape(str(ent.get("text", "")))}</span>')
                    _a('</div>')
                _a('</div>')

        # MS2 fragments
        ms2_list = pk.get("ms2_fragments", [])
        if ms2_list:
            _a('<h4>MS2 碎片</h4>')
            for ms2_block in ms2_list:
                prec = ms2_block.get("precursor_mz", "")
                scan = ms2_block.get("scan_id", "")
                _a(f'<div class="ms2-header">前体 m/z={_mz_btn(float(prec)) if prec else "—"} (scan={scan})</div>')
                frags = ms2_block.get("fragments", [])
                if frags:
                    _a('<table class="compact"><thead><tr><th>#</th><th>m/z</th><th>%</th></tr></thead><tbody>')
                    for k, fr in enumerate(frags, 1):
                        _a(f'<tr><td>{k}</td><td>{_mz_btn(fr["mz"])}</td><td>{fr["rel_pct"]:.1f}%</td></tr>')
                    _a('</tbody></table>')
                else:
                    _a('<p class="muted">(无/未匹配到MS2)</p>')

        # Adducts
        ads = pk.get("adducts", [])
        if ads:
            n_cand = len(ads)
            _a(f'<h4>加合离子检测（{n_cand}个候选）</h4>')
            _a('<table class="compact adduct-table"><thead><tr><th>候选</th><th>M</th><th>M+36</th><th>M+46</th><th>2M+1</th><th>M-36</th><th>M-46</th></tr></thead><tbody>')
            for ad in ads:
                rank = ad.get("candidate_rank", "?")
                m_mz = ad.get("m_mz")

                def _ad_cell(hit_key: str, mz_key: str, ppm_key: str) -> str:
                    if ad.get(hit_key):
                        mz_v = ad.get(mz_key)
                        ppm_v = ad.get(ppm_key)
                        return f'<td class="hit">命中 {mz_v:.4f} ({ppm_v:.1f}ppm)</td>' if mz_v else '<td class="hit">命中</td>'
                    return '<td class="miss">未命中</td>'

                _a(f'<tr><td>#{rank}</td><td>{_mz_btn(m_mz) if m_mz else "—"}</td>')
                _a(_ad_cell("hit_36", "mz_36", "ppm_36"))
                _a(_ad_cell("hit_46", "mz_46", "ppm_46"))
                _a(_ad_cell("hit_2m1", "mz_2m1", "ppm_2m1"))
                _a(_ad_cell("hit_m36", "mz_m36", "ppm_m36"))
                _a(_ad_cell("hit_m46", "mz_m46", "ppm_m46"))
                _a('</tr>')
            _a('</tbody></table>')
        elif not ms2_list:
            pass  # no ms2 and no adducts - skip
        else:
            _a('<p class="muted">（无加合离子检测数据）</p>')

        _a('</section>')  # peak-card end

    _a('</div>')  # report-wrap end

    # ---- EIC side panel ----
    _a('<div class="eic-overlay" id="eic-overlay" style="display:none;">')
    _a('<div class="eic-panel">')
    _a('<div class="eic-head">')
    _a('<span id="eic-title">EIC</span>')
    _a('<button id="eic-close" title="关闭">&times;</button>')
    _a('</div>')
    _a('<div class="eic-body">')
    _a('<img id="eic-img" alt="EIC">')
    _a('<div id="eic-loading" class="eic-loading">加载中...</div>')
    _a('<div id="eic-error" class="eic-error" style="display:none;"></div>')
    _a('</div>')
    _a('</div>')
    _a('</div>')

    # ---- Script ----
    _a('<script>')
    _a(_HTML_REPORT_JS)
    _a('</script>')
    _a('</body></html>')

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(parts), encoding="utf-8")


# ---- Embedded CSS for HTML report ----
_HTML_REPORT_CSS = """
:root {
  --bg: #f8fafc; --card: #ffffff; --text: #0f172a; --muted: #64748b;
  --accent: #2563eb; --line: #e2e8f0; --hit: #dcfce7; --miss: #f1f5f9;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: var(--bg); color: var(--text); font-size: 14px; line-height: 1.6;
}
.report-wrap { max-width: 1100px; margin: 0 auto; padding: 20px; }
h1 { font-size: 22px; margin-bottom: 8px; }
h2 { font-size: 17px; margin: 20px 0 10px; border-bottom: 2px solid var(--accent); padding-bottom: 6px; }
h2.peaks-header { margin-top: 30px; }
h3 { font-size: 15px; margin-bottom: 8px; color: var(--accent); }
h4 { font-size: 13px; margin: 12px 0 6px; color: var(--muted); }
.meta-line { font-size: 13px; color: var(--muted); margin-bottom: 4px; }
.section { margin-bottom: 16px; }
.peak-card {
  background: var(--card); border: 1px solid var(--line); border-radius: 12px;
  padding: 16px; margin-bottom: 14px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}
table { width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 10px; }
th, td { border: 1px solid var(--line); padding: 5px 8px; text-align: left; }
th { background: #eef2ff; font-size: 12px; font-weight: 600; }
tr:nth-child(even) td { background: #fafbfc; }
table.compact { max-width: 600px; }
.wl-info { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 8px; }
.wl-pill {
  background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px;
  padding: 4px 10px; font-size: 12px;
}
.ms1-meta { font-size: 12px; color: var(--muted); margin-bottom: 8px; }
.dup-tag { color: #d97706; font-size: 11px; font-weight: 600; }
.r2-note { font-size: 12px; color: var(--muted); margin: 6px 0; word-break: break-all; }
.rem-group { margin-bottom: 8px; font-size: 12px; }
.rem-entries { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
.rem-item {
  background: #fef3c7; border-radius: 6px; padding: 2px 8px; font-size: 11px;
  display: inline-block;
}
.ms2-header { font-size: 13px; margin-bottom: 4px; }
.adduct-table td.hit { background: var(--hit); color: #166534; font-weight: 600; font-size: 11px; }
.adduct-table td.miss { background: var(--miss); color: var(--muted); font-size: 11px; }
.muted { color: var(--muted); font-size: 13px; }

/* m/z EIC button */
.mz-link { white-space: nowrap; }
.eic-btn {
  background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 4px;
  color: var(--accent); cursor: pointer; font-size: 10px; padding: 1px 5px;
  margin-left: 3px; font-family: inherit; vertical-align: middle;
}
.eic-btn:hover { background: #dbeafe; border-color: var(--accent); }

/* EIC side panel — push layout */
.eic-overlay {
  position: fixed; top: 0; right: 0; bottom: 0;
  width: min(700px, 50vw); background: white;
  box-shadow: -4px 0 20px rgba(0,0,0,0.12);
  z-index: 1000; display: flex; flex-direction: column;
  transition: width 0.25s ease;
}
body.eic-open .report-wrap {
  margin-right: min(720px, 52vw);
  transition: margin-right 0.25s ease;
}
.report-wrap { transition: margin-right 0.25s ease; }
.eic-panel { display: flex; flex-direction: column; height: 100%; }
.eic-head {
  display: flex; justify-content: space-between; align-items: center;
  padding: 14px 20px; border-bottom: 1px solid var(--line);
  font-weight: 600; font-size: 16px;
}
.eic-head button {
  background: none; border: none; font-size: 24px; cursor: pointer; color: var(--muted);
}
.eic-body { flex: 1; overflow: auto; padding: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
.eic-body img { max-width: 100%; height: auto; display: none; }
.eic-loading { color: var(--muted); }
.eic-error { color: #dc2626; font-size: 13px; }
"""

# ---- Embedded JS for HTML report ----
_HTML_REPORT_JS = """
(function() {
  var overlay = document.getElementById('eic-overlay');
  var eicImg = document.getElementById('eic-img');
  var eicTitle = document.getElementById('eic-title');
  var eicLoading = document.getElementById('eic-loading');
  var eicError = document.getElementById('eic-error');
  var eicClose = document.getElementById('eic-close');

  document.addEventListener('click', function(e) {
    if (!e.target.classList.contains('eic-btn')) return;
    var mz = e.target.getAttribute('data-mz');
    if (!mz) return;

    eicTitle.textContent = 'EIC  m/z = ' + mz;
    eicImg.style.display = 'none';
    eicLoading.style.display = 'block';
    eicError.style.display = 'none';
    overlay.style.display = 'flex';
    document.body.classList.add('eic-open');
    // remember scroll position of the clicked button
    overlay._scrollY = window.scrollY;

    var url = new URL('eic', window.location.href);
    url.searchParams.set('mz', mz);
    url.searchParams.set('ppm', '5');

    var img = new Image();
    img.onload = function() {
      eicImg.src = img.src;
      eicImg.style.display = 'block';
      eicLoading.style.display = 'none';
    };
    img.onerror = function() {
      eicLoading.style.display = 'none';
      eicError.textContent = '无法加载 EIC 图 (m/z=' + mz + ')';
      eicError.style.display = 'block';
    };
    img.src = url.toString();
  });

  function closeEic() {
    overlay.style.display = 'none';
    document.body.classList.remove('eic-open');
    if (overlay._scrollY !== undefined) {
      window.scrollTo(0, overlay._scrollY);
    }
  }

  eicClose.addEventListener('click', closeEic);

  // Close on Escape
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && overlay.style.display !== 'none') {
      closeEic();
    }
  });
})();
"""
