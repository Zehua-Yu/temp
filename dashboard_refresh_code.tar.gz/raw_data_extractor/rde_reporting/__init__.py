"""
rde_reporting

报告输出层：文本报告格式化、CSV 之外的可读输出等。
"""

