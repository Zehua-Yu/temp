"""
rde_analysis/raw_blank_core.py

从 `raw_blank_analysis.py` 中抽出"核心解析/分析逻辑"，让 CLI 脚本只负责参数解析与输出编排。
目标：减少单文件体积、降低耦合、便于复用与测试；同时保持结果一致。

波长泛化：自动检测 DAD 实际波长（如 220、230、254 等），不再硬编码 210/254。
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

from .adduct_rules import detect_m_plus_34_46_multi
from .background_ions import build_background_ions
from .dad_merge import merge_dad_peak_tables
from .ms2_utils import match_best_ms2_scan, top_n_fragments
from ..rde_io.agilent_d_reader import AgilentDReader, ScanRecord, iter_scan_records, top_n_peaks_isotope_clustered
from ..rde_io.pdf_textbox50 import (
    SimplePeak,
    _coerce_pdf_peak_table,
    _extract_text_lines_from_pdf,
    _guess_analysis_pdf_path,
    _parse_textbox50_tables,
)
from ..rde_io.qualresult_peaks import PeakRow, is_bpc_chrom, load_pdf_like_peaks
from ..rde_utils.mz_utils import mz_match, mz_match_ppm
from ..rde_utils.rt_utils import parse_rt_value as _parse_rt_value
from ..rde_utils.scan_utils import (
    MS1ScanIndex,
    average_centroid_peaks,
    build_ms1_scan_index,
    collect_ms1_scans_in_window,
    pick_best_ms1_scan_indexed,
)


@dataclass(frozen=True)
class RawKeyInfo:
    """对齐 pdf_parser.py 的 key_info 结构，支持任意 DAD 波长。"""

    BPC_Peaks: Optional[pd.DataFrame]
    DAD_Peaks: Dict[int, Optional[pd.DataFrame]] = field(default_factory=dict)
    ESI_Info: Optional[pd.DataFrame] = None

    def as_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"BPC_Peaks": self.BPC_Peaks, "ESI_Info": self.ESI_Info}
        for wl, df in self.DAD_Peaks.items():
            d[f"DAD_Peaks_{wl}nm"] = df
        return d


def _format_kv(title: str, kv: Dict[str, object]) -> str:
    lines = [title]
    for k, v in kv.items():
        lines.append(f"- {k}: {v}")
    return "\n".join(lines)


def _peakrows_to_df(peaks: List[PeakRow]) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for p in peaks:
        rows.append(
            {
                "Peak": int(p.peak_no),
                "Start": float(p.start_rt_min),
                "RT": p.rt_display_3dp(),
                "End": float(p.end_rt_min),
                "Height": None if p.height is None else float(p.height),
                "Area": None if p.area is None else float(p.area),
                "Area_Percent": None if p.area_pct_of_max is None else float(p.area_pct_of_max),
                "Area_Sum": None if p.area_pct_of_total is None else float(p.area_pct_of_total),
            }
        )
    return pd.DataFrame(rows, columns=["Peak", "Start", "RT", "End", "Height", "Area", "Area_Percent", "Area_Sum"])


def _extract_dad_wavelength(title_lower: str) -> Optional[int]:
    """
    从色谱标题中提取 DAD 信号波长（整数 nm）。
    例如 "sig=220.0,4  ref=360.0,100" → 220
    返回 None 表示不是 DAD 通道或无法识别波长。
    """
    if "dad" not in title_lower:
        return None
    # 优先匹配 sig=NNN 格式
    m = re.search(r"sig=(\d+)(?:\.\d+)?", title_lower)
    if m:
        wl = int(m.group(1))
        return wl
    # 备用：匹配独立的三位数波长数字（排除 ref= 后面的）
    for mm in re.finditer(r"(\d{3})(?:\.\d+)?", title_lower):
        idx = mm.start()
        prefix = title_lower[:idx].rstrip()
        if prefix.endswith("ref="):
            continue
        return int(mm.group(1))
    return None


def _filter_dad_peaks(peaks_pdf: List[PeakRow]) -> Dict[int, List[PeakRow]]:
    """
    将 PeakRow 列表按 DAD 波长分组。
    返回 Dict[int, List[PeakRow]]，key 为波长 nm（如 220, 254）。
    """
    result: Dict[int, List[PeakRow]] = {}
    for p in peaks_pdf:
        t = (p.chrom_title or "").lower()
        wl = _extract_dad_wavelength(t)
        if wl is None:
            continue
        result.setdefault(wl, []).append(p)
    return result


def _first_decimal_digit(mz: float) -> int:
    """取 m/z 小数点后第一位数字。"""
    frac = abs(mz) - int(abs(mz))
    return int(frac * 10) % 10


def _build_esi_info_for_peaks(
    *,
    d_path: Path,
    peaks: List[Tuple[str, PeakRow]],
    top_n: int = 5,
    ms1_scans: Optional[List[ScanRecord]] = None,
    ms1_index: Optional[MS1ScanIndex] = None,
    d_reader: Optional[AgilentDReader] = None,
) -> pd.DataFrame:
    if ms1_scans is None:
        scans = list(iter_scan_records(d_path))
        ms1_scans = [s for s in scans if s.ms_level == 1]
    if ms1_index is None:
        ms1_index = build_ms1_scan_index(ms1_scans)
    if d_reader is None:
        d_reader = AgilentDReader(d_path)

    scan_top_cache: Dict[Tuple, List[Dict[str, object]]] = {}

    rows: List[Dict[str, object]] = []
    for peak_type, p in peaks:
        window_scans = collect_ms1_scans_in_window(
            ms1_index,
            rt_start=float(p.start_rt_min),
            rt_end=float(p.end_rt_min),
            rt_apex=float(p.apex_rt_min),
        )
        rt_str = p.rt_display_3dp()
        rt_min = None
        mz0 = None
        abund0 = None
        scan_id = None

        if window_scans:
            if len(window_scans) == 1:
                scan_id = int(window_scans[0].scan_id)
            else:
                scan_id = f"{window_scans[0].scan_id}~{window_scans[-1].scan_id}"
            rt_min = round(sum(s.rt_min for s in window_scans) / len(window_scans), 6)
            cache_key = tuple(int(s.scan_id) for s in window_scans)
            if cache_key not in scan_top_cache:
                mz_arr, int_arr = average_centroid_peaks(d_reader, window_scans, ppm_tol=5.0)
                if mz_arr.size > 0:
                    base_idx = int(np.argmax(int_arr))
                    mz0 = round(float(mz_arr[base_idx]), 4)
                    abund0 = float(int_arr[base_idx])
                scan_top_cache[cache_key] = top_n_peaks_isotope_clustered(mz_arr, int_arr, int(top_n))
            else:
                cached = scan_top_cache[cache_key]
                if cached:
                    mz0 = round(float(cached[0]["mz"]), 4)
                    abund0 = float(cached[0]["intensity"])

        rows.append(
            {
                "PeakType": peak_type,
                "Peak": int(p.peak_no),
                "RT": rt_str,
                "RT_min": rt_min,
                "scan_id": scan_id,
                "mz": mz0,
                "Abund": abund0,
            }
        )

        if not window_scans:
            continue

        cache_key = tuple(int(s.scan_id) for s in window_scans)
        for pk in scan_top_cache[cache_key]:
            rows.append(
                {
                    "PeakType": peak_type,
                    "Peak": int(p.peak_no),
                    "RT": rt_str,
                    "RT_min": rt_min,
                    "scan_id": scan_id,
                    "mz": mz0,
                    "Abund": abund0,
                    "spectrum_mz": round(float(pk["mz"]), 4),
                    "spectrum_intensity": float(pk["intensity"]),
                }
            )

    return pd.DataFrame(
        rows,
        columns=["PeakType", "Peak", "RT", "RT_min", "scan_id", "mz", "Abund", "spectrum_mz", "spectrum_intensity"],
    )


def _infer_ion_mode_from_method_folder(d_path: Path) -> str:
    acq = d_path / "AcqData"
    if not acq.exists():
        return "unknown"
    try:
        names = [p.name.upper() for p in acq.iterdir() if p.is_dir()]
    except Exception:
        return "unknown"
    if any("NEG" in n for n in names):
        return "negative"
    if any("POS" in n for n in names):
        return "positive"
    return "unknown"


class RawBlankRemovalAnalyzer:
    """
    原始 `.d` 空白信号分析器。
    """

    def __init__(
        self,
        *,
        blank_pos_path: Optional[str] = None,
        blank_neg_path: Optional[str] = None,
        top_n_spectrum: int = 5,
        max_interference_peaks: int = 5,
        cumulative_threshold: float = 0.9,
        mz_tol_ppm: float = 1.0,
        mz_tol_da: float = 0.0,
        rt_tolerance: float = 1.0,
    ) -> None:
        self.blank_pos_path = blank_pos_path
        self.blank_neg_path = blank_neg_path
        self.top_n_spectrum = int(top_n_spectrum)
        self.max_interference_peaks = int(max_interference_peaks)
        self.cumulative_threshold = float(cumulative_threshold)
        self.mz_tol_ppm = float(mz_tol_ppm)
        self.mz_tol_da = float(mz_tol_da)
        self.rt_tolerance = float(rt_tolerance)

        self.blank_pos_data: Optional[Dict[str, Any]] = None
        self.blank_neg_data: Optional[Dict[str, Any]] = None
        self.sample_data: Optional[Dict[str, Any]] = None
        self.sample_ion_mode: str = "unknown"
        self.sample_background_ions: List[Dict[str, object]] = []
        self._scan_cache: Dict[str, object] = {}

    @dataclass(frozen=True)
    class _ScanBundle:
        scans: List[ScanRecord]
        ms1_scans: List[ScanRecord]
        ms2_scans: List[ScanRecord]
        ms1_index: MS1ScanIndex
        d_reader: AgilentDReader

    def _get_scan_bundle(self, d_path: Path) -> "RawBlankRemovalAnalyzer._ScanBundle":
        key = str(d_path.resolve())
        cached = self._scan_cache.get(key)
        if isinstance(cached, RawBlankRemovalAnalyzer._ScanBundle):
            return cached

        scans = list(iter_scan_records(d_path))
        ms1_scans = [s for s in scans if s.ms_level == 1]
        ms2_scans = [s for s in scans if s.ms_level == 2]
        ms1_index = build_ms1_scan_index(ms1_scans)
        d_reader = AgilentDReader(d_path)
        bundle = RawBlankRemovalAnalyzer._ScanBundle(
            scans=scans,
            ms1_scans=ms1_scans,
            ms2_scans=ms2_scans,
            ms1_index=ms1_index,
            d_reader=d_reader,
        )
        self._scan_cache[key] = bundle
        return bundle

    def close(self) -> None:
        for v in list(self._scan_cache.values()):
            if isinstance(v, RawBlankRemovalAnalyzer._ScanBundle):
                try:
                    v.d_reader.close()
                except Exception:
                    pass
        self._scan_cache.clear()

    def parse_d(self, d_path: str, ion_mode: str, *, build_esi_info: bool = True) -> Optional[Dict[str, Any]]:
        if not d_path:
            return None

        p = Path(d_path).resolve()
        if not (p.is_dir() and p.suffix.lower() == ".d"):
            logger.error("不是有效的 .d 目录: %s", p)
            return None

        qual_bin = p / "Results" / "Qual" / "Version4" / "QualResult.bin"
        if not qual_bin.exists():
            logger.error("找不到 QualResult.bin: %s", qual_bin)
            return None

        logger.info("\n%s", "=" * 80)
        logger.info("开始解析 %s 模式原始文件: %s", ion_mode, p.name)
        logger.info("%s", "=" * 80)

        _chroms, peaks_pdf = load_pdf_like_peaks(qual_bin)

        # BPC / DAD peak 表
        bpc_peaks = [x for x in peaks_pdf if is_bpc_chrom(x.chrom_title, x.chrom_title)]
        dad_by_wl: Dict[int, List[PeakRow]] = _filter_dad_peaks(peaks_pdf)

        # PDF 回退：为 QualResult.bin 中缺失的波长补充数据，同时补入 PDF 中发现的新波长
        pdf_peaks_by_wl: Dict[int, List[SimplePeak]] = {}
        pdf_df_by_wl: Dict[int, pd.DataFrame] = {}
        pdf_path = _guess_analysis_pdf_path(p)
        if pdf_path:
            try:
                lines = _extract_text_lines_from_pdf(pdf_path)
                tables = _parse_textbox50_tables(lines)
                for tkey, tdf_raw in tables.items():
                    if not tkey.startswith("DAD_Peaks_"):
                        continue
                    # 从 key 提取波长：如 "DAD_Peaks_220nm" → 220
                    m = re.search(r"DAD_Peaks_(\d+)nm", tkey)
                    if not m:
                        continue
                    wl = int(m.group(1))
                    # 仅对 QualResult.bin 中缺失的波长做 PDF 回退
                    if wl in dad_by_wl and dad_by_wl[wl]:
                        continue
                    coerced = _coerce_pdf_peak_table(tdf_raw)
                    if coerced.empty:
                        continue
                    pdf_df_by_wl[wl] = coerced
                    simple_peaks: List[SimplePeak] = []
                    for _, r in coerced.iterrows():
                        try:
                            peak_no = int(r["Peak"])
                            start = float(r["Start"])
                            rt = float(r["RT"])
                            end = float(r["End"])
                        except Exception:
                            continue
                        simple_peaks.append(
                            SimplePeak(
                                peak_no=peak_no,
                                start_rt_min=start,
                                apex_rt_min=rt,
                                end_rt_min=end,
                                apex_rt_str=f"{rt:.3f}",
                            )
                        )
                    pdf_peaks_by_wl[wl] = simple_peaks
                    logger.info("从PDF补齐 DAD_Peaks_%dnm: %s 行 (%s)", wl, len(coerced), pdf_path.name)
            except Exception as e:
                logger.exception("尝试从PDF补齐 DAD 失败: %s", e)

        bpc_df = _peakrows_to_df(bpc_peaks) if bpc_peaks else pd.DataFrame()

        # 构建各波长的 DataFrame
        dad_dfs: Dict[int, pd.DataFrame] = {}
        all_wls = sorted(set(list(dad_by_wl.keys()) + list(pdf_df_by_wl.keys())))
        for wl in all_wls:
            if wl in dad_by_wl and dad_by_wl[wl]:
                dad_dfs[wl] = _peakrows_to_df(dad_by_wl[wl])
            elif wl in pdf_df_by_wl and not pdf_df_by_wl[wl].empty:
                dad_dfs[wl] = pdf_df_by_wl[wl]

        # ESI_Info
        esi_df = pd.DataFrame()
        if build_esi_info:
            union_peaks: List[Tuple[str, PeakRow]] = []
            union_peaks.extend([("BPC", x) for x in bpc_peaks])
            for wl in all_wls:
                label = f"DAD_{wl}nm"
                if wl in dad_by_wl and dad_by_wl[wl]:
                    union_peaks.extend([(label, x) for x in dad_by_wl[wl]])
                elif wl in pdf_peaks_by_wl:
                    union_peaks.extend([(label, x) for x in pdf_peaks_by_wl[wl]])  # type: ignore[arg-type]
            if union_peaks:
                try:
                    bundle = self._get_scan_bundle(p)
                    esi_df = _build_esi_info_for_peaks(
                        d_path=p,
                        peaks=union_peaks,
                        top_n=self.top_n_spectrum,
                        ms1_scans=bundle.ms1_scans,
                        ms1_index=bundle.ms1_index,
                        d_reader=bundle.d_reader,
                    )
                except Exception:
                    esi_df = _build_esi_info_for_peaks(d_path=p, peaks=union_peaks, top_n=self.top_n_spectrum)

        dad_peaks_dict: Dict[int, Optional[pd.DataFrame]] = {}
        for wl in all_wls:
            df = dad_dfs.get(wl)
            dad_peaks_dict[wl] = df if (df is not None and not df.empty) else None

        key_info = RawKeyInfo(
            BPC_Peaks=bpc_df if not bpc_df.empty else None,
            DAD_Peaks=dad_peaks_dict,
            ESI_Info=esi_df if not esi_df.empty else None,
        ).as_dict()

        logger.info("BPC_Peaks: %s 行", 0 if key_info["BPC_Peaks"] is None else len(key_info["BPC_Peaks"]))
        for wl in all_wls:
            k = f"DAD_Peaks_{wl}nm"
            logger.info("%s: %s 行", k, 0 if key_info.get(k) is None else len(key_info[k]))
        if build_esi_info:
            logger.info("ESI_Info: %s 行", 0 if key_info["ESI_Info"] is None else len(key_info["ESI_Info"]))
        else:
            logger.info("ESI_Info: (跳过构建)")

        return key_info

    def parse_all(self) -> Dict[str, Optional[Dict[str, Any]]]:
        out: Dict[str, Optional[Dict[str, Any]]] = {}
        if self.blank_pos_path:
            self.blank_pos_data = self.parse_d(self.blank_pos_path, "positive", build_esi_info=True)
            out["blank_pos"] = self.blank_pos_data
        if self.blank_neg_path:
            self.blank_neg_data = self.parse_d(self.blank_neg_path, "negative", build_esi_info=True)
            out["blank_neg"] = self.blank_neg_data
        return out

    def parse_sample(self, d_path: str, *, ion_mode: str = "auto", build_esi_info: bool = True) -> Optional[Dict[str, Any]]:
        p = Path(d_path).resolve()
        self._sample_path = str(p)
        inferred = _infer_ion_mode_from_method_folder(p)
        if ion_mode in ("positive", "negative"):
            self.sample_ion_mode = ion_mode
        elif ion_mode == "auto":
            self.sample_ion_mode = inferred
        else:
            self.sample_ion_mode = inferred
        self.sample_data = self.parse_d(d_path, f"sample({self.sample_ion_mode})", build_esi_info=bool(build_esi_info))
        return self.sample_data

    def extract_interference_peaks(
        self,
        peak_df: Optional[pd.DataFrame],
        *,
        peak_type: str,
        max_peaks: int = 5,
        cumulative_threshold: float = 0.9,
    ) -> pd.DataFrame:
        if peak_df is None or peak_df.empty:
            logger.info("  %s: 无数据", peak_type)
            return pd.DataFrame()
        if "Height" not in peak_df.columns:
            logger.warning("  %s: 缺少Height列", peak_type)
            return pd.DataFrame()

        df = peak_df.copy()
        df["Height"] = pd.to_numeric(df["Height"], errors="coerce")
        df = df[df["Height"].notna()].copy()
        if df.empty:
            logger.info("  %s: Height 无有效数值", peak_type)
            return pd.DataFrame()

        total_height = float(df["Height"].sum())
        sorted_peaks = df.sort_values("Height", ascending=False).copy()

        heights = pd.to_numeric(sorted_peaks["Height"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
        if heights.size == 0:
            return pd.DataFrame()
        cum = np.cumsum(heights)
        thr = float(total_height) * float(cumulative_threshold)
        hit_idx = int(np.searchsorted(cum, thr, side="left"))
        need_n = hit_idx + 1 if hit_idx < int(cum.size) else int(cum.size)
        need_n = min(int(max_peaks), int(need_n))
        if need_n <= 0:
            return pd.DataFrame()
        res = sorted_peaks.head(int(need_n)).copy()
        cumulative_height = float(cum[int(need_n) - 1])
        if not res.empty:
            res["PeakType"] = peak_type
            ratio = cumulative_height / total_height if total_height > 0 else 0.0
            logger.info(
                "  %s: 总%s个峰, 总Height=%.1f, 提取%s个峰, 累积Height=%.1f (%.1f%%)",
                peak_type,
                len(df),
                total_height,
                len(res),
                cumulative_height,
                ratio * 100.0,
            )
        return res

    def _match_mz_to_peaks(self, peaks_df: pd.DataFrame, esi_info: Optional[pd.DataFrame]) -> pd.DataFrame:
        if peaks_df is None or peaks_df.empty:
            return peaks_df
        if esi_info is None or esi_info.empty:
            logger.info("    ESI_Info为空，无法匹配m/z")
            return peaks_df

        out = peaks_df.copy()
        mz_values: List[Optional[float]] = []
        rt_diffs: List[Optional[float]] = []

        esi_rt_vals: List[Tuple[float, int]] = []
        for r in esi_info.itertuples(index=True):
            i = int(getattr(r, "Index"))
            rt = getattr(r, "RT_min", None) if hasattr(r, "RT_min") else None
            rt_val = None
            if rt is not None and rt != "" and pd.notna(rt):
                try:
                    rt_val = float(rt)
                except Exception:
                    rt_val = None
            if rt_val is None:
                rt_val = _parse_rt_value(getattr(r, "RT", None) if hasattr(r, "RT") else None)
            if rt_val is None:
                continue
            esi_rt_vals.append((float(rt_val), i))

        if esi_rt_vals:
            esi_rts_arr = np.array([x[0] for x in esi_rt_vals], dtype=float)
            esi_idxs = [x[1] for x in esi_rt_vals]
        else:
            esi_rts_arr = np.array([], dtype=float)
            esi_idxs = []

        for row in out.itertuples(index=False):
            prt = _parse_rt_value(getattr(row, "RT", None) if hasattr(row, "RT") else None)
            if prt is None or esi_rts_arr.size == 0:
                mz_values.append(None)
                rt_diffs.append(None)
                continue

            diffs = np.abs(esi_rts_arr - float(prt))
            j = int(diffs.argmin())
            best_idx = esi_idxs[j]
            mz_values.append(esi_info.loc[best_idx].get("mz"))
            rt_diffs.append(float(diffs[j]))

        out["mz"] = mz_values
        out["RT_Diff"] = rt_diffs

        matched_count = sum(1 for x in mz_values if x is not None)
        logger.info("    成功匹配 %s/%s 个峰的m/z信息", matched_count, len(out))
        return out

    def extract_blank_interferences(self) -> Dict[str, Any]:
        logger.info("\n%s", "=" * 80)
        logger.info("提取空白原始文件干扰物")
        logger.info("%s", "=" * 80)

        interferences: Dict[str, Any] = {"blank_pos_interferences": {}, "blank_neg_interferences": {}}

        def handle_one(key_info: Dict[str, Any], label: str) -> Dict[str, pd.DataFrame]:
            out: Dict[str, pd.DataFrame] = {}
            esi_info_all = key_info.get("ESI_Info")
            if not isinstance(esi_info_all, pd.DataFrame):
                esi_info_all = pd.DataFrame()

            def attach_spectrum_list(df: pd.DataFrame, peak_type: str) -> pd.DataFrame:
                if df is None or df.empty:
                    return df
                if esi_info_all is None or esi_info_all.empty:
                    df2 = df.copy()
                    df2["spectrum_mz_list"] = [[] for _ in range(len(df2))]
                    return df2
                esi_type = (
                    esi_info_all[esi_info_all["PeakType"] == peak_type].copy()
                    if "PeakType" in esi_info_all.columns
                    else esi_info_all.copy()
                )
                if esi_type.empty or "Peak" not in esi_type.columns:
                    df2 = df.copy()
                    df2["spectrum_mz_list"] = [[] for _ in range(len(df2))]
                    return df2

                peak_to_list: Dict[int, List[float]] = {}
                for pk, g in esi_type.groupby("Peak"):
                    try:
                        k = int(pk)
                    except Exception:
                        continue
                    if "spectrum_mz" not in g.columns:
                        continue
                    vals: List[float] = []
                    for v in g["spectrum_mz"].tolist():
                        try:
                            vals.append(float(v))
                        except Exception:
                            continue
                    seen: set = set()
                    uniq2: List[float] = []
                    for vv in vals:
                        if vv in seen:
                            continue
                        seen.add(vv)
                        uniq2.append(vv)
                    peak_to_list[k] = uniq2

                lsts: List[List[float]] = []
                if "Peak" in df.columns:
                    for r in df.itertuples(index=False):
                        try:
                            pn = int(getattr(r, "Peak"))
                        except Exception:
                            pn = -1
                        lsts.append(peak_to_list.get(pn, []))
                else:
                    lsts = [[] for _ in range(len(df))]
                df2 = df.copy()
                df2["spectrum_mz_list"] = lsts
                return df2

            # BPC
            bpc = self.extract_interference_peaks(
                key_info.get("BPC_Peaks"),
                peak_type="BPC",
                max_peaks=self.max_interference_peaks,
                cumulative_threshold=self.cumulative_threshold,
            )
            if not bpc.empty:
                esi_info = (
                    esi_info_all[esi_info_all["PeakType"] == "BPC"].copy()
                    if "PeakType" in esi_info_all.columns
                    else esi_info_all
                )
                out["BPC"] = attach_spectrum_list(self._match_mz_to_peaks(bpc, esi_info), "BPC")

            # DAD — 动态遍历所有波长
            for k, v in key_info.items():
                if not k.startswith("DAD_Peaks_") or not k.endswith("nm"):
                    continue
                # k 形如 "DAD_Peaks_220nm"
                wl_label = k.replace("Peaks_", "")  # "DAD_220nm"
                dad_df = self.extract_interference_peaks(
                    v,
                    peak_type=wl_label,
                    max_peaks=self.max_interference_peaks,
                    cumulative_threshold=self.cumulative_threshold,
                )
                if not dad_df.empty:
                    esi_info = (
                        esi_info_all[esi_info_all["PeakType"] == wl_label].copy()
                        if "PeakType" in esi_info_all.columns
                        else esi_info_all
                    )
                    out[wl_label] = attach_spectrum_list(self._match_mz_to_peaks(dad_df, esi_info), wl_label)

            if not out:
                logger.info("%s: 未提取到干扰峰", label)
            return out

        if self.blank_pos_data:
            logger.info("\n提取空白正离子干扰物:")
            interferences["blank_pos_interferences"] = handle_one(self.blank_pos_data, "blank_pos")
        if self.blank_neg_data:
            logger.info("\n提取空白负离子干扰物:")
            interferences["blank_neg_interferences"] = handle_one(self.blank_neg_data, "blank_neg")

        return interferences

    def print_interference_summary(self, interferences: Dict[str, Any]) -> None:
        logger.info("\n%s", "=" * 80)
        logger.info("空白原始文件干扰物摘要")
        logger.info("%s", "=" * 80)

        def show(title: str, items: Dict[str, pd.DataFrame]) -> None:
            if not items:
                logger.info("\n【%s】无干扰物数据", title)
                return
            logger.info("\n【%s】", title)
            for peak_type, df in items.items():
                logger.info("\n%s:", peak_type)
                if df is None or df.empty:
                    logger.info("  无干扰峰")
                    continue
                cols = ["Peak", "RT", "Height", "Area_Sum", "mz", "RT_Diff"]
                cols = [c for c in cols if c in df.columns]
                logger.info("\n%s", df[cols].to_string(index=False))

        show("空白正离子干扰物", interferences.get("blank_pos_interferences", {}))
        show("空白负离子干扰物", interferences.get("blank_neg_interferences", {}))

    def _find_rt_matched_blank_peaks(
        self, *, sample_rt: Optional[float], blank_peaks: Optional[pd.DataFrame], rt_tolerance: float
    ) -> pd.DataFrame:
        if blank_peaks is None or blank_peaks.empty or sample_rt is None:
            return pd.DataFrame()
        matched: List[pd.Series] = []
        for r in blank_peaks.itertuples(index=False):
            brt = _parse_rt_value(getattr(r, "RT", None) if hasattr(r, "RT") else None)
            if brt is None:
                continue
            if abs(float(sample_rt) - float(brt)) < float(rt_tolerance):
                matched.append(pd.Series(r._asdict()))
        return pd.DataFrame(matched) if matched else pd.DataFrame()

    def _is_interference_mz(self, *, mz_value: float, blank_mz_list: List[float]) -> bool:
        for bm in blank_mz_list or []:
            hit, _ppm, _mode = mz_match(
                obs_mz=float(mz_value),
                ref_mz=float(bm),
                ppm_tol=self.mz_tol_ppm,
                da_tol=self.mz_tol_da,
            )
            if hit:
                return True
        return False

    def _blank_mz_pool_for_rt(
        self,
        *,
        blank_pool: Dict[str, pd.DataFrame],
        sample_rt: Optional[float],
    ) -> List[float]:
        if sample_rt is None:
            return []
        mzs: List[float] = []
        for _ptype, df in (blank_pool or {}).items():
            if df is None or df.empty:
                continue
            matched = self._find_rt_matched_blank_peaks(sample_rt=sample_rt, blank_peaks=df, rt_tolerance=self.rt_tolerance)
            if matched.empty:
                continue
            for _i, r in matched.iterrows():
                bdiff = r.get("RT_Diff")
                if bdiff is not None:
                    try:
                        if float(bdiff) > 1.0:
                            continue
                    except Exception:
                        pass
                bmz = r.get("mz")
                if bmz is not None and pd.notna(bmz):
                    try:
                        mzs.append(float(bmz))
                    except Exception:
                        pass
                lst = r.get("spectrum_mz_list")
                if isinstance(lst, list):
                    for v in lst:
                        try:
                            mzs.append(float(v))
                        except Exception:
                            continue
        return list(dict.fromkeys(mzs))

    def _filter_ms1_top_peaks(
        self,
        *,
        rt_str: str,
        peak_id: str,
        ms1_top: List[Dict[str, object]],
        blank_mz_list: List[float],
        background_mz_list: List[float],
    ) -> Tuple[List[Dict[str, object]], List[Dict[str, object]]]:
        """
        返回：(kept_peaks, removed_details)
        3步过滤：blank → background → rule2_decimal(m/z<500 且小数第1位=6或9)
        """
        kept: List[Dict[str, object]] = []
        removed: List[Dict[str, object]] = []

        for p in ms1_top or []:
            try:
                m = float(p["mz"])
                it = float(p.get("intensity", 0.0))
            except Exception:
                continue

            # 1) blank
            hit_any = False
            for bm in blank_mz_list or []:
                hit, ppm_err, mode = mz_match(obs_mz=m, ref_mz=float(bm), ppm_tol=self.mz_tol_ppm, da_tol=self.mz_tol_da)
                if hit:
                    removed.append(
                        {
                            "RT": rt_str,
                            "peak_id": peak_id,
                            "removed_mz": m,
                            "removed_intensity": it,
                            "source": "blank",
                            "matched_mz": float(bm),
                            "ppm_error": ppm_err,
                            "hit_mode": mode,
                            "rule_note": "",
                        }
                    )
                    hit_any = True
                    break
            if hit_any:
                continue

            # 2) background
            for bgm in background_mz_list or []:
                hit, ppm_err, mode = mz_match(obs_mz=m, ref_mz=float(bgm), ppm_tol=self.mz_tol_ppm, da_tol=self.mz_tol_da)
                if hit:
                    removed.append(
                        {
                            "RT": rt_str,
                            "peak_id": peak_id,
                            "removed_mz": m,
                            "removed_intensity": it,
                            "source": "background",
                            "matched_mz": float(bgm),
                            "ppm_error": ppm_err,
                            "hit_mode": mode,
                            "rule_note": "",
                        }
                    )
                    hit_any = True
                    break
            if hit_any:
                continue

            # 3) rule2_decimal: m/z < 500 且小数第一位 = 6 或 9
            if m < 500.0:
                d1 = _first_decimal_digit(m)
                if d1 in (6, 9):
                    removed.append(
                        {
                            "RT": rt_str,
                            "peak_id": peak_id,
                            "removed_mz": m,
                            "removed_intensity": it,
                            "source": "rule2_decimal",
                            "matched_mz": None,
                            "ppm_error": None,
                            "hit_mode": "",
                            "rule_note": f"m/z<500 and first_decimal_digit in 6,9",
                        }
                    )
                    continue

            kept.append(p)

        return kept, removed

    def analyze_sample_peaks_v2(
        self,
        *,
        interferences: Dict[str, Any],
        top_k: int = 5,
        uv_primary_wl: int = 220,
        uv_wavelengths: Optional[List[int]] = None,
        uv_min_area_sum_pct: float = 5.0,
        ms1_topn: int = 10,
        ms1_keep: int = 5,
        dad_merge_rt_tol: float = 0.05,
        area_merge_mode: str = "max",
        enable_background: bool = True,
        bg_scan_step: int = 10,
        bg_topk: int = 50,
        bg_presence: float = 0.8,
        bg_edge_coverage: float = 0.05,
        bg_filter_min_duration_ratio: float = 0.5,
        bg_filter_min_avg_intensity: float = 30000.0,
        bg_filter_max_peak_ratio: float = 100.0,
        ms2_rt_tol: float = 0.3,
        ms2_precursor_ppm_tol: float = 20.0,
        ms2_precursors_per_rt: int = 1,
        ms2_frag_topn: int = 5,
        enable_adducts: bool = True,
        adduct_max_candidates: int = 5,
        adduct_ppm_tol: float = 5.0,
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        样品分析：
        - 多波长 DAD 合并（自动检测实际波长）
        - 每个RT取 MS1 top10 -> 去干扰(空白+背景+rule2_decimal) -> top5
        - 加合离子: top5 候选
        - 背景离子: duration_ratio >= 50%
        """
        if not self.sample_data:
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

        key_info = self.sample_data

        # 1) 合并 DAD peaks — 收集所有波长
        dad_tables: Dict[int, pd.DataFrame] = {}
        for k, v in key_info.items():
            if not k.startswith("DAD_Peaks_") or not k.endswith("nm"):
                continue
            m = re.search(r"DAD_Peaks_(\d+)nm", k)
            if m and v is not None and isinstance(v, pd.DataFrame) and not v.empty:
                wl_int = int(m.group(1))
                # 只保留指定波长（默认 220, 254）
                if uv_wavelengths and wl_int not in uv_wavelengths:
                    continue
                dad_tables[wl_int] = v
        merged = merge_dad_peak_tables(
            dad_tables=dad_tables,
            parse_rt_value=_parse_rt_value,
            rt_tol_min=float(dad_merge_rt_tol),
            area_merge_mode=str(area_merge_mode or "max"),
        )
        if merged is None or merged.empty:
            logger.info("样品：合并后的DAD峰为空，无法分析")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

        # 筛选：以主波长(220nm)的 Area_Sum 占比 >= 阈值为准，不足 top_k 则保留 top_k
        area_sum_col = f"Area_Sum_{uv_primary_wl}"
        if area_sum_col in merged.columns:
            filtered = merged[
                pd.to_numeric(merged[area_sum_col], errors="coerce").fillna(0) >= float(uv_min_area_sum_pct)
            ].copy()
            if len(filtered) < int(top_k):
                merged = merged.head(int(top_k)).copy()
                logger.info("以 %s >= %.1f%% 筛选得 %d 个峰，不足 %d，保留 top_%d",
                            area_sum_col, uv_min_area_sum_pct, len(filtered), top_k, top_k)
            else:
                merged = filtered
                logger.info("以 %s >= %.1f%% 筛选，剩余 %d 个峰", area_sum_col, uv_min_area_sum_pct, len(merged))
        else:
            # 主波长列不存在时回退到 top_k
            merged = merged.head(int(top_k)).copy()
            logger.info("主波长 %dnm 无 Area_Sum 列，回退 top_k=%d", uv_primary_wl, top_k)

        # 重置索引，使 peak_index 从 1 开始连续编号
        merged = merged.reset_index(drop=True)

        if merged.empty:
            logger.info("样品：筛选后无峰")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

        # 2) 预载 scan
        d_path = Path(str(getattr(self, "_sample_path", "") or "")).resolve() if hasattr(self, "_sample_path") else None
        if d_path is None or not d_path.exists():
            d_path = None

        if d_path is None:
            logger.info("样品：缺少样品路径上下文，无法读取MS1/MS2扫描")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

        bundle = self._get_scan_bundle(d_path)
        ms1_scans = bundle.ms1_scans
        ms2_scans = bundle.ms2_scans
        ms1_index = bundle.ms1_index
        ms2_by_id: Dict[int, ScanRecord] = {int(s.scan_id): s for s in ms2_scans}
        d_reader = bundle.d_reader

        ms1_top_cache: Dict[Tuple, List[Dict[str, object]]] = {}
        ms2_frag_cache: Dict[Tuple[int, int], str] = {}

        # 3) 背景离子 — 使用 duration_ratio 阈值
        bg_list = []
        if enable_background:
            strict_bg, bg_candidates = build_background_ions(
                ms1_scans=ms1_scans,
                d_reader=d_reader,
                ppm_tol=self.mz_tol_ppm,
                scan_step=int(bg_scan_step),
                topk_per_scan=int(bg_topk),
                presence_threshold=float(bg_presence),
                edge_coverage_ratio=float(bg_edge_coverage),
            )
            for x in bg_candidates:
                bg_list.append(
                    {
                        "mz": x.mz,
                        "hits": x.hits,
                        "scans_total": x.scans_total,
                        "presence_rate": x.presence_rate,
                        "rt_min_hit": x.rt_min_hit,
                        "rt_max_hit": x.rt_max_hit,
                        "duration_min": x.duration_min,
                        "duration_ratio": x.duration_ratio,
                        "max_intensity": x.max_intensity,
                        "avg_intensity": x.avg_intensity,
                        "score": x.score,
                        "is_strict_background": x.is_strict_background,
                        "median_intensity": x.median_intensity,
                        "peak_ratio": x.peak_ratio,
                    }
                )
        bg_df = pd.DataFrame(bg_list)

        # 过滤用背景离子：duration_ratio >= 阈值 AND avg_intensity >= 阈值 AND peak_ratio <= 阈值
        background_mz: List[float] = []
        if bg_df is not None and not bg_df.empty and "duration_ratio" in bg_df.columns and "avg_intensity" in bg_df.columns:
            df2 = bg_df.copy()
            df2["duration_ratio"] = pd.to_numeric(df2["duration_ratio"], errors="coerce")
            df2["avg_intensity"] = pd.to_numeric(df2["avg_intensity"], errors="coerce")
            if "peak_ratio" in df2.columns:
                df2["peak_ratio"] = pd.to_numeric(df2["peak_ratio"], errors="coerce")
            df2 = df2[(df2["duration_ratio"].notna()) & (df2["avg_intensity"].notna())].copy()
            df2 = df2[
                (df2["duration_ratio"] >= float(bg_filter_min_duration_ratio))
                & (df2["avg_intensity"] >= float(bg_filter_min_avg_intensity))
            ].copy()
            if "peak_ratio" in df2.columns:
                df2 = df2[df2["peak_ratio"] <= float(bg_filter_max_peak_ratio)].copy()
            for v in df2["mz"].tolist():
                try:
                    background_mz.append(float(v))
                except Exception:
                    continue
        background_mz = list(dict.fromkeys(background_mz))

        # 4) 选用哪个空白池
        if self.sample_ion_mode == "positive":
            blank_pool = interferences.get("blank_pos_interferences", {}) or {}
        elif self.sample_ion_mode == "negative":
            blank_pool = interferences.get("blank_neg_interferences", {}) or {}
        else:
            blank_pool = interferences.get("blank_neg_interferences") or interferences.get("blank_pos_interferences") or {}

        # 5) 对每个 merged peak 做分析
        main_rows: List[Dict[str, object]] = []
        removed_rows: List[Dict[str, object]] = []
        adduct_rows: List[Dict[str, object]] = []
        global_seen_mz: List[Tuple[float, int]] = []  # (mz, peak_index) 跨 UV 峰去重

        for idx, r in merged.iterrows():
            rt_str = str(r.get("RT") or "")
            rt_val = _parse_rt_value(rt_str)

            # 动态选择面积最大的波长作为 MS 窗口来源
            area_cols = [c for c in merged.columns if re.match(r"Area_\d+$", c)]
            best_wl = None
            best_area = None
            for ac in area_cols:
                wl_str = ac.replace("Area_", "")
                try:
                    a_val = float(r.get(ac)) if r.get(ac) is not None and pd.notna(r.get(ac)) else None
                except Exception:
                    a_val = None
                if a_val is not None and (best_area is None or a_val > best_area):
                    best_area = a_val
                    best_wl = wl_str

            if best_wl:
                start = r.get(f"Start_{best_wl}")
                end = r.get(f"End_{best_wl}")
                peak_no = r.get(f"Peak_{best_wl}")
                wavelength = best_wl
            else:
                start = None
                end = None
                peak_no = None
                wavelength = ""

            try:
                start_rt = float(start) if start is not None and pd.notna(start) else (rt_val if rt_val is not None else 0.0)
            except Exception:
                start_rt = rt_val if rt_val is not None else 0.0
            try:
                end_rt = float(end) if end is not None and pd.notna(end) else (rt_val if rt_val is not None else start_rt)
            except Exception:
                end_rt = rt_val if rt_val is not None else start_rt
            apex = rt_val if rt_val is not None else (start_rt + end_rt) / 2.0

            peak_id = f"merged_{idx+1}"
            if peak_no is not None and peak_no != "":
                try:
                    peak_id = f"DAD{wavelength}_P{int(peak_no)}"
                except Exception:
                    pass

            window_scans = collect_ms1_scans_in_window(ms1_index, rt_start=float(start_rt), rt_end=float(end_rt), rt_apex=float(apex))
            ms1_top = []
            base_mz = None
            base_abund = None
            scan_id = None
            rt_ms1 = None
            if window_scans:
                if len(window_scans) == 1:
                    scan_id = int(window_scans[0].scan_id)
                else:
                    scan_id = f"{window_scans[0].scan_id}~{window_scans[-1].scan_id}"
                rt_ms1 = round(sum(s.rt_min for s in window_scans) / len(window_scans), 6)
                cache_key = tuple(int(s.scan_id) for s in window_scans)
                cached_top = ms1_top_cache.get(cache_key)
                if cached_top is None:
                    mz_arr, int_arr = average_centroid_peaks(d_reader, window_scans, ppm_tol=5.0)
                    if mz_arr.size > 0:
                        base_idx = int(np.argmax(int_arr))
                        base_mz = round(float(mz_arr[base_idx]), 4)
                        base_abund = float(int_arr[base_idx])
                    cached_top = top_n_peaks_isotope_clustered(mz_arr, int_arr, int(ms1_topn))
                    ms1_top_cache[cache_key] = cached_top
                else:
                    # 从缓存恢复 base_mz / base_abund
                    if cached_top:
                        base_mz = round(float(cached_top[0]["mz"]), 4)
                        base_abund = float(cached_top[0]["intensity"])
                ms1_top = cached_top

            blank_mz_list = self._blank_mz_pool_for_rt(blank_pool=blank_pool, sample_rt=apex)
            kept, removed = self._filter_ms1_top_peaks(
                rt_str=rt_str,
                peak_id=peak_id,
                ms1_top=ms1_top,
                blank_mz_list=blank_mz_list,
                background_mz_list=background_mz,
            )
            removed_rows.extend(removed)

            # 统计 rule2_decimal 剔除
            r2_removed = [x for x in removed if x.get("source") == "rule2_decimal"]
            r2_count = len(r2_removed)
            r2_mz_list = ",".join([f"{float(x['removed_mz']):.4f}" for x in r2_removed]) if r2_removed else ""

            kept_sorted = sorted(
                kept,
                key=lambda x: float(x.get("intensity", 0.0) or 0.0),
                reverse=True,
            )

            # 跨 UV 峰去重：标记重复，凑够 ms1_keep 个不重复 m/z
            current_peak_index = int(idx) + 1
            unique_count = 0
            kept2: List[Dict[str, object]] = []
            for p in kept_sorted:
                mz_val = float(p["mz"])
                dup_from = None
                for seen_mz, seen_peak in global_seen_mz:
                    if mz_match_ppm(obs_mz=mz_val, ref_mz=seen_mz, ppm_tol=self.mz_tol_ppm):
                        dup_from = seen_peak
                        break
                p_copy = dict(p)
                p_copy["is_duplicate"] = dup_from is not None
                p_copy["dup_from_peak"] = dup_from
                kept2.append(p_copy)
                if dup_from is None:
                    unique_count += 1
                if unique_count >= int(ms1_keep):
                    break

            # 将本峰的不重复 m/z 加入全局集合
            for p in kept2:
                if not p.get("is_duplicate"):
                    global_seen_mz.append((float(p["mz"]), current_peak_index))

            # 去重备注列：标记哪些序号是重复的，以及来源峰号
            dedup_notes = []
            for i, p in enumerate(kept2, start=1):
                if p.get("is_duplicate"):
                    src = p.get("dup_from_peak")
                    dedup_notes.append(f"{i}:重复@峰#{src}")
            ms1_dedup_note = "|".join(dedup_notes)

            # MS1 过滤后 top5：相对强度
            ms1_top5_rel = ""
            if kept2:
                try:
                    base_it = max(float(p.get("intensity", 0.0) or 0.0) for p in kept2)
                except Exception:
                    base_it = 0.0
                if base_it <= 0:
                    base_it = 1.0
                toks = []
                for p2 in kept2:
                    try:
                        m2 = float(p2.get("mz"))
                        it2 = float(p2.get("intensity", 0.0) or 0.0)
                        rel = float(it2 / base_it) if base_it > 0 else 0.0
                        toks.append(f"{m2:.4f}@{rel:.3f}")
                    except Exception:
                        continue
                ms1_top5_rel = "|".join(toks)

            # adduct evidence — top5 候选 (2M+1, M+36, M+46, M-36, M-46)
            if enable_adducts and self.sample_ion_mode == "negative":
                peaks_for_adduct = kept2 if kept2 else ms1_top
                evs = detect_m_plus_34_46_multi(
                    rt=rt_str,
                    peaks_top=peaks_for_adduct,
                    ppm_tol=float(adduct_ppm_tol),
                    max_candidates=int(adduct_max_candidates),
                )
                for ev in evs:
                    adduct_rows.append(
                        {
                            "RT": ev.rt,
                            "peak_id": peak_id,
                            "candidate_rank": ev.candidate_rank,
                            "M_mz": ev.m_mz,
                            "M_intensity": ev.m_intensity,
                            "hit_2M+1": ev.hit_2m_plus_1,
                            "2M+1_mz": ev.mz_2m1,
                            "ppm_err_2m1": ev.ppm_err_2m1,
                            "hit_M+36": ev.hit_m_plus_36,
                            "M+36_mz": ev.m_plus_36_mz,
                            "ppm_err_36": ev.ppm_err_36,
                            "hit_M+46": ev.hit_m_plus_46,
                            "M+46_mz": ev.m_plus_46_mz,
                            "ppm_err_46": ev.ppm_err_46,
                            "hit_M-36": ev.hit_m_minus_36,
                            "M-36_mz": ev.m_minus_36_mz,
                            "ppm_err_m36": ev.ppm_err_m36,
                            "hit_M-46": ev.hit_m_minus_46,
                            "M-46_mz": ev.m_minus_46_mz,
                            "ppm_err_m46": ev.ppm_err_m46,
                        }
                    )

            # MS2
            ms2_summary = ""
            if kept2 and ms2_scans:
                ms2_n = max(1, int(ms2_precursors_per_rt))
                ms2_n = min(ms2_n, len(kept2))
                parts = []
                for kk in range(ms2_n):
                    pmz = float(kept2[kk]["mz"])
                    m2 = match_best_ms2_scan(
                        ms2_scans=ms2_scans,
                        target_precursor_mz=pmz,
                        ppm_tol=float(ms2_precursor_ppm_tol),
                        desired_rt_min=float(apex),
                        rt_tol_min=float(ms2_rt_tol),
                    )
                    if m2 is None:
                        continue
                    s2 = ms2_by_id.get(int(m2.scan_id))
                    if s2 is None:
                        continue
                    cache_key = (int(m2.scan_id), int(ms2_frag_topn))
                    frag_joined = ms2_frag_cache.get(cache_key)
                    if frag_joined is None:
                        mz2, int2 = d_reader.read_centroid_peaks(s2)
                        fr = top_n_fragments(mz2, int2, int(ms2_frag_topn))
                        frag_tokens = [f"{m3:.4f}@{rel:.3f}" for (m3, _it, rel) in fr]
                        frag_joined = "|".join(frag_tokens)
                        ms2_frag_cache[cache_key] = frag_joined
                    parts.append(f"prec={pmz:.4f};scan={m2.scan_id};frag_top{ms2_frag_topn}=" + frag_joined)
                ms2_summary = " || ".join(parts)

            def fmt_ms1(peaks2: List[Dict[str, object]]) -> str:
                toks2: List[str] = []
                for x in peaks2 or []:
                    try:
                        toks2.append(f"{float(x['mz']):.4f}@{float(x.get('intensity', 0.0)):.0f}")
                    except Exception:
                        continue
                return "|".join(toks2)

            row_dict: Dict[str, object] = {
                    "peak_index": int(idx) + 1,
                    "peak_id": peak_id,
                    "RT": rt_str,
                    "UV_Start": round(float(start_rt), 6) if start_rt is not None else None,
                    "UV_End": round(float(end_rt), 6) if end_rt is not None else None,
                    "Area_merge": r.get("Area_merge"),
                    "wavelength_used": wavelength,
                    "ms1_scan_id": scan_id,
                    "ms1_scan_count": len(window_scans) if window_scans else 0,
                    "ms1_rt_min": rt_ms1,
                    "ms1_base_mz": base_mz,
                    "ms1_base_abund": base_abund,
                    "ms1_top10": fmt_ms1(ms1_top),
                    "ms1_top5_filtered": fmt_ms1(kept2),
                    "ms1_top5_filtered_rel": ms1_top5_rel,
                    "ms1_top10_mz": ",".join([f"{float(x['mz']):.4f}" for x in ms1_top]) if ms1_top else "",
                    "ms1_top5_filtered_mz": ",".join([f"{float(x['mz']):.4f}" for x in kept2]) if kept2 else "",
                    "rule2_decimal_removed_count": r2_count,
                    "rule2_decimal_removed_mz": r2_mz_list,
                    "ms1_dedup_note": ms1_dedup_note,
                    "ms2_frag_top5": ms2_summary,
                }
            # 动态添加各波长的 Area/Height/Area_Percent/Area_Sum 列
            for ac in area_cols:
                wl_str2 = ac.replace("Area_", "")
                row_dict[f"Area_{wl_str2}"] = r.get(f"Area_{wl_str2}")
                row_dict[f"Height_{wl_str2}"] = r.get(f"Height_{wl_str2}")
                row_dict[f"Area_Percent_{wl_str2}"] = r.get(f"Area_Percent_{wl_str2}")
                row_dict[f"Area_Sum_{wl_str2}"] = r.get(f"Area_Sum_{wl_str2}")
            main_rows.append(row_dict)

        main_df = pd.DataFrame(main_rows)
        removed_df = pd.DataFrame(removed_rows)
        adduct_df = pd.DataFrame(adduct_rows)
        return main_df, removed_df, bg_df, adduct_df
