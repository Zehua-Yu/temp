"""
rde_analysis/background_ions.py

检测“从头到尾都有”的背景离子（无效信号）。

实现思路：
- 抽样读取 MS1 scan（每 step 张取 1 张）
- 每张取强度 topK 的 m/z
- 用 ppm 容差做简单聚类（近似去重）
- 统计每簇出现率与 RT 覆盖；满足阈值则输出为 background ions
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np

from ..rde_utils.mz_utils import mz_match_ppm


@dataclass
class BackgroundIon:
    mz: float
    hits: int
    scans_total: int
    presence_rate: float
    rt_min_hit: float
    rt_max_hit: float
    rt_min_total: float
    rt_max_total: float
    duration_min: float
    duration_ratio: float
    max_intensity: float
    avg_intensity: float
    score: float
    is_strict_background: bool
    median_intensity: float = 0.0
    peak_ratio: float = 0.0


@dataclass
class _Cluster:
    mz: float
    hits: int
    rt_min: float
    rt_max: float
    max_intensity: float
    sum_intensity: float
    intensities: list


def _topk_peaks(mz: np.ndarray, inten: np.ndarray, k: int) -> List[Tuple[float, float]]:
    if mz.size == 0 or inten.size == 0 or k <= 0:
        return []
    order = np.argsort(inten)[::-1]
    order = order[: max(0, int(k))]
    out: List[Tuple[float, float]] = []
    for idx in order:
        try:
            out.append((float(mz[idx]), float(inten[idx])))
        except Exception:
            continue
    return out


def _dedup_peaks_ppm_binned(
    peaks: List[Tuple[float, float]],
    *,
    ppm_factor: float,
    bin_width: float = 0.01,
) -> List[Tuple[float, float]]:
    """
    将 peaks（已按强度降序）做“近似去重”：
    - 保留第一个出现的峰
    - 后续若与任一已保留峰满足 |m-u| <= u*ppm_factor，则认为重复并跳过

    通过 m/z 分桶 + 邻桶检查，将每张 scan 内的去重从 O(k^2) 降为近似 O(k)。
    """
    if not peaks:
        return []

    used_bins: Dict[int, List[float]] = {}  # bin -> used mz list

    def bkey(x: float) -> int:
        return int(float(x) / float(bin_width))

    uniq: List[Tuple[float, float]] = []
    for m, it in peaks:
        m_f = float(m)
        b0 = bkey(m_f)
        hit = False
        # ppm 窗口很窄：只检查邻近桶即可（-1/0/+1）
        for bb in (b0 - 1, b0, b0 + 1):
            for u in used_bins.get(bb, []):
                if abs(m_f - float(u)) <= float(u) * float(ppm_factor):
                    hit = True
                    break
            if hit:
                break
        if hit:
            continue
        used_bins.setdefault(b0, []).append(m_f)
        uniq.append((m_f, float(it)))
    return uniq


def build_background_ions(
    *,
    ms1_scans,  # List[ScanRecord]
    d_reader,  # AgilentDReader
    ppm_tol: float,
    scan_step: int = 10,
    topk_per_scan: int = 50,
    presence_threshold: float = 0.8,
    edge_coverage_ratio: float = 0.05,
) -> Tuple[List[BackgroundIon], List[BackgroundIon]]:
    if not ms1_scans:
        return [], []
    ppm = float(ppm_tol)
    ppm_factor = ppm * 1e-6
    # 将 clusters 做一个粗粒度 m/z 桶索引，避免对每个峰都线性扫描所有簇
    # 0.01Da 对常见 QTOF 的 ppm 容差（1-10ppm）通常足够细；真实候选窗口按 m 的 ppm 动态扩展确保不漏
    bin_width = 0.01
    step = max(1, int(scan_step))
    scans_sampled = ms1_scans[::step]
    if not scans_sampled:
        scans_sampled = ms1_scans

    rt_min_total = float(min(s.rt_min for s in ms1_scans))
    rt_max_total = float(max(s.rt_min for s in ms1_scans))
    rt_span = max(1e-9, rt_max_total - rt_min_total)

    clusters: List[_Cluster] = []
    bin_map: Dict[int, List[int]] = {}  # bin -> [cluster_idx, ...]
    cluster_bin: List[int] = []  # cluster_idx -> current bin
    cluster_pos: List[int] = []  # cluster_idx -> position in bin_map[bin]
    scans_total = len(scans_sampled)

    def bin_key(x: float) -> int:
        return int(float(x) / float(bin_width))

    def bin_move(idx: int, new_mz: float) -> None:
        new_b = bin_key(float(new_mz))
        old_b = cluster_bin[idx]
        if new_b == old_b:
            return
        # remove from old bin list by swap-pop (O(1))
        lst = bin_map.get(old_b)
        if lst is not None:
            pos = cluster_pos[idx]
            last = lst[-1]
            lst[pos] = last
            cluster_pos[last] = pos
            lst.pop()
            if not lst:
                bin_map.pop(old_b, None)
        # add to new bin
        lst2 = bin_map.setdefault(new_b, [])
        cluster_pos[idx] = len(lst2)
        lst2.append(idx)
        cluster_bin[idx] = new_b

    def bin_add_new(idx: int, mz_val: float) -> None:
        b = bin_key(float(mz_val))
        lst = bin_map.setdefault(b, [])
        cluster_bin.append(b)
        cluster_pos.append(len(lst))
        lst.append(idx)

    for s in scans_sampled:
        mz, inten = d_reader.read_centroid_peaks(s)
        peaks = _topk_peaks(mz, inten, int(topk_per_scan))
        # 每张scan内先做一次“近似去重”：避免同位素/噪声重复计数过多
        peaks.sort(key=lambda x: x[1], reverse=True)
        uniq = _dedup_peaks_ppm_binned(peaks, ppm_factor=ppm_factor, bin_width=bin_width)

        for m, it in uniq:
            m_f = float(m)
            best_idx = -1
            best_ppm = None

            if clusters:
                # 以 m 为中心的动态候选桶范围（确保不漏：窗口略大于理论 ppm 容差）
                # 若 ppm_factor 极小（常见），ref≈m；否则做一个保守放大
                if ppm_factor < 0.5:
                    tol_abs = abs(m_f) * (ppm_factor / max(1e-12, 1.0 - ppm_factor))
                else:
                    tol_abs = abs(m_f) * ppm_factor
                span = int(tol_abs / float(bin_width)) + 3
                b0 = bin_key(m_f)
                for bb in range(b0 - span, b0 + span + 1):
                    for ci in bin_map.get(bb, []):
                        c = clusters[ci]
                        ref = float(c.mz)
                        if not (ref > 0):
                            continue
                        # 等价于 mz_match_ppm(obs=m, ref=ref, ppm_tol=ppm)
                        d = abs(m_f - ref)
                        if d <= ref * ppm_factor:
                            # 选 ppm 更近的簇；若 ppm_err 相同，选更早创建的簇（与原 enumerate 顺序一致）
                            ppm_err = d / ref * 1e6
                            if best_ppm is None or ppm_err < best_ppm or (ppm_err == best_ppm and ci < best_idx):
                                best_ppm = ppm_err
                                best_idx = ci

            if best_idx < 0:
                idx_new = len(clusters)
                clusters.append(
                    _Cluster(
                        mz=m_f,
                        hits=1,
                        rt_min=float(s.rt_min),
                        rt_max=float(s.rt_min),
                        max_intensity=float(it),
                        sum_intensity=float(it),
                        intensities=[float(it)],
                    )
                )
                bin_add_new(idx_new, m_f)
            else:
                c = clusters[best_idx]
                # 轻微更新代表mz（保持稳定，避免漂移过大）：用强度更大的那次作为代表
                if float(it) >= float(c.max_intensity):
                    c.mz = m_f
                    bin_move(best_idx, m_f)
                c.hits += 1
                c.rt_min = min(float(c.rt_min), float(s.rt_min))
                c.rt_max = max(float(c.rt_max), float(s.rt_min))
                c.max_intensity = max(float(c.max_intensity), float(it))
                c.sum_intensity += float(it)
                c.intensities.append(float(it))

    # ── 后处理：合并 representative m/z 在 merge_ppm 内的近邻簇 ──
    # 同一离子因测量波动（~2-3 ppm）可能被 1 ppm 聚类拆成多个簇，
    # 合并后 peak_ratio 取 max，避免副簇留在黑名单中。
    merge_ppm_factor = 5.0 * 1e-6  # 5 ppm 合并容差
    if len(clusters) > 1:
        order = sorted(range(len(clusters)), key=lambda i: clusters[i].mz)
        absorbed = [False] * len(clusters)
        for i_pos in range(len(order)):
            i = order[i_pos]
            if absorbed[i]:
                continue
            ci = clusters[i]
            for j_pos in range(i_pos + 1, len(order)):
                j = order[j_pos]
                if absorbed[j]:
                    continue
                cj = clusters[j]
                ref = max(ci.mz, cj.mz)
                if abs(ci.mz - cj.mz) > ref * merge_ppm_factor:
                    break  # 已排序，后续更远
                # 合并 j 到 i
                absorbed[j] = True
                if cj.max_intensity > ci.max_intensity:
                    ci.mz = cj.mz
                ci.hits += cj.hits
                ci.rt_min = min(ci.rt_min, cj.rt_min)
                ci.rt_max = max(ci.rt_max, cj.rt_max)
                ci.max_intensity = max(ci.max_intensity, cj.max_intensity)
                ci.sum_intensity += cj.sum_intensity
                ci.intensities.extend(cj.intensities)
        # hits 上限不超过采样 scan 数
        clusters = [c for i, c in enumerate(clusters) if not absorbed[i]]
        for c in clusters:
            if c.hits > scans_total:
                c.hits = scans_total

    strict_bg: List[BackgroundIon] = []
    candidates: List[BackgroundIon] = []
    left_edge = rt_min_total + rt_span * float(edge_coverage_ratio)
    right_edge = rt_max_total - rt_span * float(edge_coverage_ratio)

    for c in clusters:
        rate = float(c.hits) / float(scans_total) if scans_total > 0 else 0.0
        dur = max(0.0, float(c.rt_max) - float(c.rt_min))
        dur_ratio = float(dur / rt_span) if rt_span > 0 else 0.0
        is_strict = bool(
            rate >= float(presence_threshold)
            and float(c.rt_min) <= float(left_edge)
            and float(c.rt_max) >= float(right_edge)
        )

        avg_i = float(c.sum_intensity) / float(c.hits) if int(c.hits) > 0 else 0.0
        # 综合评分：持续覆盖 * sqrt(平均强度)，更偏向”又长又强”
        score = float(dur_ratio) * float(max(0.0, avg_i) ** 0.5)

        median_i = float(np.median(c.intensities)) if c.intensities else 0.0
        peak_ratio = float(c.max_intensity / median_i) if median_i > 0 else float('inf')

        ion = BackgroundIon(
            mz=float(c.mz),
            hits=int(c.hits),
            scans_total=int(scans_total),
            presence_rate=rate,
            rt_min_hit=float(c.rt_min),
            rt_max_hit=float(c.rt_max),
            rt_min_total=float(rt_min_total),
            rt_max_total=float(rt_max_total),
            duration_min=dur,
            duration_ratio=dur_ratio,
            max_intensity=float(c.max_intensity),
            avg_intensity=float(avg_i),
            score=float(score),
            is_strict_background=is_strict,
            median_intensity=median_i,
            peak_ratio=peak_ratio,
        )
        candidates.append(ion)
        if not is_strict:
            continue
        strict_bg.append(
            BackgroundIon(
                mz=ion.mz,
                hits=ion.hits,
                scans_total=ion.scans_total,
                presence_rate=ion.presence_rate,
                rt_min_hit=ion.rt_min_hit,
                rt_max_hit=ion.rt_max_hit,
                rt_min_total=ion.rt_min_total,
                rt_max_total=ion.rt_max_total,
                duration_min=ion.duration_min,
                duration_ratio=ion.duration_ratio,
                max_intensity=ion.max_intensity,
                avg_intensity=ion.avg_intensity,
                score=ion.score,
                is_strict_background=True,
                median_intensity=ion.median_intensity,
                peak_ratio=ion.peak_ratio,
            )
        )

    # strict 用出现率/强度排序（用于过滤）
    strict_bg.sort(key=lambda x: (x.presence_rate, x.max_intensity), reverse=True)
    # candidates 用“持续时间+平均强度”综合评分排序（用于展示）
    candidates.sort(key=lambda x: (x.score, x.duration_ratio, x.avg_intensity, x.presence_rate), reverse=True)
    return strict_bg, candidates

