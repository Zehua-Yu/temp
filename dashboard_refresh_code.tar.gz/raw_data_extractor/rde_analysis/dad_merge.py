"""
rde_analysis/dad_merge.py

合并任意数量的 DAD 波长峰表：
- 按 RT 最近邻对齐（在 rt_tol_min 内视为同一峰）
- 输出 merged DataFrame：保留各波长 Peak/RT/Start/End/Area/Height，并给出 Area_merge
- 波长泛化：自动适配 220/230/254 等任意波长组合
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Tuple

import pandas as pd


def _to_float(x: object) -> Optional[float]:
    try:
        if x is None or x == "":
            return None
        return float(x)
    except Exception:
        return None


def merge_dad_peak_tables(
    *,
    dad_tables: Dict[int, pd.DataFrame],
    parse_rt_value: Callable[[object], Optional[float]],
    rt_tol_min: float = 0.05,
    area_merge_mode: str = "max",
) -> pd.DataFrame:
    """
    输入 dad_tables: Dict[int, DataFrame]，key 为波长 nm（如 220, 254），
    DataFrame 需包含列：Peak, Start, RT, End, Area, Height（缺失可为空）。

    area_merge_mode:
    - "max": Area_merge = max(各波长 Area)
    - "sum": Area_merge = sum(各波长 Area)（缺失按0）
    """
    if not dad_tables:
        return pd.DataFrame()

    def normalize(df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        if "RT" in out.columns:
            out["_rt"] = out["RT"].apply(lambda x: parse_rt_value(x))
        else:
            out["_rt"] = None
        for c in ("Area", "Height", "Start", "End"):
            if c in out.columns:
                out[c] = pd.to_numeric(out[c], errors="coerce")
        if "Peak" in out.columns:
            out["Peak"] = pd.to_numeric(out["Peak"], errors="coerce")
        out = out[out["_rt"].notna()].copy()
        out["_rt"] = out["_rt"].astype(float)
        out = out.sort_values("_rt").reset_index(drop=True)
        return out

    wls = sorted(dad_tables.keys())
    normed: Dict[int, pd.DataFrame] = {}
    for wl in wls:
        df = dad_tables[wl]
        if isinstance(df, pd.DataFrame) and not df.empty:
            normed[wl] = normalize(df)

    wls = [w for w in wls if w in normed and not normed[w].empty]
    if not wls:
        return pd.DataFrame()

    # 单波长快捷路径
    if len(wls) == 1:
        wl = wls[0]
        d = normed[wl]
        rows: List[Dict[str, object]] = []
        for i in range(len(d)):
            row = d.iloc[i]
            rt = float(row["_rt"])
            area = _to_float(row.get("Area"))
            r: Dict[str, object] = {
                "RT": f"{rt:.3f}",
                f"RT_{wl}": f"{rt:.3f}",
                f"Peak_{wl}": None if pd.isna(row.get("Peak")) else int(row.get("Peak")),
                f"Start_{wl}": _to_float(row.get("Start")),
                f"End_{wl}": _to_float(row.get("End")),
                f"Height_{wl}": _to_float(row.get("Height")),
                f"Area_{wl}": area,
                f"Area_Percent_{wl}": _to_float(row.get("Area_Percent")),
                f"Area_Sum_{wl}": _to_float(row.get("Area_Sum")),
                "Area_merge": area,
            }
            rows.append(r)
        out = pd.DataFrame(rows)
        if not out.empty:
            out["Area_merge"] = pd.to_numeric(out["Area_merge"], errors="coerce")
            out = out.sort_values(["Area_merge", "RT"], ascending=[False, True], na_position="last").reset_index(drop=True)
        return out

    # 多波长合并：以第一个波长为基准，逐个合并后续波长
    # 构建一个统一的 RT 索引

    # 收集所有波长的 (rt, wl, idx) 列表
    all_entries: List[Tuple[float, int, int]] = []
    for wl in wls:
        for i in range(len(normed[wl])):
            all_entries.append((float(normed[wl].loc[i, "_rt"]), wl, i))
    all_entries.sort(key=lambda x: x[0])

    # 贪心聚类：按 RT 排序，相邻峰 RT 差 <= tol 归为一组
    groups: List[Dict[int, int]] = []  # 每组: {wl: idx_in_normed}
    used: set = set()

    for wl in wls:
        d = normed[wl]
        for i in range(len(d)):
            if (wl, i) in used:
                continue
            rt_i = float(d.loc[i, "_rt"])
            group: Dict[int, int] = {wl: i}
            used.add((wl, i))

            # 在其他波长中找最近邻
            for wl2 in wls:
                if wl2 == wl or wl2 in group:
                    continue
                d2 = normed[wl2]
                best_j = None
                best_diff = None
                for j in range(len(d2)):
                    if (wl2, j) in used:
                        continue
                    diff = abs(float(d2.loc[j, "_rt"]) - rt_i)
                    if diff <= float(rt_tol_min) and (best_diff is None or diff < best_diff):
                        best_diff = diff
                        best_j = j
                if best_j is not None:
                    group[wl2] = best_j
                    used.add((wl2, best_j))

            groups.append(group)

    rows2: List[Dict[str, object]] = []
    for group in groups:
        # 确定统一 RT：取各波长 RT 的均值
        rts = [float(normed[w].loc[idx, "_rt"]) for w, idx in group.items()]
        rt_avg = sum(rts) / len(rts)

        row_dict: Dict[str, object] = {"RT": f"{rt_avg:.3f}"}
        areas: List[float] = []

        for wl in wls:
            if wl in group:
                r = normed[wl].iloc[group[wl]]
                rt_w = float(r["_rt"])
                area = _to_float(r.get("Area"))
                row_dict[f"RT_{wl}"] = f"{rt_w:.3f}"
                row_dict[f"Peak_{wl}"] = None if pd.isna(r.get("Peak")) else int(r.get("Peak"))
                row_dict[f"Start_{wl}"] = _to_float(r.get("Start"))
                row_dict[f"End_{wl}"] = _to_float(r.get("End"))
                row_dict[f"Height_{wl}"] = _to_float(r.get("Height"))
                row_dict[f"Area_{wl}"] = area
                row_dict[f"Area_Percent_{wl}"] = _to_float(r.get("Area_Percent"))
                row_dict[f"Area_Sum_{wl}"] = _to_float(r.get("Area_Sum"))
                if area is not None:
                    areas.append(area)
            else:
                row_dict[f"RT_{wl}"] = None
                row_dict[f"Peak_{wl}"] = None
                row_dict[f"Start_{wl}"] = None
                row_dict[f"End_{wl}"] = None
                row_dict[f"Height_{wl}"] = None
                row_dict[f"Area_{wl}"] = None
                row_dict[f"Area_Percent_{wl}"] = None
                row_dict[f"Area_Sum_{wl}"] = None

        if area_merge_mode == "sum":
            row_dict["Area_merge"] = sum(areas) if areas else None
        else:
            row_dict["Area_merge"] = max(areas) if areas else None

        rows2.append(row_dict)

    out = pd.DataFrame(rows2)
    if not out.empty:
        out["Area_merge"] = pd.to_numeric(out["Area_merge"], errors="coerce")
        out = out.sort_values(["Area_merge", "RT"], ascending=[False, True], na_position="last").reset_index(drop=True)
    return out

