"""
rde_analysis/ms2_utils.py

MS2 scan 匹配与碎片 topN 提取（用于样品峰级分析）。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from ..rde_utils.mz_utils import mz_error_ppm, mz_match_ppm


@dataclass(frozen=True)
class Ms2MatchResult:
    scan_id: int
    rt_min: float
    precursor_mz: float
    collision_energy: float
    ppm_error: Optional[float]


def match_best_ms2_scan(
    *,
    ms2_scans,  # List[ScanRecord]
    target_precursor_mz: float,
    ppm_tol: float,
    desired_rt_min: float,
    rt_tol_min: float,
) -> Optional[Ms2MatchResult]:
    """
    在 RT 窗口内找最合适的 MS2：
    - ppm 误差更小优先
    - RT 更接近 desired_rt 优先
    - base_peak_value 更大优先
    """
    cands = []
    for s in ms2_scans or []:
        if getattr(s, "ms_level", None) != 2:
            continue
        pmz = getattr(s, "precursor_mz", None)
        if pmz is None:
            continue
        try:
            pmz_f = float(pmz)
        except Exception:
            continue
        if pmz_f <= 0:
            continue
        if abs(float(s.rt_min) - float(desired_rt_min)) > float(rt_tol_min):
            continue
        if not mz_match_ppm(obs_mz=pmz_f, ref_mz=float(target_precursor_mz), ppm_tol=float(ppm_tol)):
            continue
        ppm_err = mz_error_ppm(obs_mz=pmz_f, ref_mz=float(target_precursor_mz))
        drt = abs(float(s.rt_min) - float(desired_rt_min))
        bpv = float(getattr(s, "base_peak_value", 0.0) or 0.0)
        # sort key: drt, |ppm|, -bpv
        # ppm 已在上面做了容差门槛过滤，RT 距离最近的更可能是同一化合物
        cands.append((drt, abs(ppm_err) if ppm_err is not None else 1e9, -bpv, s, ppm_err))
    if not cands:
        return None
    cands.sort(key=lambda x: (x[0], x[1], x[2]))
    _ppm_abs, _drt, _nbpv, s, ppm_err = cands[0]
    return Ms2MatchResult(
        scan_id=int(s.scan_id),
        rt_min=float(s.rt_min),
        precursor_mz=float(s.precursor_mz),
        collision_energy=float(getattr(s, "collision_energy", 0.0) or 0.0),
        ppm_error=ppm_err,
    )


def top_n_fragments(mz: np.ndarray, inten: np.ndarray, n: int) -> List[Tuple[float, float, float]]:
    """
    返回 [(mz, intensity, rel)]，按 intensity 降序，rel 以 base-peak=1.0。
    """
    if mz.size == 0 or inten.size == 0 or n <= 0:
        return []
    order = np.argsort(inten)[::-1]
    order = order[: max(0, int(n))]
    if order.size == 0:
        return []
    bpi = float(inten[order[0]]) if float(inten[order[0]]) > 0 else 1.0
    out: List[Tuple[float, float, float]] = []
    for idx in order:
        m = float(mz[idx])
        it = float(inten[idx])
        rel = float(it / bpi) if bpi > 0 else 0.0
        out.append((m, it, rel))
    return out

