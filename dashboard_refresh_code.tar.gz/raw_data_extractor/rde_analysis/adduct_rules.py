"""
rde_analysis/adduct_rules.py

加合离子/同位关系检测：2M+1, M+36, M+46, M-36, M-46 同 RT 共现证据。

对 top-N 个 MS1 峰逐一作为 M 候选，输出多条 AdductEvidence。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from ..rde_utils.mz_utils import mz_error_ppm, mz_match_ppm

# 精确质量偏移（负离子模式，相对于 [M-H]⁻ 的 m/z 差值）
_PROTON_MASS = 1.007276       # 质子精确质量 (Da)
_DELTA_2M1 = _PROTON_MASS     # [2M-H]⁻ vs [M-H]⁻ 差值 = 质子质量
_DELTA_M_PLUS_36 = 35.976678  # [M+Cl]⁻ vs [M-H]⁻ = Cl⁻(34.96885) + H⁺(1.00728)
_DELTA_M_PLUS_46 = 46.005477  # [M+HCOO]⁻ vs [M-H]⁻ = HCOO⁻(44.99820) + H⁺(1.00728)
_DELTA_M_MINUS_36 = 35.976678 # 丢失 HCl 的精确质量
_DELTA_M_MINUS_46 = 46.005477 # 丢失 HCOOH 的精确质量


@dataclass(frozen=True)
class AdductEvidence:
    rt: str
    candidate_rank: int
    m_mz: Optional[float]
    m_intensity: Optional[float]
    # 2M+1
    hit_2m_plus_1: bool
    mz_2m1: Optional[float]
    ppm_err_2m1: Optional[float]
    # M+36
    hit_m_plus_36: bool
    m_plus_36_mz: Optional[float]
    ppm_err_36: Optional[float]
    # M+46
    hit_m_plus_46: bool
    m_plus_46_mz: Optional[float]
    ppm_err_46: Optional[float]
    # M-36
    hit_m_minus_36: bool
    m_minus_36_mz: Optional[float]
    ppm_err_m36: Optional[float]
    # M-46
    hit_m_minus_46: bool
    m_minus_46_mz: Optional[float]
    ppm_err_m46: Optional[float]


def _empty_evidence(rt: str, rank: int) -> AdductEvidence:
    return AdductEvidence(
        rt=rt, candidate_rank=rank, m_mz=None, m_intensity=None,
        hit_2m_plus_1=False, mz_2m1=None, ppm_err_2m1=None,
        hit_m_plus_36=False, m_plus_36_mz=None, ppm_err_36=None,
        hit_m_plus_46=False, m_plus_46_mz=None, ppm_err_46=None,
        hit_m_minus_36=False, m_minus_36_mz=None, ppm_err_m36=None,
        hit_m_minus_46=False, m_minus_46_mz=None, ppm_err_m46=None,
    )


def _find_target(
    *,
    peaks: List[Dict[str, object]],
    target_mz: float,
    ppm_tol: float,
) -> Tuple[bool, Optional[float], Optional[float], Optional[float]]:
    """
    peaks: list of {"mz":float, "intensity":float, ...}
    返回：(hit, matched_mz, matched_intensity, ppm_error)
    """
    best = None
    best_ppm = None
    for p in peaks or []:
        try:
            m = float(p.get("mz"))  # type: ignore[arg-type]
            it = float(p.get("intensity", 0.0))  # type: ignore[arg-type]
        except Exception:
            continue
        if not mz_match_ppm(obs_mz=m, ref_mz=float(target_mz), ppm_tol=float(ppm_tol)):
            continue
        ppm_err = mz_error_ppm(obs_mz=m, ref_mz=float(target_mz))
        ppm_abs = abs(ppm_err) if ppm_err is not None else 1e9
        if best_ppm is None or ppm_abs < best_ppm:
            best_ppm = ppm_abs
            best = (m, it, ppm_err)
    if best is None:
        return False, None, None, None
    return True, best[0], best[1], best[2]


def detect_adducts_multi(
    *,
    rt: str,
    peaks_top: List[Dict[str, object]],
    ppm_tol: float,
    max_candidates: int = 5,
) -> List[AdductEvidence]:
    """
    对 peaks_top 中前 max_candidates 个峰逐一作为 M 候选，
    检测是否存在 2M+1 / M+36 / M+46 / M-36 / M-46。

    返回 list[AdductEvidence]，每个候选一条。
    """
    results: List[AdductEvidence] = []
    if not peaks_top:
        return results

    n = min(max_candidates, len(peaks_top))
    for rank, p in enumerate(peaks_top[:n], start=1):
        try:
            m_mz = float(p["mz"])
            m_it = float(p.get("intensity", 0.0))
        except Exception:
            results.append(_empty_evidence(rt, rank))
            continue

        hit_2m1, mz_2m1, _it_2m1, ppm_2m1 = _find_target(peaks=peaks_top, target_mz=2.0 * m_mz + _DELTA_2M1, ppm_tol=ppm_tol)
        hit_p36, mz_p36, _it_p36, ppm_p36 = _find_target(peaks=peaks_top, target_mz=m_mz + _DELTA_M_PLUS_36, ppm_tol=ppm_tol)
        hit_p46, mz_p46, _it_p46, ppm_p46 = _find_target(peaks=peaks_top, target_mz=m_mz + _DELTA_M_PLUS_46, ppm_tol=ppm_tol)
        hit_m36, mz_m36, _it_m36, ppm_m36 = _find_target(peaks=peaks_top, target_mz=m_mz - _DELTA_M_MINUS_36, ppm_tol=ppm_tol)
        hit_m46, mz_m46, _it_m46, ppm_m46 = _find_target(peaks=peaks_top, target_mz=m_mz - _DELTA_M_MINUS_46, ppm_tol=ppm_tol)

        results.append(
            AdductEvidence(
                rt=rt,
                candidate_rank=rank,
                m_mz=float(m_mz),
                m_intensity=float(m_it),
                hit_2m_plus_1=bool(hit_2m1),
                mz_2m1=mz_2m1,
                ppm_err_2m1=ppm_2m1,
                hit_m_plus_36=bool(hit_p36),
                m_plus_36_mz=mz_p36,
                ppm_err_36=ppm_p36,
                hit_m_plus_46=bool(hit_p46),
                m_plus_46_mz=mz_p46,
                ppm_err_46=ppm_p46,
                hit_m_minus_36=bool(hit_m36),
                m_minus_36_mz=mz_m36,
                ppm_err_m36=ppm_m36,
                hit_m_minus_46=bool(hit_m46),
                m_minus_46_mz=mz_m46,
                ppm_err_m46=ppm_m46,
            )
        )

    return results


# 兼容旧接口名（内部转发）
def detect_m_plus_34_46_multi(
    *,
    rt: str,
    peaks_top: List[Dict[str, object]],
    ppm_tol: float,
    max_candidates: int = 5,
) -> List[AdductEvidence]:
    return detect_adducts_multi(rt=rt, peaks_top=peaks_top, ppm_tol=ppm_tol, max_candidates=max_candidates)


def detect_m_plus_34_46(
    *,
    rt: str,
    peaks_top: List[Dict[str, object]],
    ppm_tol: float,
) -> AdductEvidence:
    results = detect_adducts_multi(rt=rt, peaks_top=peaks_top, ppm_tol=ppm_tol, max_candidates=1)
    if results:
        return results[0]
    return _empty_evidence(rt, 1)
