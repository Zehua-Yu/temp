#!/usr/bin/env python3
"""
MinIO文件同步服务主程序
"""

import sys
import signal
import argparse
import os
import subprocess
from dotenv import load_dotenv
from loguru import logger

# 加载环境配置
# 优先级: env_local.txt > env_test.txt > .env
env_files = ['env_local.txt', 'env_test.txt', '.env']
for env_file in env_files:
    if os.path.exists(env_file):
        load_dotenv(env_file, override=True)
        print(f"已加载环境配置: {env_file}")
        break

from config import Config
from minio_client import MinioClient
from file_sync import FileSyncService
from sync_scheduler import SyncScheduler


report_server_process = None


def start_report_server():
    """Start the embedded report server when this container runs the sync loop."""
    global report_server_process
    if report_server_process and report_server_process.poll() is None:
        return

    report_server_process = subprocess.Popen(
        [sys.executable, "report_server.py"],
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    logger.info(
        f"LCMS HTML报告服务已启动: port={Config.REPORT_SERVER_PORT}, "
        f"base_url={Config.REPORT_BASE_URL}"
    )


def stop_report_server():
    """Stop the embedded report server if it was started by this process."""
    global report_server_process
    if report_server_process and report_server_process.poll() is None:
        report_server_process.terminate()
        try:
            report_server_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            report_server_process.kill()
    report_server_process = None


def setup_logging():
    """设置日志配置"""
    logger.remove()  # 移除默认处理器
    
    # 添加控制台处理器
    logger.add(
        sys.stdout,
        level=Config.LOG_LEVEL,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    )
    
    # 添加文件处理器
    logger.add(
        Config.LOG_FILE,
        level=Config.LOG_LEVEL,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        rotation="1 day",
        retention="7 days"
    )


def test_connection():
    """测试MinIO连接"""
    try:
        client = MinioClient()
        if client.bucket_exists(Config.MINIO_BUCKET):
            logger.info(f"✅ 成功连接到MinIO服务器，bucket '{Config.MINIO_BUCKET}' 存在")
            return True
        else:
            logger.error(f"❌ bucket '{Config.MINIO_BUCKET}' 不存在")
            return False
    except Exception as e:
        logger.error(f"❌ 连接MinIO服务器失败: {e}")
        return False


def list_files():
    """列出MinIO中的文件"""
    try:
        client = MinioClient()
        objects = client.list_objects()
        
        if not objects:
            logger.info("没有找到文件")
            return
        
        logger.info(f"找到 {len(objects)} 个文件:")
        for obj in objects:
            logger.info(f"  📄 {obj['name']} ({obj['size']} bytes, 修改时间: {obj['last_modified']})")
    
    except Exception as e:
        logger.error(f"列出文件失败: {e}")


def sync_once():
    """执行一次同步"""
    try:
        sync_service = FileSyncService()
        stats = sync_service.sync_files()
        logger.info(f"同步完成: {stats}")
    except Exception as e:
        logger.error(f"同步失败: {e}")


def start_daemon():
    """启动守护进程模式"""
    def signal_handler(signum, frame):
        logger.info("收到停止信号，正在关闭...")
        scheduler.stop_scheduler()
        stop_report_server()
        sys.exit(0)
    
    # 注册信号处理器
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 启动调度器
    scheduler = SyncScheduler()
    scheduler.start_scheduler()
    
    logger.info("守护进程已启动，按 Ctrl+C 停止")
    
    try:
        # 保持主线程运行
        while True:
            signal.pause()
    except KeyboardInterrupt:
        logger.info("收到键盘中断信号")
        scheduler.stop_scheduler()


def interactive_mode():
    """交互式模式"""
    scheduler = SyncScheduler()
    
    print("\n=== MinIO文件同步服务 ===")
    print("可用命令:")
    print("  test     - 测试MinIO连接")
    print("  list     - 列出MinIO中的文件")
    print("  sync     - 执行一次同步")
    print("  start    - 启动定时同步")
    print("  stop     - 停止定时同步")
    print("  status   - 查看状态")
    print("  files    - 查看已同步文件")
    print("  quit     - 退出")
    print()
    
    while True:
        try:
            command = input("请输入命令: ").strip().lower()
            
            if command == 'quit':
                break
            elif command == 'test':
                test_connection()
            elif command == 'list':
                list_files()
            elif command == 'sync':
                sync_once()
            elif command == 'start':
                scheduler.start_scheduler()
            elif command == 'stop':
                scheduler.stop_scheduler()
            elif command == 'status':
                status = scheduler.get_status()
                print(f"调度器运行状态: {'运行中' if status['is_running'] else '已停止'}")
                print(f"同步间隔: {status['sync_interval']} 秒")
                print(f"已同步文件数: {status['sync_status']['synced_files_count']}")
                print(f"下载目录: {status['sync_status']['download_dir']}")
            elif command == 'files':
                files = scheduler.sync_service.list_synced_files()
                if files:
                    print(f"已同步 {len(files)} 个文件:")
                    for file in files[-10:]:  # 显示最近10个文件
                        print(f"  📄 {file['object_name']} -> {file['local_path']}")
                else:
                    print("暂无已同步文件")
            else:
                print("未知命令，请重试")
            
            print()
            
        except KeyboardInterrupt:
            print("\n退出程序")
            break
        except Exception as e:
            logger.error(f"执行命令时发生错误: {e}")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='MinIO文件同步服务')
    parser.add_argument('--test', action='store_true', help='测试MinIO连接')
    parser.add_argument('--list', action='store_true', help='列出MinIO中的文件')
    parser.add_argument('--sync', action='store_true', help='执行一次同步')
    parser.add_argument('--daemon', action='store_true', help='启动守护进程模式')
    parser.add_argument('--interactive', action='store_true', help='启动交互式模式')
    
    args = parser.parse_args()
    
    # 设置日志
    setup_logging()
    
    # 检查环境变量
    if not Config.MINIO_ACCESS_KEY or not Config.MINIO_SECRET_KEY:
        logger.error("请设置MINIO_ACCESS_KEY和MINIO_SECRET_KEY环境变量")
        sys.exit(1)
    
    # 执行相应操作
    if args.test:
        test_connection()
    elif args.list:
        list_files()
    elif args.sync:
        start_report_server()
        # 每分钟执行一次同步
        import time
        from datetime import datetime
        
        print("\n=== 每分钟执行一次同步 ===")
        print("按 Ctrl+C 停止程序")
        print()
        
        try:
            while True:
                current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                print(f"\n🔄 执行同步 - {current_time}")
                
                try:
                    sync_once()
                    print("✅ 同步完成")
                except Exception as e:
                    print(f"❌ 同步失败: {e}")
                
                print("⏰ 等待5分钟后继续...")
                time.sleep(300)
        finally:
            stop_report_server()
    elif args.daemon:
        start_report_server()
        start_daemon()
    elif args.interactive:
        interactive_mode()
    else:
        # 默认启动交互式模式
        interactive_mode()


if __name__ == '__main__':
    main() 
