import requests
import os
import shutil
from urllib.parse import urlparse
from pathlib import Path

def download_pdf(url, save_directory="downloads"):
    """
    下载PDF文件到本地
    
    Args:
        url (str): PDF文件的URL
        save_directory (str): 保存文件的目录，默认为'downloads'
    
    Returns:
        str: 下载成功返回文件路径，失败返回None
    """
    try:
        # 从URL中提取文件名
        parsed_url = urlparse(url)
        filename = os.path.basename(parsed_url.path)
        
        # 如果没有文件名，使用默认名称
        if not filename or not filename.endswith('.pdf'):
            filename = "downloaded_file.pdf"
        
        # 提取文件名（不包含扩展名）作为文件夹名称
        filename_without_ext = os.path.splitext(filename)[0]
        
        # 创建以PDF文件名为名称的子文件夹
        pdf_folder = os.path.join(save_directory, filename_without_ext)
        Path(pdf_folder).mkdir(parents=True, exist_ok=True)
        
        # 完整的文件路径（保存在以文件名命名的文件夹中）
        file_path = os.path.join(pdf_folder, filename)
        
        print(f"正在下载PDF文件: {url}")
        print(f"保存到: {file_path}")
        
        # 发送GET请求下载文件
        response = requests.get(url, stream=True)
        response.raise_for_status()  # 检查请求是否成功
        
        # 写入文件
        with open(file_path, 'wb') as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)
        
        print(f"下载完成! 文件保存在: {file_path}")
        return file_path
        
    except requests.exceptions.RequestException as e:
        print(f"下载失败 - 网络错误: {e}")
        return None
    except Exception as e:
        print(f"下载失败 - 其他错误: {e}")
        return None

def main(pdf_url):
    """
    主函数 - 下载指定URL的PDF文件
    
    Args:
        pdf_url (str): 要下载的PDF文件URL
    
    Returns:
        str: 下载成功返回文件路径，失败返回None
    """
    # 下载PDF文件
    downloaded_file = download_pdf(pdf_url)
    
    if downloaded_file:
        print("PDF下载成功!")
        return downloaded_file
    else:
        print("PDF下载失败!")
        return None

def _normalize_unc_path(path_str):
    """将 CSV 中的报告路径翻译为容器内 SMB 挂载路径。

    宿主机已挂载：
      //172.19.13.37/data    → /mnt/reports/qtof_raw_file
      //172.19.13.37/Reports → /mnt/reports/qtof_pdf
      http://.../reports/qtof_raw_file → /mnt/reports/qtof_raw_file
      http://.../reports/qtof_pdf      → /mnt/reports/qtof_pdf
    """
    _UNC_MAPPINGS = {
        '//172.19.13.37/data/': '/mnt/reports/qtof_raw_file/',
        '//172.19.13.37/Reports/': '/mnt/reports/qtof_pdf/',
    }
    for unc_prefix, local_prefix in _UNC_MAPPINGS.items():
        if path_str.startswith(unc_prefix):
            return local_prefix + path_str[len(unc_prefix):]

    parsed_url = urlparse(path_str)
    if parsed_url.scheme in ('http', 'https'):
        _HTTP_PATH_MAPPINGS = {
            '/reports/qtof_raw_file/': '/mnt/reports/qtof_raw_file/',
            '/reports/qtof_pdf/': '/mnt/reports/qtof_pdf/',
        }
        for url_prefix, local_prefix in _HTTP_PATH_MAPPINGS.items():
            if parsed_url.path.startswith(url_prefix):
                return local_prefix + parsed_url.path[len(url_prefix):]

    # 兜底：原逻辑
    normalized = path_str.replace('/', os.sep)
    if not normalized.startswith(os.sep + os.sep):
        normalized = os.sep + os.sep + normalized.lstrip(os.sep)
    return normalized

def copy_d_directory(unc_path, save_directory="downloads"):
    """将网络共享上的 .d 目录复制到本地。

    Args:
        unc_path: .d 目录的 UNC 路径，如 //172.19.13.37/data/xxx.d
        save_directory: 本地保存目录

    Returns:
        str: 本地 .d 目录路径，失败返回 None
    """
    try:
        src = _normalize_unc_path(unc_path)
        dirname = os.path.basename(src)

        if not os.path.isdir(src):
            print(f".d 目录不存在或不可访问: {src}")
            return None

        dst = os.path.join(save_directory, dirname)
        if os.path.exists(dst):
            shutil.rmtree(dst)

        print(f"复制 .d 目录: {src} -> {dst}")
        shutil.copytree(src, dst)
        print(f"复制完成: {dst}")
        return dst

    except Exception as e:
        print(f"复制 .d 目录失败: {e}")
        return None

def copy_pdf_file(unc_path, save_directory="downloads"):
    """将网络共享上的 PDF 文件复制到本地。

    Args:
        unc_path: PDF 文件的 UNC 路径
        save_directory: 本地保存目录

    Returns:
        str: 本地 PDF 文件路径，失败返回 None
    """
    try:
        src = _normalize_unc_path(unc_path)
        filename = os.path.basename(src)

        if not os.path.isfile(src):
            print(f"PDF 文件不存在或不可访问: {src}")
            return None

        stem = os.path.splitext(filename)[0]
        dst_dir = os.path.join(save_directory, stem)
        Path(dst_dir).mkdir(parents=True, exist_ok=True)
        dst = os.path.join(dst_dir, filename)

        print(f"复制 PDF: {src} -> {dst}")
        shutil.copy2(src, dst)
        return dst

    except Exception as e:
        print(f"复制 PDF 失败: {e}")
        return None


if __name__ == "__main__":
    # 默认的PDF URL（可以根据需要修改）
    default_pdf_url = "http://172.17.15.123/reports/qtof_pdf/qtof_z00101-E-7-2_2025_09_10_07_08_09/20250910064101-z00101-E-7-2_Analysis.pdf"
    main(default_pdf_url)
