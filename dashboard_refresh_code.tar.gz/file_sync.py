#!/usr/bin/env python3
"""
文件同步服务
支持多数据源的文件下载、处理和上传
"""

import os
import json
from datetime import datetime
from typing import Dict, List, Any
from loguru import logger
from config import Config
from minio_client import MinioClient
from data_processor import DataProcessor
from sync_state_manager import SyncStateManager


SKIP_OBJECT_NAMES = {
    "REALITY/REPORT/lcms/QTOF/qtof_report_20251225_171615.csv",
    "REALITY/REPORT/lcms/QTOF/qtof_report_20260306_085640.csv",
    "REALITY/REPORT/lcms/QTOF/qtof_report_20260317_205236.csv",
    "REALITY/REPORT/lcms/QTOF/qtof_report_20260317_210216.csv",
    "REALITY/REPORT/lcms/QTOF/qtof_report_20260317_211637.csv",
    "REALITY/REPORT/lcms/QTOF/qtof_report_20260327_170743.csv",
}


class FileSyncService:
    """文件同步服务"""
    
    def __init__(self):
        self.minio_client = MinioClient()
        self.data_processor = DataProcessor()
        self.state_manager = SyncStateManager()
        os.makedirs(Config.LOCAL_DOWNLOAD_DIR, exist_ok=True)
        self.sync_sources = self._parse_sync_sources()
    
    def _parse_sync_sources(self) -> List[Dict[str, str]]:
        """解析同步源配置
        
        Returns:
            同步源配置列表，每个元素包含 prefix, table_name, processor_type
        """
        sources = []
        sync_sources_str = Config.SYNC_SOURCES
        
        if sync_sources_str:
            for source_config in sync_sources_str.split(','):
                source_config = source_config.strip()
                if ':' in source_config:
                    parts = source_config.split(':')
                    if len(parts) == 3:
                        sources.append({
                            'prefix': parts[0].strip(),
                            'table_name': parts[1].strip(),
                            'processor_type': parts[2].strip()
                        })
                    else:
                        logger.warning(f"无效的同步源配置格式: {source_config}")
                else:
                    # 兼容旧格式，默认使用chemist处理器和t_chemist_data表
                    sources.append({
                        'prefix': source_config,
                        'table_name': 't_chemist_data',
                        'processor_type': 'chemist'
                    })
        
        logger.info(f"解析到 {len(sources)} 个同步源配置: {sources}")
        return sources
    
    def _save_sync_state(self):
        """保存同步状态 - 已废弃，使用state_manager"""
        # 不再需要这个方法，state_manager会自动处理
        pass
    
    def _get_source_prefix(self, object_name: str) -> str:
        """
        根据对象名称确定数据源前缀
        """
        # 获取所有可用的数据源前缀
        available_prefixes = list(self.data_processor.source_configs.keys())
        
        # 按长度排序，优先匹配更长的前缀
        available_prefixes.sort(key=len, reverse=True)
        
        for prefix in available_prefixes:
            if object_name.startswith(prefix):
                return prefix
        
        return ""
    
    def sync_files(self, bucket: str = None) -> Dict[str, int]:
        """
        同步所有配置的数据源
        
        Args:
            bucket: MinIO桶名，默认使用配置中的桶
            
        Returns:
            同步统计信息
        """
        bucket = bucket or Config.MINIO_BUCKET
        
        logger.info(f"开始同步所有配置的数据源: bucket={bucket}")
        
        total_stats = {
            'total_objects': 0,
            'downloaded_files': 0,
            'processed_files': 0,
            'failed_files': 0,
            'total_records': 0,
            'created_records': 0,
            'updated_records': 0,
            'error_records': 0
        }
        
        try:
            # 遍历所有配置的同步源
            for source_config in self.sync_sources:
                logger.info(f"同步数据源: {source_config}")
                source_stats = self.sync_specific_source(
                    source_config['prefix'], 
                    bucket, 
                    source_config['table_name'],
                    source_config['processor_type']
                )
                
                # 合并统计信息
                for key in total_stats:
                    total_stats[key] += source_stats.get(key, 0)
            
            
            logger.info(f"所有数据源同步完成: {total_stats}")
            return total_stats
            
        except Exception as e:
            logger.error(f"同步失败: {e}")
            return total_stats
    
    def sync_specific_source(self, source_prefix: str, bucket: str = None, 
                           table_name: str = None, processor_type: str = None) -> Dict[str, int]:
        """
        同步特定数据源的文件
        
        Args:
            source_prefix: 数据源前缀
            bucket: MinIO桶名
            table_name: 目标表名
            processor_type: 处理器类型
            
        Returns:
            同步统计信息
        """
        bucket = bucket or Config.MINIO_BUCKET
        table_name = table_name or 't_chemist_data'
        processor_type = processor_type or 'chemist'
        
        logger.info(f"开始同步数据源: {source_prefix} -> {table_name} (处理器: {processor_type})")
        
        stats = {
            'total_objects': 0,
            'downloaded_files': 0,
            'processed_files': 0,
            'failed_files': 0,
            'total_records': 0,
            'created_records': 0,
            'updated_records': 0,
            'error_records': 0
        }
        
        try:
            # 获取对象列表
            objects = self.minio_client.list_objects(bucket, source_prefix)
            stats['total_objects'] = len(objects)
            
            logger.info(f"找到 {len(objects)} 个对象")
            
            for obj in objects:
                try:
                    object_name = obj['name']
                    object_etag = obj.get('etag', '')
                    object_size = obj.get('size', 0)
                    object_last_modified = obj.get('last_modified', '')

                    if object_name in SKIP_OBJECT_NAMES:
                        logger.info(f"跳过已知空CSV文件: {object_name}")
                        continue
                    
                    # 使用新的基于ETag的检查方法
                    if not self.state_manager.check_file_needs_sync_with_etag(
                        object_name, processor_type,
                        current_etag=object_etag,
                        current_size=object_size
                    ):
                        logger.debug(f"跳过未变化文件: {object_name} (ETag: {object_etag})")
                        continue
                    
                    logger.info(f"检测到文件需要同步: {object_name} (ETag: {object_etag})")
                    
                    # 下载文件
                    local_path = os.path.join(Config.LOCAL_DOWNLOAD_DIR, os.path.basename(object_name))
                    
                    if self.minio_client.download_file(bucket, object_name, local_path):
                        stats['downloaded_files'] += 1
                        logger.info(f"下载文件成功: {object_name}")
                        
                        # 处理数据上传
                        try:
                            # 使用指定的表名和处理器类型处理数据
                            upload_stats = self.data_processor.process_csv_file(
                                local_path, 
                                source_prefix,
                                table_name=table_name,
                                processor_type=processor_type
                            )
                            stats['processed_files'] += 1
                            
                            # 更新统计信息
                            stats['total_records'] += upload_stats.get('total_rows', 0)
                            stats['created_records'] += upload_stats.get('created_records', 0)
                            stats['updated_records'] += upload_stats.get('updated_records', 0)
                            stats['error_records'] += upload_stats.get('error_records', 0)
                            
                            logger.info(f"数据上传完成: {upload_stats}")
                            
                            # 只有完全成功的文件才保存到Redis（无错误记录且有处理行数）
                            error_records = upload_stats.get('error_records', 0)
                            processed_rows = upload_stats.get('processed_rows', 0)
                            
                            if error_records == 0 and processed_rows > 0:
                                # 完全成功 - 使用简化的ETag方法保存
                                self.state_manager.set_file_sync_success_with_etag(
                                    object_name, processor_type,
                                    etag=object_etag,
                                    size=object_size,
                                    processing_stats=upload_stats
                                )
                                logger.info(f"文件同步成功，已保存ETag标记: {object_name} (ETag: {object_etag})")
                            else:
                                # 有错误或无数据 - 不保存标记，下次会重新处理
                                logger.warning(f"文件同步有问题，不保存标记，下次重试: {object_name} (错误记录: {error_records}, 处理行数: {processed_rows})")
                            
                            # 同步完成后删除本地文件以节省磁盘空间
                            try:
                                os.remove(local_path)
                                logger.info(f"已删除本地文件: {local_path}")
                            except Exception as cleanup_error:
                                logger.warning(f"删除本地文件失败: {local_path} - {cleanup_error}")
                            
                        except Exception as e:
                            logger.error(f"数据处理失败: {object_name} - {e}")
                            stats['failed_files'] += 1
                            
                            # 处理失败时删除本地文件（避免磁盘占用），不保存任何状态
                            try:
                                os.remove(local_path)
                                logger.info(f"处理失败，已删除本地文件: {local_path}")
                            except Exception as cleanup_error:
                                logger.warning(f"删除失败文件失败: {local_path} - {cleanup_error}")
                            
                            # 确保失败的文件不会被保存到Redis
                            logger.info(f"处理失败的文件不保存状态，下次会重新尝试: {object_name}")
                    else:
                        logger.error(f"下载文件失败: {object_name}")
                        stats['failed_files'] += 1
                        
                except Exception as e:
                    logger.error(f"处理对象失败: {object_name} - {e}")
                    stats['failed_files'] += 1
            
            logger.info(f"数据源同步完成: {stats}")
            return stats
            
        except Exception as e:
            logger.error(f"数据源同步失败: {e}")
            return stats
    
    def list_supported_sources(self) -> List[Dict[str, Any]]:
        """列出所有配置的数据源"""
        return self.sync_sources
    
    def get_sync_status(self) -> Dict[str, Any]:
        """获取同步状态"""
        stats = self.state_manager.get_success_stats()
        return {
            'synced_files_count': stats.get('total_success_files', 0),
            'configured_sources': self.sync_sources,
            'success_stats': stats
        }
    
    def remove_synced_file(self, object_name: str, source_prefix: str = None, processor_type: str = None, table_name: str = None):
        """移除已同步文件记录"""
        self.state_manager.remove_file_success_mark(object_name, source_prefix, processor_type, table_name)
        logger.info(f"已移除同步记录: {object_name}")
    
    def reset_sync_state(self, source_prefix: str = None, processor_type: str = None, table_name: str = None):
        """重置同步状态"""
        self.state_manager.clear_all_success_marks(source_prefix, processor_type, table_name)
        logger.info("同步状态已重置")
    
    def get_storage_info(self) -> Dict[str, Any]:
        """获取存储信息"""
        return self.state_manager.get_storage_info()
