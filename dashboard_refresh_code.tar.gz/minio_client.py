import os
from typing import List, Dict, Optional
from minio import Minio
from minio.error import S3Error
from loguru import logger
from config import Config
import io


class MinioClient:
    """MinIO客户端类，提供文件操作功能"""
    
    def __init__(self):
        """初始化MinIO客户端"""
        self.client = None
        self._connect()
    
    def _connect(self):
        """连接到MinIO服务器"""
        try:
            self.client = Minio(
                endpoint=Config.MINIO_ENDPOINT,
                access_key=Config.MINIO_ACCESS_KEY,
                secret_key=Config.MINIO_SECRET_KEY,
                secure=Config.MINIO_SECURE
            )
            logger.info(f"成功连接到MinIO服务器: {Config.MINIO_ENDPOINT}")
        except Exception as e:
            logger.error(f"连接MinIO服务器失败: {e}")
            raise
    
    def list_objects(self, bucket: str = None, prefix: str = None) -> List[Dict]:
        """
        列出指定bucket和prefix下的所有对象
        
        Args:
            bucket: bucket名称，默认使用配置中的bucket
            prefix: 前缀路径，默认使用配置中的prefix
            
        Returns:
            对象列表，每个对象包含name, size, last_modified等信息
        """
        bucket = bucket or Config.MINIO_BUCKET
        prefix = prefix or ''
        
        try:
            objects = []
            # 列出所有对象
            for obj in self.client.list_objects(bucket, prefix=prefix, recursive=True):
                object_info = {
                    'name': obj.object_name,
                    'size': obj.size,
                    'last_modified': obj.last_modified,
                    'etag': obj.etag,
                    'content_type': getattr(obj, 'content_type', ''),
                    'metadata': getattr(obj, 'metadata', {})
                }
                objects.append(object_info)
                logger.debug(f"发现对象: {obj.object_name}, 大小: {obj.size} bytes")
            
            logger.info(f"在bucket '{bucket}' 前缀 '{prefix}' 下找到 {len(objects)} 个对象")
            return objects
            
        except S3Error as e:
            logger.error(f"列出对象失败: {e}")
            return []
        except Exception as e:
            logger.error(f"列出对象时发生未知错误: {e}")
            return []
    
    def download_file(self, bucket: str, object_name: str, local_path: str) -> bool:
        """
        下载单个文件
        
        Args:
            bucket: bucket名称
            object_name: 对象名称
            local_path: 本地保存路径
            
        Returns:
            下载是否成功
        """
        try:
            # 确保本地目录存在
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            
            # 下载文件
            self.client.fget_object(bucket, object_name, local_path)
            logger.info(f"成功下载文件: {object_name} -> {local_path}")
            return True
            
        except S3Error as e:
            logger.error(f"下载文件失败 {object_name}: {e}")
            return False
        except Exception as e:
            logger.error(f"下载文件时发生未知错误 {object_name}: {e}")
            return False
    
    def get_object_info(self, bucket: str, object_name: str) -> Optional[Dict]:
        """
        获取对象信息
        
        Args:
            bucket: bucket名称
            object_name: 对象名称
            
        Returns:
            对象信息字典，如果不存在则返回None
        """
        try:
            stat = self.client.stat_object(bucket, object_name)
            return {
                'name': object_name,
                'size': stat.size,
                'last_modified': stat.last_modified,
                'etag': stat.etag,
                'content_type': stat.content_type,
                'metadata': stat.metadata
            }
        except S3Error as e:
            logger.error(f"获取对象信息失败 {object_name}: {e}")
            return None
        except Exception as e:
            logger.error(f"获取对象信息时发生未知错误 {object_name}: {e}")
            return None
    
    def bucket_exists(self, bucket: str) -> bool:
        """
        检查bucket是否存在
        
        Args:
            bucket: bucket名称
            
        Returns:
            bucket是否存在
        """
        try:
            return self.client.bucket_exists(bucket)
        except Exception as e:
            logger.error(f"检查bucket存在性失败 {bucket}: {e}")
            return False 

    def ensure_bucket(self, bucket: str = None) -> bool:
        """
        确保指定的bucket存在，不存在则创建
        
        Args:
            bucket: bucket名称，不传则使用配置中的默认bucket
        
        Returns:
            bool: 是否可用
        """
        bucket = bucket or Config.MINIO_BUCKET
        try:
            if not self.client.bucket_exists(bucket):
                self.client.make_bucket(bucket)
                logger.info(f"已创建MinIO Bucket: {bucket}")
            return True
        except Exception as e:
            logger.error(f"确保Bucket可用失败 {bucket}: {e}")
            return False

    def upload_text(self, object_name: str, text: str, bucket: str = None, content_type: str = 'application/json') -> bool:
        """
        以文本形式上传对象（常用于JSON等小文件）
        
        Args:
            object_name: 对象名称（包含路径）
            text: 文本内容
            bucket: 目标bucket，不传则使用配置中的默认bucket
            content_type: 内容类型，默认'application/json'
        
        Returns:
            bool: 上传是否成功
        """
        bucket = bucket or Config.MINIO_BUCKET
        try:
            if not self.ensure_bucket(bucket):
                return False
            data = text.encode('utf-8')
            data_stream = io.BytesIO(data)
            self.client.put_object(
                bucket,
                object_name,
                data_stream,
                length=len(data),
                content_type=content_type
            )
            logger.info(f"上传文本到MinIO成功: {bucket}/{object_name} ({len(data)} bytes)")
            return True
        except Exception as e:
            logger.error(f"上传文本到MinIO失败 {bucket}/{object_name}: {e}")
            return False