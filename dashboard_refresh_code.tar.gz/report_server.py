#!/usr/bin/env python3
"""Static report server for generated LCMS analysis files."""

import argparse
import html
import json
import mimetypes
import os
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import numpy as np

from raw_data_extractor.rde_io.agilent_d_reader import AgilentDReader, iter_scan_records


mimetypes.add_type("text/html; charset=utf-8", ".html")
mimetypes.add_type("text/html; charset=utf-8", ".htm")
mimetypes.add_type("application/json; charset=utf-8", ".json")
mimetypes.add_type("image/svg+xml; charset=utf-8", ".svg")


def _resolve_data_path(path_value: str) -> Path:
    """Translate stored report input URLs/UNC paths to container-mounted paths."""
    value = str(path_value or "").strip().replace("\\", "/")
    parsed = urlparse(value)
    if parsed.scheme in ("http", "https"):
        http_mappings = {
            "/reports/qtof_raw_file/": "/mnt/reports/qtof_raw_file/",
            "/reports/qtof_pdf/": "/mnt/reports/qtof_pdf/",
        }
        for url_prefix, local_prefix in http_mappings.items():
            if parsed.path.startswith(url_prefix):
                return Path(local_prefix + parsed.path[len(url_prefix):])

    unc_mappings = {
        "//172.19.13.37/data/": "/mnt/reports/qtof_raw_file/",
        "//172.19.13.37/Reports/": "/mnt/reports/qtof_pdf/",
    }
    for unc_prefix, local_prefix in unc_mappings.items():
        if value.startswith(unc_prefix):
            return Path(local_prefix + value[len(unc_prefix):])

    return Path(value)


_EIC_COMPAT_JS = r"""
<script>
(function() {
  if (window.__analysisEicCompatInstalled) return;
  window.__analysisEicCompatInstalled = true;

  function sameDirEicUrl(mz) {
    var url = new URL('eic', window.location.href);
    url.searchParams.set('mz', mz);
    url.searchParams.set('ppm', '5');
    return url.toString();
  }

  function openEic(mz) {
    var overlay = document.getElementById('eic-overlay');
    var eicImg = document.getElementById('eic-img');
    var eicTitle = document.getElementById('eic-title');
    var eicLoading = document.getElementById('eic-loading');
    var eicError = document.getElementById('eic-error');
    if (!overlay || !eicImg || !eicTitle || !eicLoading || !eicError) return false;

    eicTitle.textContent = 'EIC  m/z = ' + mz;
    eicImg.style.display = 'none';
    eicLoading.style.display = 'block';
    eicError.style.display = 'none';
    overlay.style.display = 'flex';
    document.body.classList.add('eic-open');
    overlay._scrollY = window.scrollY;

    var img = new Image();
    img.onload = function() {
      eicImg.src = img.src;
      eicImg.style.display = 'block';
      eicLoading.style.display = 'none';
    };
    img.onerror = function() {
      eicLoading.style.display = 'none';
      eicError.textContent = '无法加载 EIC 图 (m/z=' + mz + ')';
      eicError.style.display = 'block';
    };
    img.src = sameDirEicUrl(mz);
    return true;
  }

  document.addEventListener('click', function(e) {
    var target = e.target;
    if (!target || !target.classList || !target.classList.contains('eic-btn')) return;
    var mz = target.getAttribute('data-mz');
    if (!mz) return;
    if (openEic(mz)) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, true);
})();
</script>
"""


class AnalysisReportHandler(SimpleHTTPRequestHandler):
    server_version = "AnalysisReportHTTP/1.0"

    def translate_path(self, path):
        parsed_path = unquote(urlparse(path).path)
        if parsed_path == "/analysis":
            parsed_path = "/analysis/"
        if not parsed_path.startswith("/analysis/"):
            return str(Path(self.directory) / "__not_found__")

        relative_path = parsed_path[len("/analysis/") :]
        safe_parts = [
            part for part in relative_path.split("/")
            if part and part not in (".", "..")
        ]
        return str(Path(self.directory, *safe_parts))

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path.endswith("/eic"):
            self._serve_eic(parsed)
            return

        local_path = Path(self.translate_path(self.path))
        if local_path.name == "sample_report.html" and local_path.is_file():
            self._serve_html_with_eic_compat(local_path)
            return

        super().do_GET()

    def _send_text(self, status: int, body: str, content_type: str) -> None:
        payload = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _serve_html_with_eic_compat(self, local_path: Path) -> None:
        try:
            body = local_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            body = local_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            self.send_error(404, "File not found")
            return

        if "__analysisEicCompatInstalled" not in body:
            marker = "</body>"
            if marker in body:
                body = body.replace(marker, _EIC_COMPAT_JS + "\n" + marker, 1)
            else:
                body += "\n" + _EIC_COMPAT_JS
        self._send_text(200, body, "text/html; charset=utf-8")

    def _serve_eic(self, parsed) -> None:
        params = parse_qs(parsed.query)
        try:
            mz = float(params.get("mz", [""])[0])
            ppm = float(params.get("ppm", ["5"])[0])
        except (TypeError, ValueError):
            self.send_error(400, "Invalid mz or ppm")
            return
        if not np.isfinite(mz) or mz <= 0 or not np.isfinite(ppm) or ppm <= 0:
            self.send_error(400, "Invalid mz or ppm")
            return

        report_dir = Path(self.translate_path(parsed.path.rsplit("/", 1)[0] + "/"))
        result_json = report_dir / "result.json"
        try:
            result = json.loads(result_json.read_text(encoding="utf-8"))
            sample_d = _resolve_data_path(str(result.get("inputs", {}).get("sample_d", "")))
        except Exception as exc:
            self.send_error(404, f"Cannot read result.json: {exc}")
            return
        if not sample_d.is_dir():
            self.send_error(404, f"Sample .d not found: {sample_d}")
            return

        try:
            rts, intensities = _extract_eic(sample_d, target_mz=mz, ppm=ppm)
            svg = _render_eic_svg(rts, intensities, mz=mz, ppm=ppm, sample_name=sample_d.name)
        except Exception as exc:
            self.send_error(500, f"EIC generation failed: {exc}")
            return
        self._send_text(200, svg, "image/svg+xml; charset=utf-8")


def _extract_eic(d_path: Path, *, target_mz: float, ppm: float):
    scans = [s for s in iter_scan_records(d_path) if s.ms_level == 1]
    tol = abs(float(target_mz)) * float(ppm) * 1e-6
    rts = []
    intensities = []

    with AgilentDReader(d_path) as reader:
        for scan in scans:
            mz_arr, int_arr = reader.read_centroid_peaks(scan)
            intensity = 0.0
            if mz_arr.size and int_arr.size:
                mask = (mz_arr >= target_mz - tol) & (mz_arr <= target_mz + tol)
                if np.any(mask):
                    intensity = float(np.sum(int_arr[mask]))
            rts.append(float(scan.rt_min))
            intensities.append(intensity)

    return np.array(rts, dtype=float), np.array(intensities, dtype=float)


def _render_eic_svg(rts, intensities, *, mz: float, ppm: float, sample_name: str) -> str:
    width, height = 920, 520
    margin_l, margin_r, margin_t, margin_b = 76, 28, 56, 68
    plot_w = width - margin_l - margin_r
    plot_h = height - margin_t - margin_b

    valid = np.isfinite(rts) & np.isfinite(intensities)
    rts = rts[valid]
    intensities = intensities[valid]
    if rts.size == 0:
        rts = np.array([0.0, 1.0])
        intensities = np.array([0.0, 0.0])

    x_min, x_max = float(np.min(rts)), float(np.max(rts))
    if x_max <= x_min:
        x_max = x_min + 1.0
    y_max = float(np.max(intensities)) if intensities.size else 0.0
    if y_max <= 0:
        y_max = 1.0

    def sx(x):
        return margin_l + (float(x) - x_min) / (x_max - x_min) * plot_w

    def sy(y):
        return margin_t + plot_h - (float(y) / y_max) * plot_h

    points = " ".join(f"{sx(x):.1f},{sy(y):.1f}" for x, y in zip(rts, intensities))

    x_ticks = np.linspace(x_min, x_max, 6)
    y_ticks = np.linspace(0, y_max, 5)
    grid = []
    for xt in x_ticks:
        x = sx(xt)
        grid.append(f'<line x1="{x:.1f}" y1="{margin_t}" x2="{x:.1f}" y2="{margin_t + plot_h}" stroke="#e2e8f0"/>')
        grid.append(f'<text x="{x:.1f}" y="{height - 30}" text-anchor="middle" font-size="12" fill="#475569">{xt:.2f}</text>')
    for yt in y_ticks:
        y = sy(yt)
        grid.append(f'<line x1="{margin_l}" y1="{y:.1f}" x2="{margin_l + plot_w}" y2="{y:.1f}" stroke="#e2e8f0"/>')
        grid.append(f'<text x="{margin_l - 10}" y="{y + 4:.1f}" text-anchor="end" font-size="12" fill="#475569">{yt:.2g}</text>')

    title = html.escape(f"EIC m/z={mz:.4f} ± {ppm:g} ppm")
    subtitle = html.escape(sample_name)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <rect width="100%" height="100%" fill="#ffffff"/>
  <text x="{margin_l}" y="26" font-size="20" font-weight="700" fill="#0f172a">{title}</text>
  <text x="{margin_l}" y="45" font-size="12" fill="#64748b">{subtitle}</text>
  <g>{''.join(grid)}</g>
  <line x1="{margin_l}" y1="{margin_t + plot_h}" x2="{margin_l + plot_w}" y2="{margin_t + plot_h}" stroke="#334155" stroke-width="1.5"/>
  <line x1="{margin_l}" y1="{margin_t}" x2="{margin_l}" y2="{margin_t + plot_h}" stroke="#334155" stroke-width="1.5"/>
  <polyline points="{points}" fill="none" stroke="#2563eb" stroke-width="2"/>
  <text x="{margin_l + plot_w / 2:.1f}" y="{height - 8}" text-anchor="middle" font-size="13" fill="#334155">RT (min)</text>
  <text x="18" y="{margin_t + plot_h / 2:.1f}" text-anchor="middle" transform="rotate(-90 18 {margin_t + plot_h / 2:.1f})" font-size="13" fill="#334155">Intensity</text>
</svg>"""


def main():
    parser = argparse.ArgumentParser(description="Serve generated analysis reports")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=int(os.getenv("REPORT_SERVER_PORT", "7860")))
    parser.add_argument("--directory", default=os.getenv("ANALYSIS_OUTPUT_DIR", "/data/analysis"))
    args = parser.parse_args()

    handler = lambda *handler_args, **handler_kwargs: AnalysisReportHandler(
        *handler_args,
        directory=args.directory,
        **handler_kwargs,
    )
    httpd = ThreadingHTTPServer((args.host, args.port), handler)
    print(f"Serving analysis reports from {args.directory} at http://{args.host}:{args.port}/analysis/")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
