#!/usr/bin/env python3
"""
数据处理器模块
负责文件验证、数据清洗和上传，支持多数据源
"""

import os
import csv
import json
from typing import Dict, Any, List, Optional
from loguru import logger
from data_mapping import DataMapper
from api_client import APIClient


class DataProcessor:
    """数据处理器"""
    
    def __init__(self):
        self.mapper = DataMapper()
        self.api_client = APIClient()
        
        # 处理器类型映射
        self.processor_types = {
            'chemist': 'ChemistProcessor',
            'yc': 'YCProcessor',
            'lxgl': 'LXGLProcessor',
            'lxns': 'LXNSProcessor',
            'dgcz': 'DGCZProcessor',
            'gfsy': 'GFSYProcessor',
            'gyzb': 'GYZBProcessor',
            'zyzb': 'ZYZBProcessor',
            'lcms': 'LCMSProcessor',
           
            'tyyy': 'TYYYProcessor',
            'zycwhb': 'ZYCWHBProcessor',
            'zycwxs': 'ZYCWXSProcessor',
            'gycwfr': 'GYCWFRProcessor',
            'dgcz' :  'DGCZProcessor'
        }
    
    def get_or_create_processor(self, processor_type: str, table_name: str, source_prefix: str):
        """获取或创建指定类型的处理器
        
        Args:
            processor_type: 处理器类型
            table_name: 目标表名
            source_prefix: 数据源前缀
            
        Returns:
            处理器实例
        """
        # 首先尝试从DataMapper获取已注册的处理器
        existing_processor = self.mapper.get_processor(source_prefix, processor_type, table_name)
        if existing_processor:
            logger.debug(f"使用已注册的处理器: {source_prefix}#{processor_type}#{table_name}")
            return existing_processor
        
        # 如果不存在，则动态创建并注册
        if processor_type not in self.processor_types:
            raise ValueError(f"不支持的处理器类型: {processor_type}")
        
        logger.info(f"动态创建处理器: {processor_type} -> {table_name} (前缀: {source_prefix})")
        
        # 动态创建处理器
        if processor_type == 'chemist':
            from data_mapping import ChemistProcessor
            processor = ChemistProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'yc':
            from data_mapping import YCProcessor
            processor = YCProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'lxgl':
            from data_mapping import LXGLProcessor
            processor = LXGLProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'lxns':
            from data_mapping import LXNSProcessor
            processor = LXNSProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'dgcz':
            from data_mapping import DGCZProcessor
            processor = DGCZProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'gfsy':
            from data_mapping import GFSYProcessor
            processor = GFSYProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'gyzb':
            from data_mapping import GYZBProcessor
            processor = GYZBProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'zyzb':
            from data_mapping import ZYZBProcessor
            processor = ZYZBProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'lcms':
            from data_mapping import LCMSProcessor
            processor = LCMSProcessor(table_name=table_name, source_prefix=source_prefix)

        elif processor_type == 'tyyy':
            from data_mapping import TYYYProcessor
            processor = TYYYProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'zycwhb':
            from data_mapping import ZYCWHBProcessor
            processor = ZYCWHBProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'zycwxs':
            from data_mapping import ZYCWXSProcessor
            processor = ZYCWXSProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'gycwfr':
            from data_mapping import GYCWFRProcessor
            processor = GYCWFRProcessor(table_name=table_name, source_prefix=source_prefix)
        elif processor_type == 'dgcz':
            from data_mapping import DGCZProcessor
            processor = DGCZProcessor(table_name=table_name, source_prefix=source_prefix)
        else:
            raise ValueError(f"未实现的处理器类型: {processor_type}")
        
        # 注册到DataMapper统一管理
        self.mapper.register_processor(processor, processor_type)
        
        return processor
    
    def validate_file(self, file_path: str, source_prefix: str, processor_type: str, table_name: str) -> Dict[str, Any]:
        """
        验证CSV文件格式
        
        Args:
            file_path: CSV文件路径
            source_prefix: 数据源前缀
            processor_type: 处理器类型
            table_name: 目标表名
            
        Returns:
            验证结果字典
        """
        if not os.path.exists(file_path):
            return {
                'valid': False,
                'errors': [f"文件不存在: {file_path}"],
                'warnings': [],
                'column_count': 0,
                'row_count': 0
            }
        
        # 获取对应的处理器
        processor = self.mapper.get_processor(source_prefix, processor_type, table_name)
        if not processor:
            return {
                'valid': False,
                'errors': [f"未找到数据源前缀 {source_prefix} 的处理器"],
                'warnings': [],
                'column_count': 0,
                'row_count': 0
            }
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                rows = list(reader)
                
                if not rows:
                    return {
                        'valid': False,
                        'errors': ["文件为空"],
                        'warnings': [],
                        'column_count': 0,
                        'row_count': 0
                    }
                
                header = rows[0]
                data_rows = rows[1:]
                
                # 获取处理器要求的必需列
                required_columns = processor.get_required_columns()
                
                missing_columns = []
                for col in required_columns:
                    if col not in header:
                        missing_columns.append(col)
                
                errors = []
                warnings = []
                
                if missing_columns:
                    errors.append(f"缺少必需列: {', '.join(missing_columns)}")
                
                # 检查数据行数
                if len(data_rows) == 0:
                    warnings.append("文件没有数据行")
                
                # 检查列数是否匹配
                if len(header) != len(required_columns):
                    warnings.append(f"列数不匹配: 期望 {len(required_columns)}, 实际 {len(header)}")
                
                return {
                    'valid': len(errors) == 0,
                    'errors': errors,
                    'warnings': warnings,
                    'column_count': len(header),
                    'row_count': len(data_rows),
                    'table_name': processor.table_name
                }
                
        except Exception as e:
            return {
                'valid': False,
                'errors': [f"文件读取失败: {str(e)}"],
                'warnings': [],
                'column_count': 0,
                'row_count': 0
            }
    
    def process_csv_file(self, file_path: str, source_prefix: str, 
                        table_name: str = None, processor_type: str = None) -> Dict[str, Any]:
        """
        处理CSV文件并上传数据
        
        Args:
            file_path: CSV文件路径
            source_prefix: 数据源前缀
            table_name: 目标表名（必填）
            processor_type: 处理器类型（必填）
            
        Returns:
            处理统计信息
        """
        if not table_name or not processor_type:
            raise ValueError("table_name 和 processor_type 参数都是必填的")
        
        # 获取或创建处理器
        processor = self.get_or_create_processor(processor_type, table_name, source_prefix)
        batch_size = 50  # 默认批次大小
        
        logger.info(f"开始处理文件: {file_path}")
        logger.info(f"数据源: {source_prefix}")
        logger.info(f"目标表: {table_name}")
        logger.info(f"处理器类型: {processor_type}")
        
        stats = {
            'total_rows': 0,
            'processed_rows': 0,
            'created_records': 0,
            'updated_records': 0,
            'skipped_records': 0,
            'error_records': 0,
            'errors': [],
            'table_name': table_name,
            'source_prefix': source_prefix,
            'processor_type': processor_type
        }
        
        # 先进行文件格式校验
        try:
            validation_result = self.validate_file(file_path, source_prefix, processor_type, table_name)
            if not validation_result.get('valid', False):
                # 文件格式校验失败，直接返回错误结果
                validation_errors = validation_result.get('errors', [])
                stats['errors'].extend(validation_errors)
                stats['error_records'] = 1  # 标记为有错误，这样不会被保存到Redis
                logger.error(f"文件格式校验失败: {file_path} - {validation_errors}")
                return stats
            else:
                logger.info(f"文件格式校验通过: {file_path}")
        except Exception as e:
            stats['errors'].append(f"文件校验异常: {e}")
            stats['error_records'] = 1
            logger.error(f"文件校验异常: {file_path} - {e}")
            return stats
        
        try:
            # 如果处理器有重置行号计数器的方法，则调用它
            if hasattr(processor, 'reset_row_counter'):
                processor.reset_row_counter()
            
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = list(csv.DictReader(f))
                stats['total_rows'] = len(reader)

                # 预分配稳定行号ID：{process_id}_{row_num:06d}
                preassigned_rows = []
                for idx, row in enumerate(reader, 1):
                    # 仅当没有id且存在process_id时分配
                    if not row.get('id') and row.get('process_id'):
                        row['id'] = f"{row['process_id']}_{idx:06d}"
                    preassigned_rows.append((idx, row))

                from concurrent.futures import ThreadPoolExecutor, as_completed

                def _process_single(row_num_and_row):
                    row_num, row = row_num_and_row
                    try:
                        # 支持上游传id：若无，则由clean_data生成；多进程无需共享计数器
                        cleaned_data = processor.clean_data(row)
                        if cleaned_data is None:
                            return ('skipped', row_num, None, None)
                        validation_errors = processor.validate_data(cleaned_data)
                        if validation_errors:
                            return ('error', row_num, None, f"行 {row_num}: {', '.join(validation_errors)}")
                        return ('ok', row_num, cleaned_data, None)
                    except Exception as e:
                        return ('error', row_num, None, f"行 {row_num}: 处理失败 - {e}")

                max_workers = min(16, (os.cpu_count() or 1))
                results = []
                with ThreadPoolExecutor(max_workers=max_workers) as pool:
                    futures = [pool.submit(_process_single, item) for item in preassigned_rows]
                    for fut in as_completed(futures):
                        results.append(fut.result())

                batch = []
                for status, row_num, cleaned_data, err in sorted(results, key=lambda x: x[1]):
                    if status == 'ok' and cleaned_data is not None:
                        batch.append(cleaned_data)
                        stats['processed_rows'] += 1
                        if len(batch) >= batch_size:
                            self._process_batch(batch, table_name, stats, processor)
                            batch = []
                    elif status == 'skipped':
                        stats['processed_rows'] += 1
                    else:
                        stats['error_records'] += 1
                        stats['errors'].append(err)
                        logger.error(err)

                if batch:
                    self._process_batch(batch, table_name, stats, processor)
                
                # 检查是否有聚合数据需要处理（适用于DGCZProcessor等支持聚合的处理器）
                if hasattr(processor, 'has_aggregated_data') and processor.has_aggregated_data():
                    logger.info("处理聚合后的数据...")
                    aggregated_data = processor.get_aggregated_data()
                    if aggregated_data:
                        self._process_batch(aggregated_data, table_name, stats, processor)
                        logger.info(f"聚合数据处理完成，共 {len(aggregated_data)} 条记录")
            
            logger.info(f"文件处理完成: {file_path}")
            logger.info(f"统计信息: {stats}")
            
            return stats
            
        except Exception as e:
            error_msg = f"文件处理失败: {e}"
            logger.error(error_msg)
            stats['errors'].append(error_msg)
            stats['error_records'] += 1  # 确保失败的文件有错误记录
            return stats
    
    def _process_batch(self, batch: List[Dict[str, Any]], table_name: str, stats: Dict[str, Any], processor=None):
        """处理数据批次
        
        Args:
            batch: 数据批次
            table_name: 表名
            stats: 统计信息
            processor: 处理器实例（可选，如果提供则直接使用）
        """
        try:
            # 获取处理器以获取唯一字段
            if processor:
                # 直接使用传入的处理器
                unique_fields = processor.unique_fields if hasattr(processor, 'unique_fields') else None
            else:
                # 尝试从DataMapper获取处理器
                processor = self.mapper.get_processor_by_table(table_name)
                unique_fields = processor.unique_fields if processor else None
            
            # 批量创建记录（优先插入，失败时更新）
            result = self.api_client.batch_create_records(table_name, batch, unique_fields)
            
            # 更新统计信息
            stats['created_records'] += result['created']
            stats['updated_records'] += result['updated']
            
            failed_count = result['total'] - result['created'] - result['updated']
            if failed_count > 0:
                stats['error_records'] += failed_count
                logger.warning(f"批次处理: 创建 {result['created']}, 更新 {result['updated']}, 失败 {failed_count}")
            else:
                logger.info(f"批次处理成功: 创建 {result['created']}, 更新 {result['updated']}")
                
        except Exception as e:
            stats['error_records'] += len(batch)
            error_msg = f"批次处理失败: {e}"
            stats['errors'].append(error_msg)
            logger.error(error_msg)
    
    def get_processor_by_prefix(self, source_prefix: str):
        """根据前缀获取处理器"""
        return self.mapper.get_processor_by_prefix(source_prefix)
    
    def get_processor_by_table(self, table_name: str):
        """根据表名获取处理器"""
        return self.mapper.get_processor_by_table(table_name)
    
    def list_processors(self) -> Dict[str, str]:
        """列出所有处理器"""
        return self.mapper.list_processors()
    
    def register_processor(self, processor, processor_type: str = None):
        """注册新的处理器"""
        self.mapper.register_processor(processor, processor_type)
        logger.info(f"注册新处理器: {processor.table_name} -> {processor.source_prefix}")
    
    def get_required_columns(self, source_prefix: str, processor_type: str, table_name: str) -> List[str]:
        """获取指定数据源的必需列"""
        return self.mapper.get_required_columns(source_prefix, processor_type, table_name) 

