#在data_mapping_3_download_pdf.py的基础上，添加了填充样本保存条码，保存量
"""
数据映射和清洗模块 - 多数据源支持版本
支持完全不同的数据源格式、字段类型和目标表
"""

import math
import re
from datetime import datetime
from typing import Dict, Any, List, Callable, Optional, Union
from abc import ABC, abstractmethod
from loguru import logger
import download_parse_pdf
import os
import downloadpdf
import shutil
import tempfile
from config import Config
import json
from pathlib import Path
from raw_data_extractor.rde_analysis.raw_blank_core import RawBlankRemovalAnalyzer
from raw_data_extractor.rde_reporting.report_utils import render_html_report
import raw_data_extractor.rde_analysis.raw_blank_core as _rde_core

# PDF 路径映射：让 parse_d() 内部能定位到显式指定的 PDF
_PDF_OVERRIDE = {}
_orig_guess = _rde_core._guess_analysis_pdf_path

def _patched_guess(d_path):
    key = str(d_path.resolve())
    if key in _PDF_OVERRIDE:
        p = _PDF_OVERRIDE[key]
        return p if p.exists() else None
    return _orig_guess(d_path)

_rde_core._guess_analysis_pdf_path = _patched_guess


def _sanitize_json_value(value):
    """将分析结果中的非标准 JSON 值转换为可安全序列化的值。"""
    if isinstance(value, float):
        return value if math.isfinite(value) else None

    if isinstance(value, dict):
        return {key: _sanitize_json_value(val) for key, val in value.items()}

    if isinstance(value, (list, tuple, set)):
        return [_sanitize_json_value(item) for item in value]

    if hasattr(value, "tolist") and not isinstance(value, (str, bytes)):
        try:
            return _sanitize_json_value(value.tolist())
        except Exception:
            pass

    if hasattr(value, "item") and not isinstance(value, (str, bytes, dict, list, tuple, set)):
        try:
            item = value.item()
            if item is not value:
                return _sanitize_json_value(item)
        except Exception:
            pass

    return value


class DataCleaner(ABC):
    """数据清洗器抽象基类"""
    
    @abstractmethod
    def clean(self, value: Any) -> Any:
        """清洗单个字段值"""
        pass
    
    @abstractmethod
    def validate(self, value: Any) -> bool:
        """验证字段值"""
        pass


class IntegerCleaner(DataCleaner):
    """整数清洗器"""
    
    def __init__(self, default: int = 0, min_value: Optional[int] = None, max_value: Optional[int] = None):
        self.default = default
        self.min_value = min_value
        self.max_value = max_value
    
    def clean(self, value: Any) -> int:
        if not value:
            return self.default
        try:
            result = int(str(value).strip())
            if self.min_value is not None and result < self.min_value:
                return self.default
            if self.max_value is not None and result > self.max_value:
                return self.default
            return result
        except (ValueError, TypeError):
            return self.default
    
    def validate(self, value: Any) -> bool:
        try:
            cleaned = self.clean(value)
            return cleaned != self.default or str(value).strip() == str(self.default)
        except:
            return False


class StringCleaner(DataCleaner):
    """字符串清洗器"""
    
    def __init__(self, max_length: Optional[int] = None, pattern: Optional[str] = None, 
                 default: str = "", allow_empty: bool = True):
        self.max_length = max_length
        self.pattern = re.compile(pattern) if pattern else None
        self.default = default
        self.allow_empty = allow_empty
    
    def clean(self, value: Any) -> str:
        if value is None:
            return self.default
        result = str(value).strip()
        if not result and not self.allow_empty:
            return self.default
        if self.max_length and len(result) > self.max_length:
            result = result[:self.max_length]
        return result
    
    def validate(self, value: Any) -> bool:
        cleaned = self.clean(value)
        if not cleaned and not self.allow_empty:
            return False
        if self.pattern and not self.pattern.match(cleaned):
            return False
        return True

import re
from typing import Any, Optional


class URLCleaner(StringCleaner):
    """URL清洗器，专门处理URL字符串的特殊格式要求"""


    def clean(self, value: Any) -> str:
        url_mapping = {
        # "":"//172.19.13.37/reports/",
        # "":"//172.19.13.37/reports/",
        "////172.19.13.23//report//":"http://172.17.15.123/reports/zyzb/",
        "//172.19.13.34/1260_agilent_report/":"http://172.17.15.123/reports/1260gyzb/",
        "////172.19.13.34//1290_agilent_report//":"http://172.17.15.123/reports/1290gyzb/",
        "////172.19.13.35//LCMS_agilent_report//":"http://172.17.15.123/reports/lcms/",
        "//172.19.13.37/Reports/":"http://172.17.15.123/reports/qtof_pdf/",
        "//172.19.13.37/data/":"http://172.17.15.123/reports/qtof_raw_file/"
        }
        # 首先调用父类的清洗方法（处理空值、截断等）
        cleaned = super().clean(value)
        for key,item in url_mapping.items():
            if key in cleaned:
                # 找到 key 在 cleaned 中的位置
                index = cleaned.find(key)
                # 计算 key 结束的位置
                end_index = index + len(key)
                # 返回 key 之后的字符串:
                file_name = cleaned[end_index:]
                # 如果文件名尾部仅为 'pd'（缺少 'f'），则补全为 'pdf'
                if file_name.lower().endswith('pd'):
                    file_name = file_name + 'f'
                return item + file_name
        print(cleaned.replace('\\','/'))
        return cleaned.replace('\\', '/')
class DateTimeCleaner(DataCleaner):
    """日期时间清洗器"""
    
    def __init__(self, format_pattern: str = "%Y_%m_%d_%H:%M:%S", 
                 default: Optional[datetime] = None, output_format: str = "iso"):
        self.format_pattern = format_pattern
        self.default = default
        self.output_format = output_format
    
    def clean(self, value: Any) -> Union[datetime, str]:
        if not value:
            return self.default
        try:
            dt = datetime.strptime(str(value).strip(), self.format_pattern)
            if self.output_format == "iso":
                return dt.isoformat()
            elif self.output_format == "datetime":
                return dt
            else:
                return dt.strftime(self.output_format)
        except (ValueError, TypeError):
            return self.default
    
    def validate(self, value: Any) -> bool:
        if not value:
            return True  # 空值允许通过验证
        
        # 如果输出格式是iso，检查是否为有效的ISO格式字符串
        if self.output_format == "iso":
            try:
                # 尝试解析ISO格式
                datetime.fromisoformat(str(value).strip())
                return True
            except (ValueError, TypeError):
                return False
        else:
            # 对于其他输出格式，检查原始格式
            try:
                datetime.strptime(str(value).strip(), self.format_pattern)
                return True
            except (ValueError, TypeError):
                return False


class FloatCleaner(DataCleaner):
    """浮点数清洗器"""
    
    def __init__(self, default: float = 0.0, min_value: Optional[float] = None, 
                 max_value: Optional[float] = None, precision: Optional[int] = None, 
                 format_as_string: bool = False):
        self.default = default
        self.min_value = min_value
        self.max_value = max_value
        self.precision = precision
        self.format_as_string = format_as_string
    
    def clean(self, value: Any) -> Union[float, str]:
        if not value:
            return self.default
        try:
            result = float(str(value).strip())
            if self.min_value is not None and result < self.min_value:
                return self.default
            if self.max_value is not None and result > self.max_value:
                return self.default
            if self.precision is not None:
                result = round(result, self.precision)
                if self.format_as_string:
                    return f"{result:.{self.precision}f}"
            return result
        except (ValueError, TypeError):
            return self.default
    
    def validate(self, value: Any) -> bool:
        try:
            cleaned = self.clean(value)
            return cleaned != self.default or str(value).strip() == str(self.default)
        except:
            return False


class BooleanCleaner(DataCleaner):
    """布尔值清洗器"""
    
    def __init__(self, default: bool = False, true_values: List[str] = None, false_values: List[str] = None):
        self.default = default
        self.true_values = true_values or ['true', '1', 'yes', 'on', '是', 'Y']
        self.false_values = false_values or ['false', '0', 'no', 'off', '否', 'N']
    
    def clean(self, value: Any) -> bool:
        if value is None:
            return self.default
        str_value = str(value).strip().lower()
        if str_value in self.true_values:
            return True
        elif str_value in self.false_values:
            return False
        else:
            return self.default
    
    def validate(self, value: Any) -> bool:
        if value is None:
            return True
        str_value = str(value).strip().lower()
        return str_value in self.true_values or str_value in self.false_values


class DataSourceProcessor(ABC):
    """数据源处理器抽象基类"""
    
    def __init__(self):
        self.field_mappings: Dict[str, str] = {}
        self.cleaners: Dict[str, DataCleaner] = {}
        self.required_fields: List[str] = []
        self.unique_fields: List[str] = []
        self.table_name: str = ""
        self.source_prefix: str = ""
        
        # 初始化配置
        self.setup_config()
    
    @abstractmethod
    def setup_config(self):
        """设置处理器配置"""
        pass
    
    @abstractmethod
    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        pass
    
    @abstractmethod
    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        pass
    
    @abstractmethod
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        pass
    
    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据"""
        cleaned_data = {}
        
        for target_field, source_field in self.field_mappings.items():
            if source_field in raw_data:
                value = raw_data[source_field]
                cleaner = self.cleaners.get(target_field)
                
                if cleaner:
                    cleaned_value = cleaner.clean(value)
                    cleaned_data[target_field] = cleaned_value
                else:
                    # 如果没有专门的清洗器，使用默认字符串清洗
                    cleaned_data[target_field] = str(value).strip()
            else:
                # 源字段不存在，使用默认值
                cleaner = self.cleaners.get(target_field)
                if cleaner:
                    cleaned_data[target_field] = cleaner.clean(None)
                else:
                    cleaned_data[target_field] = ""
        
        return cleaned_data
    
    def validate_data(self, data: Dict[str, Any]) -> List[str]:
        """验证数据"""
        errors = []
        
        # 检查必填字段
        for field in self.required_fields:
            if not data.get(field):
                errors.append(f"必填字段 {field} 为空")
        
        # 检查字段验证
        for field, value in data.items():
            cleaner = self.cleaners.get(field)
            if cleaner and not cleaner.validate(value):
                errors.append(f"字段 {field} 验证失败")
        
        return errors


class ChemistProcessor(DataSourceProcessor):
    """化学家数据处理器 - 支持配置化"""
    
    def __init__(self, table_name: str = "chemist", source_prefix: str = "REPORT/yc/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """

        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        super().__init__()
    
    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = ['shake_flask_id', 'shake_flask_code', 'shake_flask_sample_info']
        self.unique_fields = ['shake_flask_id']
    
    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'serial_number',
            'shake_flask_id',
            'shake_flask_code',
            'shake_flask_sample_information',
            'shaking_speed(rmp)',
            'Extraction_temperature(℃)',
            'Extraction_duration(h)',
            'start_time',
            'stop_time'
        ]
    
    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        return {
            'serial_number': 'serial_number',
            'shake_flask_code': 'shake_flask_code',
            'shake_flask_sample_info': 'shake_flask_sample_information',
            'shaking_speed': 'shaking_speed(rmp)',
            'Extraction_temperature': 'Extraction_temperature(℃)',
            'Extraction_duration': 'Extraction_duration(h)',
            'start_time': 'start_time',
            'stop_time': 'stop_time',
            'shake_flask_id': 'shake_flask_id'
        }
    
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            'serial_number': IntegerCleaner(default=0, min_value=1),
            'shake_flask_code': StringCleaner(max_length=50),
            'shake_flask_sample_info': StringCleaner(max_length=200),
            'shaking_speed': IntegerCleaner(default=0, min_value=0, max_value=10000),
            'Extraction_temperature': FloatCleaner(default=0.0, min_value=-50.0, max_value=200.0),
            'Extraction_duration': FloatCleaner(default=0.0, min_value=0.0, max_value=1000.0),
            'start_time': DateTimeCleaner(format_pattern="%Y_%m_%d_%H:%M:%S"),
            'stop_time': DateTimeCleaner(format_pattern="%Y_%m_%d_%H:%M:%S"),
            'shake_flask_id': StringCleaner(max_length=100, pattern=r'^[a-zA-Z0-9_\.\-]+$')
        }


class YCProcessor(DataSourceProcessor):
    """YC摇床工站数据处理器 - 支持配置化（含数据聚合功能）"""
    
    def __init__(self, table_name: str = "yc_shaker", source_prefix: str = "REPORT/yc/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 添加数据聚合器，用于收集相同sample_id的数据
        self._sample_data = {}  # sample_id -> 聚合后的数据
        super().__init__()
    
    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']
    
    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'shake_flask_sample_information',
            'process_id'
        ]
    
    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        """表字段：CSV字段"""
        return {
            'id': 'id',  # 生成的唯一ID字段
            'sample_id': 'shake_flask_sample_information',
            'process_id': 'process_id'
        }
    
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'lf_concentration': StringCleaner(max_length=200),
            'lf_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50), 
            'stop_datetime':  StringCleaner(max_length=50), 
            'process_id': StringCleaner(max_length=100)
        }
    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置数据聚合器，为新文件处理做准备
        self._sample_data.clear()
    
    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并进行数据聚合"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)
        
        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
            
        # 获取关键字段
        sample_id = cleaned_data.get('sample_id', '')
        
        # 如果sample_id为空，直接处理并返回
        if not sample_id or not sample_id.strip():
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            return cleaned_data
        
        # 检查是否已经有这个sample_id的聚合数据
        if sample_id in self._sample_data:
            # 已存在，进行数据聚合
            existing_data = self._sample_data[sample_id]
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            # 返回聚合后的数据，用于更新数据库中的记录
            return existing_data.copy()
        else:
            # 第一次遇到这个sample_id，创建新的聚合记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 存储到聚合器中
            self._sample_data[sample_id] = cleaned_data.copy()
            
            # 返回创建的记录
            return cleaned_data

class LXGLProcessor(DataSourceProcessor):
    """离心过滤工站数据处理器 - 支持配置化（含数据聚合功能）"""
    
    def __init__(self, table_name: str = "centrifugal_filter", source_prefix: str = "REPORT/lxgl/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 添加数据聚合器，用于收集相同sample_id的数据
        self._sample_data = {}  # sample_id -> 聚合后的数据
        super().__init__()
    
    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']
    
    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'Concentration_bottle_code',
            'Concentration_bottle_sample_information',
            'process_id'
        ]
  
    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        # 平台字段标识：CSV字段名称
        return {
            'id': 'id',
            'bottle_tag': 'Concentration_bottle_code',
            'sample_id': 'Concentration_bottle_sample_information',
            'process_id': 'process_id'
        }
    
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'lf_concentration': StringCleaner(max_length=200),
            'lf_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50), 
            'stop_datetime': StringCleaner(max_length=50), 
            'process_id': StringCleaner(max_length=100)
        }

    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置数据聚合器，为新文件处理做准备
        self._sample_data.clear()
    
    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并进行数据聚合"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)
        
        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
            
        # 获取关键字段
        sample_id = cleaned_data.get('sample_id', '')
        bottle_tag = cleaned_data.get('bottle_tag', '')
        
        # 如果sample_id为空，直接处理并返回
        if not sample_id or not sample_id.strip():
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            return cleaned_data
        
        # 检查是否已经有这个sample_id的聚合数据
        if sample_id in self._sample_data:
            # 已存在，进行数据聚合
            existing_data = self._sample_data[sample_id]
            
            # 合并bottle_tag（去重并用逗号分隔）
            existing_tags = set(existing_data.get('bottle_tag', '').split(',')) if existing_data.get('bottle_tag') else set()
            if bottle_tag and bottle_tag.strip():
                existing_tags.add(bottle_tag.strip())
            existing_data['bottle_tag'] = ','.join(sorted(filter(None, existing_tags)))
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            # 返回聚合后的数据，用于更新数据库中的记录
            return existing_data.copy()
        else:
            # 第一次遇到这个sample_id，创建新的聚合记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 存储到聚合器中
            self._sample_data[sample_id] = cleaned_data.copy()
            
            # 返回创建的记录
            return cleaned_data


class LXNSProcessor(DataSourceProcessor):
    """离心浓缩工站数据处理器 - 支持配置化"""
    
    def __init__(self, table_name: str = "lxns_concentrator", source_prefix: str = "REPORT/lxns/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        super().__init__()
    
    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = ['sample', 'ves_id', 'tray_id', 'process_id']
        self.unique_fields = ['id']  # 使用生成的id作为唯一字段
    
    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'sample',
            'ves_id',
            'tray_id',
            'method',
            'start_time',
            'stop_time',
            'device_id',
            'process_id'
        ]
    
    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        return {
            'sample': 'sample',
            'ves_id': 'ves_id',
            'tray_id': 'tray_id',
            'method': 'method',
            'start_time': 'start_time',
            'stop_time': 'stop_time',
            'device_id': 'device_id',
            'process_id': 'process_id',
            'id': 'id'  # 生成的唯一ID字段
        }
    
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            'sample': StringCleaner(max_length=200),
            'ves_id': StringCleaner(max_length=100, pattern=r'^[a-zA-Z0-9_\.\-]+$'),
            'tray_id': StringCleaner(max_length=100, pattern=r'^[a-zA-Z0-9_\.\-]+$'),
            'method': StringCleaner(max_length=100),
            'start_time': DateTimeCleaner(format_pattern="%Y_%m_%d_%H:%M:%S"),
            'stop_time': DateTimeCleaner(format_pattern="%Y_%m_%d_%H:%M:%S"),
            'device_id': StringCleaner(max_length=100, pattern=r'^[a-zA-Z0-9_\.\-]+$'),
            'process_id': StringCleaner(max_length=100, pattern=r'^[a-zA-Z0-9_\.\-]+$'),
            'id': StringCleaner(max_length=200)  # 生成的唯一ID字段
        }
    
    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
    
    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并生成唯一ID"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)
        
        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
        
        # 递增行号计数器
        self._row_counter += 1
        
        # 生成唯一ID：process_id + 行号
        unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
        cleaned_data['id'] = unique_id
        
        return cleaned_data




class GFSYProcessor(DataSourceProcessor):
    """GFSY模块数据处理器 - 支持配置化"""
    
    def __init__(self, table_name: str = "gfsy_module", source_prefix: str = "REPORT/gfsy/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        super().__init__()
    
    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = ['nsp_id', 'concentration_ves_code', 'sample']
        self.unique_fields = ['nsp_id']
    
    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'nsp_id',
            'Concentration_ves_code',
            'nsp_sample',  # CSV中使用nsp_sample，映射到sample字段
            'mix_times',
            'motor_speed',
            'xz_time',
            'work_temp',
            'rota_dis',
            'delay_time',
            'vac_var',
            'start_time',
            'stop_time'
        ]
    
    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        return {
            'nsp_id': 'nsp_id',
            'concentration_ves_code': 'Concentration_ves_code',
            'sample': 'nsp_sample',  # 特殊映射：sample字段对应CSV中的nsp_sample
            'mix_times': 'mix_times',
            'motor_speed': 'motor_speed',
            'xz_time': 'xz_time',
            'work_temp': 'work_temp',
            'rota_dis': 'rota_dis',
            'delay_time': 'delay_time',
            'vac_var': 'vac_var',
            'start_time': 'start_time',
            'stop_time': 'stop_time'
        }
    
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            'nsp_id': StringCleaner(max_length=100, pattern=r'^[a-zA-Z0-9_\.\-]+$'),
            'concentration_ves_code': StringCleaner(max_length=50),
            'sample': StringCleaner(max_length=200),
            'mix_times': IntegerCleaner(default=0, min_value=0),
            'motor_speed': IntegerCleaner(default=0, min_value=0),
            'xz_time': IntegerCleaner(default=0, min_value=0),
            'work_temp': FloatCleaner(default=0.0),
            'rota_dis': FloatCleaner(default=0.0),
            'delay_time': FloatCleaner(default=0.0),
            'vac_var': IntegerCleaner(default=0, min_value=0),
            'start_time': DateTimeCleaner(format_pattern="%Y_%m_%d_%H:%M:%S"),
            'stop_time': DateTimeCleaner(format_pattern="%Y_%m_%d_%H:%M:%S")
        }


class GYZBProcessor(DataSourceProcessor):
    """GYZB数据处理器 - 支持配置化（含去重功能）"""

    def __init__(self, table_name: str = "gyzb-1260", source_prefix: str = "REPORT/gyzb/"):
        """初始化处理器

        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 添加去重集合，用于追踪三个关键字段的组合
        self._processed_combinations = set()
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使用生成的id作为唯一字段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'Fraction_collection_ves_code',
            'Fraction_collection_ves_sample_information',
            'process_id',
            'report_address'
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        return {
            'id': 'id',  # 生成的唯一ID字段
            'sample_id': 'Fraction_collection_ves_sample_information',
            'bottle_tag': 'Fraction_collection_ves_code',
            'gy_report': 'report_address',
            'process_id': 'process_id'
        }

    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'lf_concentration': StringCleaner(max_length=200),
            'lf_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50), 
            'stop_datetime': StringCleaner(max_length=50), 
            'process_id': StringCleaner(max_length=100)
        }

    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置去重集合，为新文件处理做准备
        self._processed_combinations.clear()

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并生成唯一ID（含去重功能）"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)

        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
            
        # 检查三个关键字段的组合是否已经处理过
        sample_id = cleaned_data.get('sample_id', '')
        bottle_tag = cleaned_data.get('bottle_tag', '')
        gy_report = cleaned_data.get('gy_report', '')
        
        # 只有当关键字段不为空时才进行去重检查
        if sample_id and sample_id.strip() and bottle_tag and bottle_tag.strip() and gy_report and gy_report.strip():
            # 创建去重键：sample_id + bottle_tag + gy_report的组合
            dedup_key = (sample_id, bottle_tag, gy_report)
            
            # 如果这个组合已经处理过，跳过这条记录
            if dedup_key in self._processed_combinations:
                return None  # 返回None表示跳过这条记录
                
            # 将这个组合添加到已处理集合中
            self._processed_combinations.add(dedup_key)

        # 如果上游未提供id，则在此生成；否则尊重上游传入的id（便于并发稳定）
        if not cleaned_data.get('id'):
            # 递增行号计数器
            self._row_counter += 1
            # 生成唯一ID：process_id + 行号
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id

        # 自动生成当前时间戳
        current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        # 设置时间字段的更新策略：
        # - 第一次创建时：start_datetime 和 stop_datetime 都设置为当前时间
        # - 后续更新时：只更新 stop_datetime，start_datetime 保持不变
        cleaned_data['_update_start_time'] = False  # 标记：更新时不要改变 start_datetime
        cleaned_data['start_datetime'] = current_time  # 只在创建时使用
        cleaned_data['stop_datetime'] = current_time   # 总是更新为当前时间

        return cleaned_data
        
class ZYZBProcessor(DataSourceProcessor):
    """ZYZB数据处理器 - 支持配置化（含数据聚合功能）"""

    def __init__(self, table_name: str = "zyzb-lfsj", source_prefix: str = "REPORT/zyzb-lfsj/"):
        """初始化处理器

        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 添加数据聚合器，用于收集相同sample_id和zy_report的数据
        self._sample_data = {}  # (sample_id, zy_report) -> 聚合后的数据
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使用生成的id作为唯一字段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'Fraction_collection_ves_code',
            'Fraction_collection_ves_sample_information',
            'report_address',
            'process_id',
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        return {
            'id': 'id',  # 生成的唯一ID字段
            'sample_id': 'Fraction_collection_ves_sample_information',
            'bottle_tag': 'Fraction_collection_ves_code',
            'zy_report': 'report_address',
            'process_id': 'process_id',
        }

    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'lf_concentration': StringCleaner(max_length=200),
            'lf_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'stop_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'process_id': StringCleaner(max_length=100)
        }

    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置数据聚合器，为新文件处理做准备
        self._sample_data.clear()

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并进行数据聚合"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)

        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
            
        # 获取关键字段
        sample_id = cleaned_data.get('sample_id', '')
        bottle_tag = cleaned_data.get('bottle_tag', '')
        zy_report = cleaned_data.get('zy_report', '')
        
        # 如果关键字段为空，直接处理并返回
        if not sample_id or not sample_id.strip() or not zy_report or not zy_report.strip():
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            return cleaned_data
        
        # 创建聚合键：(sample_id, zy_report)
        agg_key = (sample_id, zy_report)
        
        # 检查是否已经有这个组合的聚合数据
        if agg_key in self._sample_data:
            # 已存在，进行数据聚合
            existing_data = self._sample_data[agg_key]
            
            # 合并bottle_tag（去重并用逗号分隔）
            existing_tags = set(existing_data.get('bottle_tag', '').split(',')) if existing_data.get('bottle_tag') else set()
            if bottle_tag and bottle_tag.strip():
                existing_tags.add(bottle_tag.strip())
            existing_data['bottle_tag'] = ','.join(sorted(filter(None, existing_tags)))
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            # 返回聚合后的数据，用于更新数据库中的记录
            return existing_data.copy()
        else:
            # 第一次遇到这个组合，创建新的聚合记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 存储到聚合器中
            self._sample_data[agg_key] = cleaned_data.copy()
            
            # 返回创建的记录
            return cleaned_data




class LCMSProcessor(DataSourceProcessor):
    """LCMS数据处理器 - 支持配置化（含去重功能）"""

    def __init__(self, table_name: str = "lcms", source_prefix: str = "REPORT/lcms/QTOF"):
        """初始化处理器

        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 添加去重集合，用于追踪sample_id和qtof_report的组合
        self._processed_combinations = set()
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使用初始化时设置的table_name和source_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使用生成的id作为唯一字段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'sample_information',
            'report_address',
            'process_id',
            'data_address',
            'bk_report',
            'bk_data'
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置"""
        return {
             #平台字段标识：CSV字段名称
            'id': 'id',  # 生成的唯一ID字段
            'sample_id': 'sample_information',
            'qtof_report': 'report_address',
            'data_address': 'data_address',
            'bk_report': 'bk_report',
            'bk_data': 'bk_data',
            'process_id': 'process_id',
            'analyse_address': 'analyse_address'
        }

    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        return {
            #平台字段标识：清洗器
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'lf_concentration': StringCleaner(max_length=200),
            'lf_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=255),
            'start_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'stop_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'data_address': URLCleaner(max_length=255),
            'bk_report': URLCleaner(max_length=255),
            'bk_data': URLCleaner(max_length=255),
            'process_id': StringCleaner(max_length=100),
            'analyse_address': URLCleaner(max_length=255)
        }

    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置去重集合，为新文件处理做准备
        self._processed_combinations.clear()

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并生成唯一ID（含去重功能）"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)

        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
            
        # 检查sample_id和qtof_report的组合是否已经处理过
        sample_id = cleaned_data.get('sample_id', '')
        qtof_report = cleaned_data.get('qtof_report', '')
        
        # 只有当关键字段不为空时才进行去重检查
        if sample_id and sample_id.strip() and qtof_report and qtof_report.strip():
            # 创建去重键：sample_id + qtof_report的组合
            dedup_key = (sample_id, qtof_report)
            
            # 如果这个组合已经处理过，跳过这条记录
            if dedup_key in self._processed_combinations:
                return None  # 返回None表示跳过这条记录
                
            # 将这个组合添加到已处理集合中
            self._processed_combinations.add(dedup_key)

        # 优先使用上游传入的id；若无则按自增规则生成
        existing_id = str(cleaned_data.get('id', '')).strip()
        if existing_id:
            cleaned_data['id'] = existing_id
        else:
            # 递增行号计数器
            self._row_counter += 1
            # 生成唯一ID：process_id + 行号
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id

        # 自动生成当前时间戳
        current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        # 设置时间字段的更新策略：
        # - 第一次创建时：start_datetime 和 stop_datetime 都设置为当前时间
        # - 后续更新时：只更新 stop_datetime，start_datetime 保持不变
        cleaned_data['_update_start_time'] = False  # 标记：更新时不要改变 start_datetime
        cleaned_data['start_datetime'] = current_time  # 只在创建时使用
        cleaned_data['stop_datetime'] = current_time   # 总是更新为当前时间

        # ---- 调用新版算法（.d + PDF 双输入）----
        try:
            sample_d_url = cleaned_data.get('data_address') or ''
            blank_d_url = cleaned_data.get('bk_data') or ''
            sample_pdf_url = cleaned_data.get('qtof_report') or ''
            blank_pdf_url = cleaned_data.get('bk_report') or ''

            def is_valid_path(val):
                """检查是否为有效路径（排除 /no, /no.d 等占位值）"""
                v = str(val).strip()
                base = os.path.basename(v)
                return bool(v) and base not in ('no', 'no.d', '')

            if not is_valid_path(sample_d_url) or not is_valid_path(blank_d_url):
                logger.warning(
                    "LCMS分析输入缺失或为占位值，analyse_address置空: "
                    f"id={cleaned_data.get('id')}, sample_d={sample_d_url}, blank_d={blank_d_url}"
                )
                cleaned_data['analyse_address'] = ''
                return cleaned_data

            # 缓存检查：如果 HTML 报告已存在，直接复用
            process_id = cleaned_data['process_id']
            record_id = cleaned_data['id']
            result_dir_rel_path = f"lcms/{process_id}/{record_id}"
            json_rel_path = f"{result_dir_rel_path}/result.json"
            html_rel_path = f"{result_dir_rel_path}/sample_report.html"
            json_abs_path = os.path.join(Config.ANALYSIS_OUTPUT_DIR, json_rel_path)
            html_abs_path = os.path.join(Config.ANALYSIS_OUTPUT_DIR, html_rel_path)
            base_url = Config.REPORT_BASE_URL.rstrip('/')
            if os.path.exists(html_abs_path):
                cleaned_data['analyse_address'] = f"{base_url}/{html_rel_path}"
                logger.info(f"复用已存在LCMS HTML报告: {html_abs_path}")
                return cleaned_data

            # 每条记录使用独立临时工作目录，避免并发处理同一个 blank.d 时互相删除/覆盖。
            workspace_parent = os.path.join(Config.LOCAL_DOWNLOAD_DIR, "_analysis", record_id)
            os.makedirs(workspace_parent, exist_ok=True)
            analysis_workspace = tempfile.mkdtemp(prefix="work_", dir=workspace_parent)
            local_sample_d = None
            local_blank_d = None
            local_sample_pdf = None
            local_blank_pdf = None
            analyzer = None
            try:
                # 复制 4 个数据源到本地
                local_sample_d = downloadpdf.copy_d_directory(sample_d_url, save_directory=analysis_workspace)
                local_blank_d = downloadpdf.copy_d_directory(blank_d_url, save_directory=analysis_workspace)
                local_sample_pdf = (downloadpdf.copy_pdf_file(sample_pdf_url, save_directory=analysis_workspace)
                                    if is_valid_path(sample_pdf_url) else None)
                local_blank_pdf = (downloadpdf.copy_pdf_file(blank_pdf_url, save_directory=analysis_workspace)
                                   if is_valid_path(blank_pdf_url) else None)

                if not local_sample_d or not local_blank_d:
                    logger.warning(
                        "LCMS分析输入复制失败，analyse_address置空: "
                        f"id={cleaned_data.get('id')}, sample_d={sample_d_url}, blank_d={blank_d_url}, "
                        f"local_sample_d={local_sample_d}, local_blank_d={local_blank_d}"
                    )
                    cleaned_data['analyse_address'] = ''
                    return cleaned_data

                # 注册 PDF 映射（让 parse_d 内部能找到 PDF）
                if local_sample_pdf:
                    _PDF_OVERRIDE[str(Path(local_sample_d).resolve())] = Path(local_sample_pdf)
                else:
                    logger.warning(f"LCMS样品PDF未复制成功，将继续尝试解析.d数据: id={record_id}, pdf={sample_pdf_url}")
                if local_blank_pdf:
                    _PDF_OVERRIDE[str(Path(local_blank_d).resolve())] = Path(local_blank_pdf)
                else:
                    logger.warning(f"LCMS空白PDF未复制成功，将继续尝试解析.d数据: id={record_id}, pdf={blank_pdf_url}")

                # 推断空白离子模式
                blank_acq = Path(local_blank_d) / "AcqData"
                blank_mode = "negative"  # 默认
                if blank_acq.exists():
                    names = [p.name.upper() for p in blank_acq.iterdir() if p.is_dir()]
                    if any("POS" in n for n in names):
                        blank_mode = "positive"

                analyzer = RawBlankRemovalAnalyzer(
                    blank_pos_path=local_blank_d if blank_mode == "positive" else "",
                    blank_neg_path=local_blank_d if blank_mode != "positive" else "",
                    top_n_spectrum=10, max_interference_peaks=5,
                    cumulative_threshold=0.9, rt_tolerance=1.0,
                    mz_tol_ppm=1.0, mz_tol_da=0.0,
                )
                analyzer.parse_all()
                interferences = analyzer.extract_blank_interferences()
                analyzer.parse_sample(local_sample_d, ion_mode="auto", build_esi_info=False)

                main_df, removed_df, bg_df, adduct_df = analyzer.analyze_sample_peaks_v2(
                    interferences=interferences,
                    top_k=5, uv_primary_wl=220,
                    uv_min_area_sum_pct=5.0,
                    ms1_topn=10, ms1_keep=5,
                    dad_merge_rt_tol=0.05, area_merge_mode="max",
                    enable_background=True,
                    bg_scan_step=10, bg_topk=200, bg_presence=0.8,
                    bg_edge_coverage=0.05,
                    bg_filter_min_duration_ratio=0.5,
                    bg_filter_min_avg_intensity=30000.0,
                    bg_filter_max_peak_ratio=100.0,
                    ms2_rt_tol=0.3, ms2_precursor_ppm_tol=20,
                    ms2_precursors_per_rt=1, ms2_frag_topn=5,
                    enable_adducts=True,
                    adduct_max_candidates=5, adduct_ppm_tol=10.0,
                )

                # 组装 JSON 结果 — 兼容旧版前端字段格式
                def df_to_records(df):
                    if df is not None and not df.empty:
                        return json.loads(df.to_json(orient='records', force_ascii=False))
                    return []

                def _parse_float(v):
                    try:
                        return float(v) if v is not None else None
                    except (ValueError, TypeError):
                        return None

                def _parse_mz_list(mz_str):
                    """'123.4567,234.5678,...' → [123.4567, 234.5678, ...]"""
                    if not mz_str:
                        return []
                    try:
                        return [float(m) for m in str(mz_str).split(',') if m.strip()]
                    except Exception:
                        return []

                # --- 构造旧版 sample_neg_analysis 结构 ---
                sample_neg_analysis = {}
                if main_df is not None and not main_df.empty:
                    for _, row in main_df.iterrows():
                        wl = str(row.get('wavelength_used', ''))
                        peak_type = f"DAD_{wl}nm" if wl else "DAD_unknown"

                        rt_val = _parse_float(row.get('RT'))
                        ms1_rt = _parse_float(row.get('ms1_rt_min'))
                        rt_diff = abs(rt_val - ms1_rt) if rt_val is not None and ms1_rt is not None else None

                        mz_val = _parse_float(row.get('ms1_base_mz'))
                        top5_mz = _parse_mz_list(row.get('ms1_top5_filtered_mz'))

                        peak_obj = {
                            'Peak': row.get('peak_index'),
                            'Start': row.get('UV_Start'),
                            'RT': rt_val,
                            'End': row.get('UV_End'),
                            'Height': _parse_float(row.get(f'Height_{wl}')),
                            'Area': _parse_float(row.get(f'Area_{wl}')),
                            'Area_Percent': _parse_float(row.get(f'Area_Percent_{wl}')),
                            'Area_Sum': _parse_float(row.get(f'Area_Sum_{wl}')),
                            'PeakType': peak_type,
                            'mz': mz_val,
                            'top5_spectrum_mz': top5_mz,
                            'RT_Diff': rt_diff,
                            'matched_ESI_Peak': row.get('peak_index'),
                            'Remark': '',
                            'mz_annotated': mz_val,
                            'top5_spectrum_mz_annotated': top5_mz,
                        }

                        if peak_type not in sample_neg_analysis:
                            sample_neg_analysis[peak_type] = []
                        sample_neg_analysis[peak_type].append(peak_obj)

                # --- 构造旧版 interferences 结构 ---
                intf_data = {}
                if interferences:
                    for k, v in interferences.items():
                        if hasattr(v, 'to_dict'):
                            intf_data[k] = v.to_dict(orient='records')
                        elif isinstance(v, dict):
                            sub = {}
                            for sk, sv in v.items():
                                if hasattr(sv, 'to_dict'):
                                    sub[sk] = sv.to_dict(orient='records')
                                else:
                                    sub[sk] = sv
                            intf_data[k] = sub
                        else:
                            intf_data[k] = v

                result_payload = {
                    'sample_id': cleaned_data.get('sample_id'),
                    'process_id': process_id,
                    'inputs': {
                        'sample_neg': sample_pdf_url,
                        'blank_neg': blank_pdf_url,
                        'sample_d': sample_d_url,
                        'blank_d': blank_d_url,
                        'sample_pdf': sample_pdf_url,
                        'blank_pdf': blank_pdf_url,
                    },
                    'interferences': intf_data,
                    'sample_neg_analysis': sample_neg_analysis,
                    # 新增字段（前端可忽略）
                    'ion_mode': getattr(analyzer, 'sample_ion_mode', 'unknown'),
                    'main_peaks': df_to_records(main_df),
                    'removed': df_to_records(removed_df),
                    'background_ions': df_to_records(bg_df),
                    'adduct_evidence': df_to_records(adduct_df),
                }

                os.makedirs(os.path.dirname(json_abs_path), exist_ok=True)
                with open(json_abs_path, 'w', encoding='utf-8') as f:
                    json.dump(_sanitize_json_value(result_payload), f, ensure_ascii=False, allow_nan=False)

                render_html_report(
                    out_path=Path(html_abs_path),
                    sample_path=sample_d_url,
                    ion_mode=getattr(analyzer, 'sample_ion_mode', 'unknown'),
                    main_df=main_df,
                    removed_df=removed_df,
                    bg_df=bg_df,
                    adduct_df=adduct_df,
                )
                cleaned_data['analyse_address'] = f"{base_url}/{html_rel_path}"
                logger.info(f"LCMS分析报告已生成: json={json_abs_path}, html={html_abs_path}")

            finally:
                if analyzer is not None:
                    analyzer.close()
                # 清理 PDF 映射
                if local_sample_d:
                    _PDF_OVERRIDE.pop(str(Path(local_sample_d).resolve()), None)
                if local_blank_d:
                    _PDF_OVERRIDE.pop(str(Path(local_blank_d).resolve()), None)
                # 清理临时文件
                try:
                    if analysis_workspace and os.path.isdir(analysis_workspace):
                        shutil.rmtree(analysis_workspace)
                except Exception:
                    pass
                for p in [workspace_parent, os.path.dirname(workspace_parent)]:
                    try:
                        if p and os.path.isdir(p) and not os.listdir(p):
                            os.rmdir(p)
                    except Exception:
                        pass

        except Exception as e:
            logger.exception(f"LCMS 分析与报告生成异常，analyse_address置空: id={cleaned_data.get('id')}, error={e}")
            cleaned_data['analyse_address'] = ''

        return cleaned_data

class TYYYProcessor(DataSourceProcessor):
    """TYYY数据处理器 - 支持配置化（含数据聚合功能）"""

    def __init__(self, table_name: str = "lcms", source_prefix: str = "REPORT/lcms/QTOF"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 添加数据聚合器，用于收集相同sample_id的数据
        self._sample_data = {}  # sample_id -> 聚合后的数据
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使~T~H~]~K~L~V~W设置~Z~Dtable_name~R~Lsource_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使~T~T~_~H~P~Z~Did~\为~T~@~W段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'sample',
            'source_ves_code',
            'process_id',
            'target_ves_code',
            'pipette_volume(mL)'
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置""" 
        """表字段名称：csv字段名称"""
        return {
             #平台字段标识：CSV字段名称
            'id': 'id',  # 生成的唯一ID字段
            'sample_id': 'sample',
            'bottle_tag': 'source_ves_code',
            'process_id': 'process_id',
            # 样本保存条码字段 1-6 (动态填充，不映射到CSV)
            # 'sample_storage1': '',
            # 'sample_storage2': '',
            # 'sample_storage3': '',
            # 'sample_storage4': '',
            # 'sample_storage5': '',
            # 'sample_storage6': '',
            # 保存量字段 1-6 (动态填充，不映射到CSV)
            # 'save_amount1': '',
            # 'save_amount2': '',
            # 'save_amount3': '',
            # 'save_amount4': '',
            # 'save_amount5': '',
            # 'save_amount6': ''
        } 
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        """表字段名称：清洗器对象"""
        return {
            #平台字段标识：清洗器
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'lf_concentration': StringCleaner(max_length=200),
            'lf_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'stop_datetime': StringCleaner(max_length=50),   # 自动生成的ISO格式时间字符串
            'process_id': StringCleaner(max_length=100),
            # 样本保存条码字段 1-6
            'sample_storage1': StringCleaner(max_length=200),
            'sample_storage2': StringCleaner(max_length=200),
            'sample_storage3': StringCleaner(max_length=200),
            'sample_storage4': StringCleaner(max_length=200),
            'sample_storage5': StringCleaner(max_length=200),
            'sample_storage6': StringCleaner(max_length=200),
            # 保存量字段 1-6 (数值类型)
            'save_amount1': FloatCleaner(default=0.0, precision=2),
            'save_amount2': FloatCleaner(default=0.0, precision=2),
            'save_amount3': FloatCleaner(default=0.0, precision=2),
            'save_amount4': FloatCleaner(default=0.0, precision=2),
            'save_amount5': FloatCleaner(default=0.0, precision=2),
            'save_amount6': FloatCleaner(default=0.0, precision=2)
        }

    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置数据聚合器，为新文件处理做准备
        self._sample_data.clear()

    def _process_target_storage_data(self, cleaned_data: Dict[str, Any], raw_data: Dict[str, Any] = None) -> bool:
        """处理以WP96H开头的target_ves_code数据，填充到样本保存条码字段
        
        Args:
            cleaned_data: 清洗后的数据字典
            raw_data: 原始CSV数据字典
            
        Returns:
            bool: 如果成功处理返回True，如果所有位置都满了返回False
        """
        # 从原始CSV数据中读取target_ves_code和pipette_volume
        if raw_data:
            target_ves_code = raw_data.get('target_ves_code', '')
            pipette_volume = raw_data.get('pipette_volume(mL)', '')
        else:
            target_ves_code = cleaned_data.get('target_ves_code', '')
            pipette_volume = cleaned_data.get('pipette_volume', '')
        
        # 检查target_ves_code是否以"WP96H"开头
        if not target_ves_code or not target_ves_code.strip().startswith('WP96H'):
            return True  # 不是WP96H开头的数据，直接返回成功
        
        # 检查是否有数据要写入
        if not target_ves_code.strip() or not pipette_volume:
            return True  # 数据为空，直接返回成功
        
        # 查找第一个空闲的样本保存条码位置
        for i in range(1, 7):  # 检查位置1-6
            barcode_field = f'sample_storage{i}'
            volume_field = f'save_amount{i}'
            
            # 检查当前位置是否为空
            current_barcode = cleaned_data.get(barcode_field, '')
            current_volume = cleaned_data.get(volume_field, 0.0)
            
            if not current_barcode and current_volume == 0.0:
                # 找到空闲位置，写入数据
                cleaned_data[barcode_field] = target_ves_code.strip() if target_ves_code else ''
                cleaned_data[volume_field] = float(pipette_volume) if pipette_volume else 0.0
                logger.info(f"WP96H数据已写入位置{i}: 条码={target_ves_code.strip()}, 体积={pipette_volume}")
                return True
        
        # 所有位置都已满，跳过这个样本
        sample_id = cleaned_data.get('sample_id', 'Unknown')
        logger.warning(f"样本 {sample_id} 的样本保存条码字段1-6，保存量字段1-6都被填满了，跳过WP96H数据: 条码={target_ves_code.strip()}, 体积={pipette_volume}")
        print(f"跳过样本 {sample_id}: 样本保存条码字段1-6，保存量字段1-6都被填满了 - WP96H条码={target_ves_code.strip()}, 体积={pipette_volume}")
        return False

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并进行数据聚合"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)

        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
            
        # 获取关键字段
        sample_id = cleaned_data.get('sample_id', '')
        bottle_tag = cleaned_data.get('bottle_tag', '')
        
        # 如果sample_id为空，直接处理并返回
        if not sample_id or not sample_id.strip():
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            return cleaned_data
        
        # 检查是否已经有这个sample_id的聚合数据
        if sample_id in self._sample_data:
            # 已存在，进行数据聚合
            existing_data = self._sample_data[sample_id]
            
            # 合并bottle_tag（去重并用逗号分隔）
            existing_tags = set(existing_data.get('bottle_tag', '').split(',')) if existing_data.get('bottle_tag') else set()
            if bottle_tag and bottle_tag.strip():
                existing_tags.add(bottle_tag.strip())
            existing_data['bottle_tag'] = ','.join(sorted(filter(None, existing_tags)))
            
            # 确保existing_data有样本保存条码和保存量字段
            for i in range(1, 7):
                barcode_field = f'sample_storage{i}'
                volume_field = f'save_amount{i}'
                if barcode_field not in existing_data:
                    existing_data[barcode_field] = ''
                if volume_field not in existing_data:
                    existing_data[volume_field] = 0.0
            
            # 处理WP96H开头的target_ves_code数据
            if hasattr(self, '_process_target_storage_data'):
                if not self._process_target_storage_data(existing_data, raw_data):
                    # 如果所有位置都满了，跳过当前记录的处理
                    return None
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            # 返回聚合后的数据，用于更新数据库中的记录
            return existing_data.copy()
        else:
            # 第一次遇到这个sample_id，创建新的聚合记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 初始化样本保存条码和保存量字段
            for i in range(1, 7):
                barcode_field = f'sample_storage{i}'
                volume_field = f'save_amount{i}'
                if barcode_field not in cleaned_data:
                    cleaned_data[barcode_field] = ''
                if volume_field not in cleaned_data:
                    cleaned_data[volume_field] = 0.0
            
            # 处理WP96H开头的target_ves_code数据
            if not self._process_target_storage_data(cleaned_data, raw_data):
                # 如果所有位置都满了，跳过当前记录的处理
                return None
            
            # 存储到聚合器中
            self._sample_data[sample_id] = cleaned_data.copy()
            
            # 返回创建的记录
            return cleaned_data

class ZYCWHBProcessor(DataSourceProcessor):
    """ZYCWHB数据处理器 - 支持配置化（含数据聚合功能）"""

    def __init__(self, table_name: str = "zycwhb", source_prefix: str = "REPORT/fr/HB/jycs-hbrx"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 添加数据聚合器，用于收集相同sample_id的数据
        self._sample_data = {}  # sample_id -> 聚合后的数据
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使~T~H~]~K~L~V~W设置~Z~Dtable_name~R~Lsource_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使~T~T~_~H~P~Z~Did~\为~T~@~W段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'sample',
            'ves_code',
            'merge_ves_code',
            'process_id'
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置""" 
        """表字段名称：csv字段名称"""
        return {
             # 平台字段标识：CSV字段名称
            'id': 'id',  # 生成的唯一ID字段
            'sample_id': 'sample',
            'bottle_tag': 'ves_code',
            'bottle_merge_tag': 'merge_ves_code',
            'process_id': 'process_id'
        } 
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        """表字段名称：清洗器对象"""
        return {
            #平~O~W段| ~G~F~Z~E~W~Y
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'If_concentration': StringCleaner(max_length=200),
            'If_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'stop_datetime': StringCleaner(max_length=50),   # 自动生成的ISO格式时间字符串
            'process_id': StringCleaner(max_length=100)
        }

    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置数据聚合器，为新文件处理做准备
        self._sample_data.clear()

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并进行数据聚合"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)

        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")

        # 获取关键字段
        sample_id = cleaned_data.get('sample_id', '')
        bottle_tag = cleaned_data.get('bottle_tag', '')
        bottle_merge_tag = cleaned_data.get('bottle_merge_tag', '')
        
        # 如果sample_id为空，直接处理并返回
        if not sample_id or not sample_id.strip():
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            return cleaned_data
        
        # 检查是否已经有这个sample_id的聚合数据
        if sample_id in self._sample_data:
            # 已存在，进行数据聚合
            existing_data = self._sample_data[sample_id]
            
            # 合并bottle_tag（去重并用逗号分隔）
            existing_tags = set(existing_data.get('bottle_tag', '').split(',')) if existing_data.get('bottle_tag') else set()
            if bottle_tag and bottle_tag.strip():
                existing_tags.add(bottle_tag.strip())
            existing_data['bottle_tag'] = ','.join(sorted(filter(None, existing_tags)))
            
            # 合并bottle_merge_tag（去重并用逗号分隔）
            existing_merge_tags = set(existing_data.get('bottle_merge_tag', '').split(',')) if existing_data.get('bottle_merge_tag') else set()
            if bottle_merge_tag and bottle_merge_tag.strip():
                existing_merge_tags.add(bottle_merge_tag.strip())
            existing_data['bottle_merge_tag'] = ','.join(sorted(filter(None, existing_merge_tags)))
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            # 返回聚合后的数据，用于更新数据库中的记录
            return existing_data.copy()
        else:
            # 第一次遇到这个sample_id，创建新的聚合记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 存储到聚合器中
            self._sample_data[sample_id] = cleaned_data.copy()
            
            # 返回创建的记录
            return cleaned_data

class ZYCWXSProcessor(DataSourceProcessor):
    """ZYCWXS数据处理器 - 支持配置化"""
    def __init__(self, table_name: str = "zycwxs", source_prefix: str = "REPORT/fr/dilution_product/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # ~]~X~E~M置~O~B~U~L~\setup_config中使~T
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 数据积累器，用于sample和concentration聚合功能
        self._sample_data = {}  # 以(sample_id, If_concentration)为key存储数据
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使~T~H~]~K~L~V~W设置~Z~Dtable_name~R~Lsource_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使~T~T~_~H~P~Z~Did~\为~T~@~W段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'sample',
            'vessel_code',
            'concentration(mg/ml)',
            'process_id'
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置""" 
        """表字段名称：csv字段名称"""
        return {
             #平~O~W段| ~G~F~ZCSV~W段~P~M称
            'id': 'id',  # ~T~_~H~P~Z~D~T~@ID~W段
            'sample_id': 'sample',
            'bottle_tag': 'vessel_code',
            'If_concentration': 'concentration(mg/ml)',
            'process_id': 'process_id'
        } 
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        """表字段名称：清洗器对象"""
        return {
            #平~O~W段| ~G~F~Z~E~W~Y
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'If_concentration': StringCleaner(max_length=200),
            'If_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'stop_datetime': StringCleaner(max_length=50),   # 自动生成的ISO格式时间字符串
            'process_id': StringCleaner(max_length=100)
        }

    def reset_row_counter(self):
        """重置行计数器，在处理新文件时调用"""
        self._row_counter = 0
        # 重置数据积累器
        self._sample_data = {}

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗数据并聚合相同sample和concentration的记录"""
        cleaned_data = super().clean_data(raw_data)
        
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段是必需的，不能为空")
        
        # 获取聚合键：sample_id和concentration
        sample_id = cleaned_data.get('sample_id', '')
        concentration = cleaned_data.get('If_concentration', '')
        bottle_tag = cleaned_data.get('bottle_tag', '')
        
        # 验证必需字段
        if not sample_id or not sample_id.strip():
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            return cleaned_data
        
        # 创建聚合键：(sample_id, concentration)
        agg_key = (sample_id, concentration)
        
        # 检查是否已存在相同sample和concentration的数据
        if agg_key in self._sample_data:
            # 聚合数据：合并bottle_tag
            existing_data = self._sample_data[agg_key]
            
            # 合并bottle_tag（去重并用逗号分隔）
            existing_tags = set(existing_data.get('bottle_tag', '').split(',')) if existing_data.get('bottle_tag') else set()
            if bottle_tag and bottle_tag.strip():
                existing_tags.add(bottle_tag.strip())
            existing_data['bottle_tag'] = ','.join(sorted(filter(None, existing_tags)))
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            logger.info(f"聚合sample {sample_id} + concentration {concentration}: bottle_tag={existing_data['bottle_tag']}")
            
            # 返回聚合后的数据
            return existing_data.copy()
        else:
            # 第一次遇到这个sample和concentration组合，生成完整记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 存储到积累器中
            self._sample_data[agg_key] = cleaned_data.copy()
            logger.info(f"新增sample {sample_id} + concentration {concentration}: bottle_tag={bottle_tag}, id={unique_id}")
            
            return cleaned_data

class GYCWFRProcessor(DataSourceProcessor):
    """GYCWFR数据处理器 - 支持配置化（含去重功能）"""
    def __init__(self, table_name: str = "gycwfr", source_prefix: str = "REPORT/fr/XS/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # ~]~X~E~M置~O~B~U~L~\setup_config中使~T
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添~J| ~L~O计~U~Y~T~N~T~_~H~P~T~@ID~H~O个~V~G件~G~M~V~@~K~I
        self._row_counter = 0
        # 添加数据聚合器，用于收集相同sample_id的数据
        self._sample_data = {}  # sample_id -> 聚合后的数据
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使~T~H~]~K~L~V~W设置~Z~Dtable_name~R~Lsource_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使~T~T~_~H~P~Z~Did~\为~T~@~W段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'sample',
            'ves_code',
            'merge_ves_code',
            'concentration(mg/ml)',
            'process_id'
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置""" 
        """表字段名称：csv字段名称"""
        return {
             #平~O~W段| ~G~F~ZCSV~W段~P~M称
            'id': 'id',  # ~T~_~H~P~Z~D~T~@ID~W段
            'sample_id': 'sample',
            'bottle_tag': 'ves_code',
            'bottle_merge_tag': 'merge_ves_code',
            'If_concentration': 'concentration(mg/ml)',
            'process_id': 'process_id'
        } 
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        """表字段名称：清洗器对象"""
        return {
            #平~O~W段| ~G~F~Z~E~W~Y
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'If_concentration': StringCleaner(max_length=200),
            'If_mass': StringCleaner(max_length=200),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'stop_datetime': StringCleaner(max_length=50),   # 自动生成的ISO格式时间字符串
            'process_id': StringCleaner(max_length=100)
        }

    def reset_row_counter(self):
        """重置行号计数器（每个文件开始处理时调用）"""
        self._row_counter = 0
        # 重置数据聚合器，为新文件处理做准备
        self._sample_data.clear()

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗和映射数据，并进行数据聚合"""
        # 调用父类方法进行基础清洗
        cleaned_data = super().clean_data(raw_data)

        # 调试：打印原始数据和清洗后数据
        logger.debug(f"GYCWFRProcessor 原始数据: {raw_data}")
        logger.debug(f"GYCWFRProcessor 清洗后数据: {cleaned_data}")

        # 检查process_id是否存在且非空
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            logger.warning(f"process_id字段为空或不存在: {cleaned_data.get('process_id', 'N/A')}")
            raise ValueError("process_id字段是必需的，不能为空")
            
        # 获取sample_id
        sample_id = cleaned_data.get('sample_id', '')
        logger.debug(f"GYCWFRProcessor sample_id: '{sample_id}'")
        
        # 如果sample_id为空，直接处理并返回
        if not sample_id or not sample_id.strip():
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            return cleaned_data
        
        # 获取当前记录的关键字段
        bottle_tag = cleaned_data.get('bottle_tag', '')
        bottle_merge_tag = cleaned_data.get('bottle_merge_tag', '')
        
        # 检查是否已经有这个sample_id的聚合数据
        if sample_id in self._sample_data:
            # 已存在，进行数据聚合
            existing_data = self._sample_data[sample_id]
            
            # 合并bottle_tag（去重并用逗号分隔）
            existing_tags = set(existing_data.get('bottle_tag', '').split(',')) if existing_data.get('bottle_tag') else set()
            if bottle_tag and bottle_tag.strip():
                existing_tags.add(bottle_tag.strip())
            existing_data['bottle_tag'] = ','.join(sorted(filter(None, existing_tags)))
            
            # 合并bottle_merge_tag（去重并用逗号分隔）
            existing_merge_tags = set(existing_data.get('bottle_merge_tag', '').split(',')) if existing_data.get('bottle_merge_tag') else set()
            if bottle_merge_tag and bottle_merge_tag.strip():
                existing_merge_tags.add(bottle_merge_tag.strip())
            existing_data['bottle_merge_tag'] = ','.join(sorted(filter(None, existing_merge_tags)))
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            logger.info(f"GYCWFRProcessor 聚合数据: sample_id='{sample_id}', bottle_tag='{existing_data['bottle_tag']}', bottle_merge_tag='{existing_data['bottle_merge_tag']}'")
            
            # 返回聚合后的数据，用于更新数据库中的记录
            return existing_data.copy()
        else:
            # 第一次遇到这个sample_id，创建新的聚合记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 存储到聚合器中
            self._sample_data[sample_id] = cleaned_data.copy()
            logger.info(f"GYCWFRProcessor 新增sample_id: '{sample_id}', bottle_tag='{bottle_tag}', bottle_merge_tag='{bottle_merge_tag}', id='{unique_id}'")
            
            # 返回创建的记录
            return cleaned_data


class DGCZProcessor(DataSourceProcessor):
    """DGCZ数据处理器 - 支持配置化"""
    def __init__(self, table_name: str = "dgcz", source_prefix: str = "REPORT/dg/"):
        """初始化处理器
        
        Args:
            table_name: 目标表名
            source_prefix: 数据源前缀
        """
        # 保存配置参数，在setup_config中使用
        self._target_table_name = table_name
        self._target_source_prefix = source_prefix
        # 添加行号计数器用于生成唯一ID（每个文件重新开始）
        self._row_counter = 0
        # 数据积累器，用于sample合并功能
        self._sample_data = {}  # 以sample_id为key存储数据
        # 样本保存条码跟踪器，以sample_id为key存储已使用的条码位置数量
        self._sample_storage_tracker = {}  # 格式: {sample_id: 已使用的条码位置数量}
        super().__init__()

    def setup_config(self):
        """设置处理器配置"""
        # 使~T~H~]~K~L~V~W设置~Z~Dtable_name~R~Lsource_prefix
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']  # 使~T~T~_~H~P~Z~Did~\为~T~@~W段

    def get_required_columns(self) -> List[str]:
        """获取CSV文件必需的列"""
        return [
            'sample',
            'sample_weight',
            'ves_code',
            'process_id'
        ]

    def get_field_mappings(self) -> Dict[str, str]:
        """获取字段映射配置""" 
        """表字段名称：csv字段名称"""
        return {
             # 数据库字段名：CSV字段名称
            'id': 'id',  # 数据库表的ID字段
            'sample_id': 'sample',
            'bottle_tag': 'ves_code',
            'If_mass': 'sample_weight',
            'process_id': 'process_id'
            # start_datetime 和 stop_datetime 将在 clean_data 中自动生成当前时间
            # 样本保存条码和保存量字段将在clean_data中动态生成，不需要CSV映射
        } 
    def get_cleaners(self) -> Dict[str, DataCleaner]:
        """获取字段清洗器配置"""
        """表字段名称：清洗器对象"""
        return {
            # 数据库字段名：清洗器对象
            'id': StringCleaner(max_length=200),  # 生成的唯一ID字段
            'sample_id': StringCleaner(max_length=200),
            'bottle_tag': StringCleaner(max_length=200),
            'bottle_merge_tag': StringCleaner(max_length=200),
            'sample_storage_location': StringCleaner(max_length=200),
            'If_concentration': StringCleaner(max_length=200),
            'If_mass': FloatCleaner(default=0.0, precision=2, format_as_string=True),
            'zy_report': URLCleaner(max_length=100),
            'gy_report': URLCleaner(max_length=100),
            'qtof_report': URLCleaner(max_length=100),
            'start_datetime': StringCleaner(max_length=50),  # 自动生成的ISO格式时间字符串
            'stop_datetime': StringCleaner(max_length=50),   # 自动生成的ISO格式时间字符串
            'process_id': StringCleaner(max_length=100),
            # 样本保存条码字段 1-6
            'sample_storage1': StringCleaner(max_length=200),
            'sample_storage2': StringCleaner(max_length=200),
            'sample_storage3': StringCleaner(max_length=200),
            'sample_storage4': StringCleaner(max_length=200),
            'sample_storage5': StringCleaner(max_length=200),
            'sample_storage6': StringCleaner(max_length=200),
            # 保存量字段 1-6 (数值类型)
            'save_amount1': FloatCleaner(default=0.0, precision=2),
            'save_amount2': FloatCleaner(default=0.0, precision=2),
            'save_amount3': FloatCleaner(default=0.0, precision=2),
            'save_amount4': FloatCleaner(default=0.0, precision=2),
            'save_amount5': FloatCleaner(default=0.0, precision=2),
            'save_amount6': FloatCleaner(default=0.0, precision=2)
        }

    def reset_row_counter(self):
        """重置行计数器，在处理新文件时调用"""
        self._row_counter = 0
        # 重置数据积累器
        self._sample_data = {}
        # 重置样本保存条码跟踪器
        self._sample_storage_tracker = {}

    def clean_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗数据并合并相同sample，每次都返回更新后的记录"""
        cleaned_data = super().clean_data(raw_data)
        
        if 'process_id' not in cleaned_data or not cleaned_data['process_id']:
            raise ValueError("process_id字段不能为空")
        
        # 获取sample_id用于合并
        sample_id = cleaned_data.get('sample_id', '')
        if not sample_id:
            raise ValueError("sample_id字段不能为空")
        
        # 获取bottle_tag（ves_code）和sample_weight
        bottle_tag = cleaned_data.get('bottle_tag', '')
        sample_weight = cleaned_data.get('If_mass', '0.0')
        
        # 检查ves_code是否以TT5或TT12开头（排除TT58）
        is_storage_barcode = False
        if bottle_tag and bottle_tag.strip():
            bottle_tag_clean = bottle_tag.strip()
            if (bottle_tag_clean.startswith('TT5') or bottle_tag_clean.startswith('TT12')) and not bottle_tag_clean.startswith('TT58'):
                is_storage_barcode = True
                logger.info(f"检测到样本保存条码: {bottle_tag_clean} for sample {sample_id}")
            elif bottle_tag_clean.startswith('TT58'):
                logger.info(f"检测到TT58条码，作为普通瓶子标签处理: {bottle_tag_clean} for sample {sample_id}")
        
        # 检查是否已存在相同sample的数据
        if sample_id in self._sample_data:
            existing_data = self._sample_data[sample_id]
            
            if is_storage_barcode:
                # 处理样本保存条码逻辑
                success = self._add_storage_barcode(existing_data, sample_id, bottle_tag_clean, sample_weight)
                if not success:
                    # 如果添加失败（1-6都满了），跳过这条记录
                    logger.error(f"样本 {sample_id} 的保存条码位置1-6都已满，跳过条码 {bottle_tag_clean}")
                    raise ValueError(f"样本 {sample_id} 的保存条码位置1-6都已满，无法添加更多条码")
            else:
                # 处理普通bottle_tag合并逻辑
                self._merge_bottle_tag_and_mass(existing_data, sample_id, bottle_tag, sample_weight)
            
            # 更新时间戳
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            existing_data['stop_datetime'] = current_time
            
            # 返回更新后的数据（使用相同ID确保数据库更新而不是插入）
            result_data = existing_data.copy()
            # 移除内部使用的累积字段，不传递给数据库
            result_data.pop('_accumulated_mass', None)
            return result_data
        else:
            # 第一次遇到这个sample，生成完整记录
            self._row_counter += 1
            unique_id = f"{cleaned_data['process_id']}_{self._row_counter:06d}"
            cleaned_data['id'] = unique_id
            
            current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            cleaned_data['_update_start_time'] = False
            cleaned_data['start_datetime'] = current_time
            cleaned_data['stop_datetime'] = current_time
            
            # 初始化所有样本保存条码字段为空
            for i in range(1, 7):
                cleaned_data[f'sample_storage{i}'] = ''
                cleaned_data[f'save_amount{i}'] = 0.0
            
            # 初始化样本保存条码跟踪器
            self._sample_storage_tracker[sample_id] = 0
            
            if is_storage_barcode:
                # 如果第一条就是样本保存条码，直接放到位置1
                cleaned_data['sample_storage1'] = bottle_tag_clean
                try:
                    weight_value = float(sample_weight)
                    cleaned_data['save_amount1'] = weight_value
                except (ValueError, TypeError):
                    cleaned_data['save_amount1'] = 0.0
                self._sample_storage_tracker[sample_id] = 1
                logger.info(f"新样本 {sample_id}: 保存条码1={bottle_tag_clean}, 保存量1={cleaned_data['save_amount1']}")
                
                # 清空bottle_tag，但保留If_mass用于后续合并
                cleaned_data['bottle_tag'] = ''
                # 初始化累积重量为0，因为这是样本保存条码，不是普通馏分
                cleaned_data['_accumulated_mass'] = 0.0
                cleaned_data['If_mass'] = '0.00'
            else:
                # 普通数据的处理
                # 初始化累积重量（浮点数）
                try:
                    initial_mass = float(sample_weight)
                    cleaned_data['_accumulated_mass'] = initial_mass
                    # 确保If_mass是格式化的字符串
                    cleaned_data['If_mass'] = f"{initial_mass:.2f}"
                except (ValueError, TypeError):
                    cleaned_data['_accumulated_mass'] = 0.0
                    cleaned_data['If_mass'] = "0.00"
                logger.info(f"新样本 {sample_id}: bottle_tag={bottle_tag}, weight={cleaned_data['If_mass']}")
            
            # 存储到积累器中
            self._sample_data[sample_id] = cleaned_data.copy()
            
            # 返回给数据库的数据不包含内部字段
            result_data = cleaned_data.copy()
            result_data.pop('_accumulated_mass', None)
            return result_data
    
    def _add_storage_barcode(self, existing_data: Dict[str, Any], sample_id: str, 
                           barcode: str, volume: str) -> bool:
        """添加样本保存条码到下一个可用位置
        
        Args:
            existing_data: 已存在的样本数据
            sample_id: 样本ID
            barcode: 保存条码
            volume: 保存量
            
        Returns:
            bool: 是否成功添加（False表示1-6位置都满了）
        """
        current_count = self._sample_storage_tracker.get(sample_id, 0)
        
        # 检查是否还有可用位置（1-6）
        if current_count >= 6:
            return False
        
        # 找到下一个可用位置
        next_position = current_count + 1
        
        # 设置条码和保存量
        existing_data[f'sample_storage{next_position}'] = barcode
        try:
            volume_value = float(volume)
            existing_data[f'save_amount{next_position}'] = volume_value
        except (ValueError, TypeError):
            existing_data[f'save_amount{next_position}'] = 0.0
        
        # 更新跟踪器
        self._sample_storage_tracker[sample_id] = next_position
        
        logger.info(f"添加样本保存条码: {sample_id} 位置{next_position}={barcode}, 保存量={existing_data[f'save_amount{next_position}']}")
        return True
    
    def _merge_bottle_tag_and_mass(self, existing_data: Dict[str, Any], sample_id: str, 
                                 bottle_tag: str, sample_weight: str):
        """合并普通bottle_tag和重量数据
        
        Args:
            existing_data: 已存在的样本数据
            sample_id: 样本ID
            bottle_tag: bottle标签
            sample_weight: 样本重量
        """
        # 合并bottle_tag（去重并用逗号分隔）
        existing_tags = set(existing_data.get('bottle_tag', '').split(',')) if existing_data.get('bottle_tag') else set()
        if bottle_tag and bottle_tag.strip():
            existing_tags.add(bottle_tag.strip())
        existing_data['bottle_tag'] = ','.join(sorted(filter(None, existing_tags)))
        
        # 获取累积的浮点数重量（如果不存在则从字符串解析）
        if '_accumulated_mass' in existing_data:
            accumulated_mass = existing_data['_accumulated_mass']
        else:
            # 第一次，从字符串转换
            try:
                accumulated_mass = float(existing_data.get('If_mass', '0.0'))
            except (ValueError, TypeError):
                accumulated_mass = 0.0
        
        # 累加新的重量
        try:
            new_mass = float(sample_weight)
            accumulated_mass += new_mass
            logger.info(f"合并sample {sample_id}: 累加 {new_mass}, 总重量 {accumulated_mass}, bottle_tag={existing_data['bottle_tag']}")
        except (ValueError, TypeError):
            logger.warning(f"无法解析sample_weight值: {sample_weight}")
            new_mass = 0.0
        
        # 保存累积的浮点数重量（用于下次累加）
        existing_data['_accumulated_mass'] = accumulated_mass
        # 格式化为最终的字符串（2位小数）
        existing_data['If_mass'] = f"{accumulated_mass:.2f}"

class DataMapper:
    """数据映射管理器"""
    
    def __init__(self):
        # 使用复合键：source_prefix + processor_type + table_name
        self.processors: Dict[str, DataSourceProcessor] = {}
        # 不再自动注册默认处理器，改为按需注册
        logger.info("DataMapper初始化完成，等待处理器注册")
    
    def _make_processor_key(self, source_prefix: str, processor_type: str, table_name: str) -> str:
        """生成处理器的唯一键
        
        Args:
            source_prefix: 数据源前缀
            processor_type: 处理器类型
            table_name: 目标表名
            
        Returns:
            唯一键字符串
        """
        return f"{source_prefix}#{processor_type}#{table_name}"
    
    def register_processor(self, processor: DataSourceProcessor, processor_type: str = None):
        """注册数据源处理器
        
        Args:
            processor: 处理器实例
            processor_type: 处理器类型（可选，如果不提供则从处理器类名推断）
        """
        if processor_type is None:
            # 从类名推断处理器类型
            class_name = processor.__class__.__name__
            if class_name.endswith('Processor'):
                processor_type = class_name[:-9].lower()  # 去掉Processor后缀
            else:
                processor_type = class_name.lower()
        
        key = self._make_processor_key(processor.source_prefix, processor_type, processor.table_name)
        self.processors[key] = processor
        
        logger.info(f"注册处理器: {key} -> {processor.__class__.__name__}")
    
    def get_processor(self, source_prefix: str, processor_type: str, table_name: str) -> Optional[DataSourceProcessor]:
        """根据复合键获取处理器
        
        Args:
            source_prefix: 数据源前缀
            processor_type: 处理器类型
            table_name: 目标表名
            
        Returns:
            处理器实例或None
        """
        key = self._make_processor_key(source_prefix, processor_type, table_name)
        return self.processors.get(key)
    
    def get_processor_by_table(self, table_name: str) -> Optional[DataSourceProcessor]:
        """根据表名获取处理器（兼容性方法，可能返回多个匹配的第一个）"""
        for processor in self.processors.values():
            if processor.table_name == table_name:
                return processor
        return None
    
    def get_processor_by_prefix(self, source_prefix: str) -> Optional[DataSourceProcessor]:
        """根据源前缀获取处理器（兼容性方法，可能返回多个匹配的第一个）"""
        for processor in self.processors.values():
            if processor.source_prefix == source_prefix:
                return processor
        return None
    
    def clean_data(self, raw_data: Dict[str, Any], source_prefix: str, processor_type: str, table_name: str) -> Dict[str, Any]:
        """清洗数据"""
        processor = self.get_processor(source_prefix, processor_type, table_name)
        if not processor:
            raise ValueError(f"未找到处理器: {source_prefix}#{processor_type}#{table_name}")
        
        return processor.clean_data(raw_data)
    
    def validate_data(self, data: Dict[str, Any], source_prefix: str, processor_type: str, table_name: str) -> List[str]:
        """验证数据"""
        processor = self.get_processor(source_prefix, processor_type, table_name)
        if not processor:
            raise ValueError(f"未找到处理器: {source_prefix}#{processor_type}#{table_name}")
        
        return processor.validate_data(data)
    
    def get_required_fields(self, source_prefix: str, processor_type: str, table_name: str) -> List[str]:
        """获取必填字段"""
        processor = self.get_processor(source_prefix, processor_type, table_name)
        if not processor:
            return []
        return processor.required_fields
    
    def get_unique_fields(self, source_prefix: str, processor_type: str, table_name: str) -> List[str]:
        """获取唯一字段"""
        processor = self.get_processor(source_prefix, processor_type, table_name)
        if not processor:
            return []
        return processor.unique_fields
    
    def get_required_columns(self, source_prefix: str, processor_type: str, table_name: str) -> List[str]:
        """获取CSV文件必需的列"""
        processor = self.get_processor(source_prefix, processor_type, table_name)
        if not processor:
            return []
        return processor.get_required_columns()
    
    def list_processors(self) -> Dict[str, str]:
        """列出所有处理器"""
        return {key: f"{processor.__class__.__name__}" for key, processor in self.processors.items()}
    
    def remove_processor(self, source_prefix: str, processor_type: str, table_name: str):
        """移除处理器"""
        key = self._make_processor_key(source_prefix, processor_type, table_name)
        if key in self.processors:
            del self.processors[key]
            logger.info(f"移除处理器: {key}")
    
    def clear_processors(self):
        """清除所有处理器"""
        self.processors.clear()
        logger.info("清除所有处理器")


# 便捷函数
def create_integer_cleaner(default: int = 0, min_value: Optional[int] = None, max_value: Optional[int] = None) -> IntegerCleaner:
    """创建整数清洗器"""
    return IntegerCleaner(default, min_value, max_value)


def create_string_cleaner(max_length: Optional[int] = None, pattern: Optional[str] = None, 
                         default: str = "", allow_empty: bool = True) -> StringCleaner:
    """创建字符串清洗器"""
    return StringCleaner(max_length, pattern, default, allow_empty)


def create_datetime_cleaner(format_pattern: str = "%Y_%m_%d_%H:%M:%S", 
                           default: Optional[datetime] = None, output_format: str = "iso") -> DateTimeCleaner:
    """创建日期时间清洗器"""
    return DateTimeCleaner(format_pattern, default, output_format)


def create_float_cleaner(default: float = 0.0, min_value: Optional[float] = None, 
                        max_value: Optional[float] = None, precision: Optional[int] = None,
                        format_as_string: bool = False) -> FloatCleaner:
    """创建浮点数清洗器"""
    return FloatCleaner(default, min_value, max_value, precision, format_as_string)


def create_boolean_cleaner(default: bool = False, true_values: List[str] = None, 
                          false_values: List[str] = None) -> BooleanCleaner:
    """创建布尔值清洗器"""
    return BooleanCleaner(default, true_values, false_values) 
