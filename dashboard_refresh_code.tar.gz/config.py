import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class Config:
    """配置类，管理所有配置参数"""
    
    # MinIO配置
    MINIO_ENDPOINT = os.getenv('MINIO_ENDPOINT', '172.17.15.122:9001')
    MINIO_ACCESS_KEY = os.getenv('MINIO_ACCESS_KEY', '')
    MINIO_SECRET_KEY = os.getenv('MINIO_SECRET_KEY', '')
    MINIO_SECURE = os.getenv('MINIO_SECURE', 'false').lower() == 'true'
    MINIO_BUCKET = os.getenv('MINIO_BUCKET', 'venus')  # MinIO存储桶名称
    
    # 同步配置 - 指定要同步的对象路径和对应的数据处理配置
    # 格式: "对象路径前缀:目标表名:处理器类型"
    SYNC_SOURCES = os.getenv('SYNC_SOURCES', 'REALITY/REPORT/yc/:t_chemist_data:chemist')
    LOCAL_DOWNLOAD_DIR = os.getenv('LOCAL_DOWNLOAD_DIR', './downloads')
    
    # 同步间隔（秒）
    SYNC_INTERVAL = int(os.getenv('SYNC_INTERVAL', 300))  # 默认5分钟
    
    # 日志配置
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'sync.log')
    
    # API配置
    API_BASE_URL = os.getenv('API_BASE_URL', 'http://10.254.61.225:13090')
    API_KEY = os.getenv('API_KEY', '')
    API_TIMEOUT = int(os.getenv('API_TIMEOUT', 30)) 

    # Redis配置
    REDIS_ENABLED = os.getenv('REDIS_ENABLED', 'false').lower() == 'true'
    REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
    REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
    REDIS_DB = int(os.getenv('REDIS_DB', 0))
    REDIS_USERNAME = os.getenv('REDIS_USERNAME', None)
    REDIS_PASSWORD = os.getenv('REDIS_PASSWORD', None)
    REDIS_KEY_PREFIX = os.getenv('REDIS_KEY_PREFIX', 'zy_syncer') 

    # 分析结果输出与对外访问
    # 容器内写入目录（请将宿主机 /data/analysis 挂载到容器同路径）
    ANALYSIS_OUTPUT_DIR = os.getenv('ANALYSIS_OUTPUT_DIR', '/data/analysis')
    # 对外可访问的HTTP前缀（Nginx反向代理/静态目录映射到ANALYSIS_OUTPUT_DIR）
    REPORT_BASE_URL = os.getenv('REPORT_BASE_URL', 'http://172.17.15.123:7860/analysis')
    REPORT_SERVER_PORT = int(os.getenv('REPORT_SERVER_PORT', '7860'))
