import downloadpdf
import qtof_parse.batch_process
import pandas as pd


def read_parsed_csv(csv_path):
    """
    读取CSV文件第一行的五个rank属性值
    
    Args:
        csv_path (str): CSV文件路径
        
    Returns:
        dict: 包含五个rank属性的字符串值
    """
    # 读取CSV文件
    df = pd.read_csv(csv_path)
    
    if df.empty:
        print("CSV文件为空")
        return None
    
    # 获取第一行数据
    first_row = df.iloc[0]
    
    # 定义要读取的五个属性
    rank_columns = ['rank1_peak', 'rank2_peak', 'rank3_peak', 'rank4_peak', 'rank5_peak']
    
    # 存储结果
    results = {}
    
    print("读取五个rank属性的第一行值:")
    print("-" * 50)
    
    for i, col in enumerate(rank_columns, 1):
        if col in first_row:
            value = str(first_row[col]) if pd.notna(first_row[col]) else ""
            print(f"rank{i}_peak: {value}")
            results[f'rank{i}_peak'] = value
        else:
            print(f"rank{i}_peak: 列不存在")
            results[f'rank{i}_peak'] = ""
    
    print("-" * 50)
    return results


def download_parse_pdf(pdf_url):
    """
    下载并解析PDF文件，返回五个峰信息
    
    Args:
        pdf_url (str): PDF文件URL
        
    Returns:
        tuple: (rank1_peak, rank2_peak, rank3_peak, rank4_peak, rank5_peak)
    """
    try:
        print(f"开始处理PDF: {pdf_url}")
        
        # 第一步：下载PDF
        downloaded_file_path = downloadpdf.main(pdf_url)
        if not downloaded_file_path:
            print(f"PDF下载失败，无法继续处理")
            return "", "", "", "", ""
        print(f"PDF下载完成: {downloaded_file_path}")
        
        # 第二步：解析PDF
        output_path = qtof_parse.batch_process.main(pdf_url)
        print(f"PDF解析完成，输出路径: {output_path}")
        
        if not output_path:
            print(f"PDF解析失败，output_path为空")
            return "", "", "", "", ""
        
        # 第三步：读取CSV结果
        results = read_parsed_csv(output_path)
        
        if not results:
            print(f"CSV读取失败，results为空")
            return "", "", "", "", ""
        
        # 第四步：提取峰信息
        rank1_peak = results.get('rank1_peak', '')
        rank2_peak = results.get('rank2_peak', '')
        rank3_peak = results.get('rank3_peak', '')
        rank4_peak = results.get('rank4_peak', '')
        rank5_peak = results.get('rank5_peak', '')
        
        print(f"峰信息提取成功: rank1={rank1_peak}")
        print(f"准备返回峰信息: ({rank1_peak}, {rank2_peak}, {rank3_peak}, {rank4_peak}, {rank5_peak})")
        
        return rank1_peak, rank2_peak, rank3_peak, rank4_peak, rank5_peak
        
    except Exception as e:
        print(f"download_parse_pdf出现异常: {e}")
        import traceback
        print(f"完整异常信息:\n{traceback.format_exc()}")
        print(f"返回空值元组")
        return "", "", "", "", ""






if __name__ == "__main__":
    pdf_url = "http://172.17.15.123/reports/qtof_pdf/qtof_z00101-E-7-2_2025_09_10_07_08_09/20250910064101-z00101-E-7-2_Analysis.pdf"
    download_parse_pdf(pdf_url)