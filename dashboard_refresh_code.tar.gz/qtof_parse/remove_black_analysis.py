#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QTOF谱图去噪分析模块
使用空白样品信号去除样品中的背景噪声
"""

import os
import pandas as pd
from typing import Dict, Optional, Tuple, Any
from .pdf_parser import PDFParser


class BlankRemovalAnalyzer:
    """QTOF谱图去噪分析器"""
    
    def __init__(self, 
                 blank_pos_path: Optional[str] = None,
                 blank_neg_path: Optional[str] = None,
                 sample_pos_path: Optional[str] = None,
                 sample_neg_path: Optional[str] = None):
        """
        初始化去噪分析器
        
        Args:
            blank_pos_path: 空白正离子信号PDF路径
            blank_neg_path: 空白负离子信号PDF路径
            sample_pos_path: 样品正离子信号PDF路径
            sample_neg_path: 样品负离子信号PDF路径
        """
        self.blank_pos_path = blank_pos_path
        self.blank_neg_path = blank_neg_path
        self.sample_pos_path = sample_pos_path
        self.sample_neg_path = sample_neg_path
        
        # 存储解析结果
        self.blank_pos_data = None
        self.blank_neg_data = None
        self.sample_pos_data = None
        self.sample_neg_data = None
        
        # 存储去噪后的结果
        self.denoised_pos_data = None
        self.denoised_neg_data = None
    
    def parse_pdf(self, pdf_path: str, ion_mode: str) -> Dict[str, Any]:
        """
        解析单个PDF文件
        
        Args:
            pdf_path: PDF文件路径
            ion_mode: 离子模式 ('positive' 或 'negative')
            
        Returns:
            Dict: 包含解析结果的字典
        """
        if not pdf_path or not os.path.exists(pdf_path):
            print(f"PDF文件不存在或未提供: {pdf_path}")
            return None
        
        print(f"\n{'=' * 80}")
        print(f"开始解析 {ion_mode} 模式PDF: {os.path.basename(pdf_path)}")
        print(f"{'=' * 80}")
        
        parser = PDFParser(pdf_path)
        
        try:
            # 打开PDF
            if not parser.open_pdf():
                return None
            
            # 提取文本内容
            print("提取文本内容...")
            text_content = parser.extract_text()
            print(f"提取到 {len(text_content)} 行文本内容")
            
            # 提取关键信息（BPC、DAD、ESI）
            print("提取色谱峰和质谱信息...")
            key_info = parser.extract_key_info()
            
            return key_info
            
        except Exception as e:
            print(f"解析PDF时发生错误: {e}")
            import traceback
            traceback.print_exc()
            return None
        
        finally:
            parser.close()
    
    def parse_all_pdfs(self) -> Dict[str, Dict[str, Any]]:
        """
        解析所有提供的PDF文件
        
        Returns:
            Dict: 包含所有解析结果的字典
        """
        results = {}
        
        # 解析空白正离子
        if self.blank_pos_path:
            print("\n处理空白正离子样品...")
            self.blank_pos_data = self.parse_pdf(self.blank_pos_path, 'positive')
            results['blank_pos'] = self.blank_pos_data
        
        # 解析空白负离子
        if self.blank_neg_path:
            print("\n处理空白负离子样品...")
            self.blank_neg_data = self.parse_pdf(self.blank_neg_path, 'negative')
            results['blank_neg'] = self.blank_neg_data
        
        # 解析样品正离子
        if self.sample_pos_path:
            print("\n处理样品正离子信号...")
            self.sample_pos_data = self.parse_pdf(self.sample_pos_path, 'positive')
            results['sample_pos'] = self.sample_pos_data
        
        # 解析样品负离子
        if self.sample_neg_path:
            print("\n处理样品负离子信号...")
            self.sample_neg_data = self.parse_pdf(self.sample_neg_path, 'negative')
            results['sample_neg'] = self.sample_neg_data
        
        return results
    
    def extract_interference_peaks(self, 
                                   peak_data: pd.DataFrame, 
                                   peak_type: str,
                                   max_peaks: int = 5,
                                   cumulative_threshold: float = 0.9) -> pd.DataFrame:
        """
        从峰数据中提取Height明显高于其他峰的干扰物质
        
        使用累积Height贡献度方法：选择Height最高的几个峰，使其累积Height达到总Height的80%
        
        Args:
            peak_data: 峰数据DataFrame
            peak_type: 峰类型（'BPC', 'DAD_210nm', 'DAD_254nm'）
            max_peaks: 最多提取的峰数量（默认5）
            cumulative_threshold: 累积Height阈值（默认0.8，即80%）
            
        Returns:
            pd.DataFrame: 干扰物质峰信息
        """
        if peak_data is None or peak_data.empty:
            print(f"  {peak_type}: 无数据")
            return pd.DataFrame()
        
        if 'Height' not in peak_data.columns:
            print(f"  {peak_type}: 缺少Height列")
            return pd.DataFrame()
        
        # 计算总Height
        total_height = peak_data['Height'].sum()
        
        # 按Height降序排序
        sorted_peaks = peak_data.sort_values('Height', ascending=False).copy()
        
        # 累积计算Height，找出达到阈值的峰
        cumulative_height = 0
        selected_peaks = []
        
        for idx, row in sorted_peaks.iterrows():
            cumulative_height += row['Height']
            selected_peaks.append(row)
            
            # 检查是否达到累积阈值或达到最大峰数
            if cumulative_height >= total_height * cumulative_threshold or len(selected_peaks) >= max_peaks:
                break
        
        # 创建结果DataFrame
        if selected_peaks:
            high_peaks = pd.DataFrame(selected_peaks)
            
            # 添加峰类型标识
            high_peaks['PeakType'] = peak_type
            
            # 计算实际累积比例
            actual_cumulative_ratio = cumulative_height / total_height
            
            print(f"  {peak_type}: 总共{len(peak_data)}个峰, "
                  f"总Height={total_height:.1f}, "
                  f"提取{len(high_peaks)}个峰, "
                  f"累积Height={cumulative_height:.1f} ({actual_cumulative_ratio*100:.1f}%)")
            
            return high_peaks
        else:
            print(f"  {peak_type}: 未找到符合条件的峰")
            return pd.DataFrame()
    
    def _match_mz_to_peaks(self, peak_df: pd.DataFrame, esi_info: pd.DataFrame) -> pd.DataFrame:
        """
        为峰数据匹配对应的m/z信息（通过RT最接近的ESI峰）
        
        Args:
            peak_df: 峰数据DataFrame（包含RT列）
            esi_info: ESI质谱信息DataFrame（包含RT和mz列）
            
        Returns:
            pd.DataFrame: 添加了mz和RT_Diff列的峰数据
        """
        if peak_df is None or peak_df.empty:
            return peak_df
        
        if esi_info is None or esi_info.empty:
            print("    ESI信息为空，无法匹配m/z")
            return peak_df
        
        # 复制数据以避免修改原始数据
        result_df = peak_df.copy()
        
        # 添加mz和RT_Diff列
        mz_values = []
        rt_diffs = []
        
        for idx, peak_row in result_df.iterrows():
            peak_rt = self._parse_rt_value(peak_row.get('RT'))
            
            # 找到RT最接近的ESI峰
            best_mz = None
            min_rt_diff = float('inf')
            
            if peak_rt is not None:
                for esi_idx, esi_row in esi_info.iterrows():
                    esi_rt = self._parse_rt_value(esi_row.get('RT'))
                    
                    if esi_rt is not None:
                        rt_diff = abs(peak_rt - esi_rt)
                        if rt_diff < min_rt_diff:
                            min_rt_diff = rt_diff
                            best_mz = esi_row.get('mz')
                
                mz_values.append(best_mz)
                rt_diffs.append(min_rt_diff if min_rt_diff != float('inf') else None)
            else:
                mz_values.append(None)
                rt_diffs.append(None)
        
        result_df['mz'] = mz_values
        result_df['RT_Diff'] = rt_diffs
        
        # 统计匹配成功的数量
        matched_count = sum(1 for mz in mz_values if mz is not None)
        print(f"    成功匹配 {matched_count}/{len(result_df)} 个峰的m/z信息")
        
        return result_df
    
    def _parse_rt_value(self, rt_str) -> float:
        """
        解析RT字符串为数值（从pdf_parser.py复制）
        
        Args:
            rt_str: RT字符串
            
        Returns:
            float: 所有数值的平均值，如果解析失败返回None
        """
        try:
            if isinstance(rt_str, (int, float)):
                return float(rt_str)
            
            rt_str = str(rt_str).strip()
            if not rt_str:
                return None
            
            # 去除字符串中的三个点
            rt_str = rt_str.replace('...', '')
            
            # 收集所有数值
            all_values = []
            
            # 按逗号分割
            comma_parts = [part.strip() for part in rt_str.split(',')]
            
            for part in comma_parts:
                if not part:
                    continue
                
                # 检查是否包含范围（短横线）
                if '-' in part:
                    # 处理范围
                    range_parts = part.split('-')
                    if len(range_parts) == 2:
                        try:
                            start = float(range_parts[0].strip())
                            end = float(range_parts[1].strip())
                            all_values.extend([start, end])
                        except ValueError:
                            continue
                else:
                    # 单个数值
                    try:
                        value = float(part)
                        all_values.append(value)
                    except ValueError:
                        continue
            
            # 计算平均值
            if all_values:
                return sum(all_values) / len(all_values)
            else:
                return None
                
        except Exception:
            return None
    
    def extract_blank_interferences(self) -> Dict[str, Any]:
        """
        从空白样品中提取干扰物质信息，并匹配对应的m/z值
        
        Returns:
            Dict: 包含正负离子模式干扰物质信息的字典
        """
        print(f"\n{'=' * 80}")
        print("提取空白样品干扰物质")
        print(f"{'=' * 80}")
        
        interferences = {
            'blank_pos_interferences': {},
            'blank_neg_interferences': {}
        }
        
        # 提取空白正离子干扰物质
        if self.blank_pos_data:
            print("\n提取空白正离子干扰物质:")
            pos_interferences = {}
            
            # 获取ESI信息用于匹配m/z
            esi_info = self.blank_pos_data.get('ESI_Info')
            
            # 从BPC峰提取
            if 'BPC_Peaks' in self.blank_pos_data and self.blank_pos_data['BPC_Peaks'] is not None:
                bpc_interference = self.extract_interference_peaks(
                    self.blank_pos_data['BPC_Peaks'], 'BPC'
                )
                if not bpc_interference.empty:
                    # 匹配m/z信息
                    bpc_interference = self._match_mz_to_peaks(bpc_interference, esi_info)
                    pos_interferences['BPC'] = bpc_interference
            
            # 从DAD 210nm峰提取
            if 'DAD_Peaks_210nm' in self.blank_pos_data and self.blank_pos_data['DAD_Peaks_210nm'] is not None:
                dad210_interference = self.extract_interference_peaks(
                    self.blank_pos_data['DAD_Peaks_210nm'], 'DAD_210nm'
                )
                if not dad210_interference.empty:
                    # 匹配m/z信息
                    dad210_interference = self._match_mz_to_peaks(dad210_interference, esi_info)
                    pos_interferences['DAD_210nm'] = dad210_interference
            
            # 从DAD 254nm峰提取
            if 'DAD_Peaks_254nm' in self.blank_pos_data and self.blank_pos_data['DAD_Peaks_254nm'] is not None:
                dad254_interference = self.extract_interference_peaks(
                    self.blank_pos_data['DAD_Peaks_254nm'], 'DAD_254nm'
                )
                if not dad254_interference.empty:
                    # 匹配m/z信息
                    dad254_interference = self._match_mz_to_peaks(dad254_interference, esi_info)
                    pos_interferences['DAD_254nm'] = dad254_interference
            
            interferences['blank_pos_interferences'] = pos_interferences
        
        # 提取空白负离子干扰物质
        if self.blank_neg_data:
            print("\n提取空白负离子干扰物质:")
            neg_interferences = {}
            
            # 获取ESI信息用于匹配m/z
            esi_info = self.blank_neg_data.get('ESI_Info')
            
            # 从BPC峰提取
            if 'BPC_Peaks' in self.blank_neg_data and self.blank_neg_data['BPC_Peaks'] is not None:
                bpc_interference = self.extract_interference_peaks(
                    self.blank_neg_data['BPC_Peaks'], 'BPC'
                )
                if not bpc_interference.empty:
                    # 匹配m/z信息
                    bpc_interference = self._match_mz_to_peaks(bpc_interference, esi_info)
                    neg_interferences['BPC'] = bpc_interference
            
            # 从DAD 210nm峰提取
            if 'DAD_Peaks_210nm' in self.blank_neg_data and self.blank_neg_data['DAD_Peaks_210nm'] is not None:
                dad210_interference = self.extract_interference_peaks(
                    self.blank_neg_data['DAD_Peaks_210nm'], 'DAD_210nm'
                )
                if not dad210_interference.empty:
                    # 匹配m/z信息
                    dad210_interference = self._match_mz_to_peaks(dad210_interference, esi_info)
                    neg_interferences['DAD_210nm'] = dad210_interference
            
            # 从DAD 254nm峰提取
            if 'DAD_Peaks_254nm' in self.blank_neg_data and self.blank_neg_data['DAD_Peaks_254nm'] is not None:
                dad254_interference = self.extract_interference_peaks(
                    self.blank_neg_data['DAD_Peaks_254nm'], 'DAD_254nm'
                )
                if not dad254_interference.empty:
                    # 匹配m/z信息
                    dad254_interference = self._match_mz_to_peaks(dad254_interference, esi_info)
                    neg_interferences['DAD_254nm'] = dad254_interference
            
            interferences['blank_neg_interferences'] = neg_interferences
        
        return interferences
    
    def print_interference_summary(self, interferences: Dict[str, Any]):
        """
        打印干扰物质提取摘要
        
        Args:
            interferences: 干扰物质信息字典
        """
        print(f"\n{'=' * 80}")
        print("空白样品干扰物质摘要")
        print(f"{'=' * 80}")
        
        # 打印正离子干扰物质
        if interferences['blank_pos_interferences']:
            print("\n【空白正离子干扰物质】")
            for peak_type, df in interferences['blank_pos_interferences'].items():
                print(f"\n{peak_type}:")
                if not df.empty:
                    # 选择关键列显示：Peak, RT, Height, Area_Sum, mz, RT_Diff
                    display_cols = ['Peak', 'RT', 'Height', 'Area_Sum', 'mz', 'RT_Diff']
                    available_cols = [col for col in display_cols if col in df.columns]
                    print(df[available_cols].to_string(index=False))
                else:
                    print("  无干扰峰")
        else:
            print("\n【空白正离子】无干扰物质数据")
        
        # 打印负离子干扰物质
        if interferences['blank_neg_interferences']:
            print("\n【空白负离子干扰物质】")
            for peak_type, df in interferences['blank_neg_interferences'].items():
                print(f"\n{peak_type}:")
                if not df.empty:
                    # 选择关键列显示：Peak, RT, Height, Area_Sum, mz, RT_Diff
                    display_cols = ['Peak', 'RT', 'Height', 'Area_Sum', 'mz', 'RT_Diff']
                    available_cols = [col for col in display_cols if col in df.columns]
                    print(df[available_cols].to_string(index=False))
                else:
                    print("  无干扰峰")
        else:
            print("\n【空白负离子】无干扰物质数据")
    
    def save_interference_results(self, interferences: Dict[str, Any], 
                                  output_dir: str = ".", 
                                  prefix: str = "blank_interference"):
        """
        保存干扰物质提取结果（已禁用，不生成任何文件）
        
        Args:
            interferences: 干扰物质信息字典
            output_dir: 输出目录
            prefix: 输出文件前缀
        """
        # 不再生成任何文件
        print(f"\n{'=' * 80}")
        print("干扰物质提取完成（不生成文件）")
        print(f"{'=' * 80}")
    
    def extract_sample_peaks(self, 
                            peak_data: pd.DataFrame, 
                            peak_type: str,
                            min_peaks: int = 5,
                            cumulative_threshold: float = 0.95) -> pd.DataFrame:
        """
        从样品峰数据中提取Area_Sum最大的几个峰
        
        Args:
            peak_data: 峰数据DataFrame
            peak_type: 峰类型（'DAD_210nm', 'DAD_254nm'）
            min_peaks: 最少提取的峰数量（默认5）
            cumulative_threshold: 累积Area_Sum阈值（默认0.95，即95%）
            
        Returns:
            pd.DataFrame: 样品峰信息
        """
        if peak_data is None or peak_data.empty:
            print(f"  {peak_type}: 无数据")
            return pd.DataFrame()
        
        if 'Area_Sum' not in peak_data.columns:
            print(f"  {peak_type}: 缺少Area_Sum列")
            return pd.DataFrame()
        
        # 计算总Area_Sum
        total_area_sum = peak_data['Area_Sum'].sum()
        
        # 按Area_Sum降序排序
        sorted_peaks = peak_data.sort_values('Area_Sum', ascending=False).copy()
        
        # 累积计算Area_Sum，找出达到阈值的峰
        cumulative_area_sum = 0
        selected_peaks = []
        
        for idx, row in sorted_peaks.iterrows():
            cumulative_area_sum += row['Area_Sum']
            selected_peaks.append(row)
            
            # 检查是否达到累积阈值且至少有min_peaks个峰
            if cumulative_area_sum >= total_area_sum * cumulative_threshold and len(selected_peaks) >= min_peaks:
                break
        
        # 确保至少有min_peaks个峰
        if len(selected_peaks) < min_peaks and len(sorted_peaks) >= min_peaks:
            selected_peaks = [sorted_peaks.iloc[i] for i in range(min_peaks)]
            cumulative_area_sum = sum(p['Area_Sum'] for p in selected_peaks)
        
        # 创建结果DataFrame
        if selected_peaks:
            sample_peaks = pd.DataFrame(selected_peaks)
            
            # 添加峰类型标识
            sample_peaks['PeakType'] = peak_type
            
            # 计算实际累积比例
            actual_cumulative_ratio = cumulative_area_sum / total_area_sum
            
            print(f"  {peak_type}: 总共{len(peak_data)}个峰, "
                  f"总Area_Sum={total_area_sum:.1f}, "
                  f"提取{len(sample_peaks)}个峰, "
                  f"累积Area_Sum={cumulative_area_sum:.1f} ({actual_cumulative_ratio*100:.1f}%)")
            
            return sample_peaks
        else:
            print(f"  {peak_type}: 未找到符合条件的峰")
            return pd.DataFrame()
    
    def _match_top5_spectrum_to_peak(self, peak_rt: float, esi_info: pd.DataFrame) -> Dict[str, Any]:
        """
        为单个峰匹配RT最接近的ESI信息，并提取Top 5质谱棒图
        
        Args:
            peak_rt: 峰的RT值
            esi_info: ESI质谱信息DataFrame
            
        Returns:
            Dict: 包含mz和top5_spectrum_mz的字典
        """
        if esi_info is None or esi_info.empty:
            return {'mz': None, 'top5_spectrum_mz': [], 'RT_Diff': None}
        
        # 找到RT最接近的ESI峰（基于基本信息中的RT）
        min_rt_diff = float('inf')
        matched_peak_num = None
        matched_mz = None
        
        # 先根据Peak分组，获取每个Peak的基本信息
        if 'Peak' in esi_info.columns:
            unique_peaks = esi_info['Peak'].unique()
            
            for peak_num in unique_peaks:
                # 获取该Peak的第一条记录作为代表（基本信息）
                peak_records = esi_info[esi_info['Peak'] == peak_num]
                if peak_records.empty:
                    continue
                
                first_record = peak_records.iloc[0]
                esi_rt = self._parse_rt_value(first_record.get('RT'))
                
                if esi_rt is not None:
                    rt_diff = abs(peak_rt - esi_rt)
                    if rt_diff < min_rt_diff:
                        min_rt_diff = rt_diff
                        matched_peak_num = peak_num
                        matched_mz = first_record.get('mz')
        
        # 如果找到匹配的Peak，提取该Peak的Top 5 spectrum_mz
        top5_spectrum_mz = []
        if matched_peak_num is not None:
            # 第一个值使用mz（最强信号的m/z）
            if matched_mz is not None:
                top5_spectrum_mz.append(matched_mz)
            
            # 获取该Peak的所有质谱棒图记录
            peak_spectrum = esi_info[esi_info['Peak'] == matched_peak_num].copy()
            
            # 检查是否有spectrum_mz和spectrum_intensity列
            if 'spectrum_mz' in peak_spectrum.columns and 'spectrum_intensity' in peak_spectrum.columns:
                # 过滤出有效的spectrum数据
                valid_spectrum = peak_spectrum[peak_spectrum['spectrum_mz'].notna() & 
                                               peak_spectrum['spectrum_intensity'].notna()].copy()
                
                if not valid_spectrum.empty:
                    # 按spectrum_intensity降序排序
                    valid_spectrum = valid_spectrum.sort_values('spectrum_intensity', ascending=False)
                    
                    # 提取其他的spectrum_mz（排除与mz相同的值，避免重复）
                    remaining_mz = []
                    for mz_val in valid_spectrum['spectrum_mz'].tolist():
                        # 如果已经有mz了，排除与mz非常接近的值（容差0.01）
                        if matched_mz is not None and abs(mz_val - matched_mz) < 1:
                            continue
                        remaining_mz.append(mz_val)
                        if len(top5_spectrum_mz) + len(remaining_mz) >= 5:
                            break
                    
                    # 合并：第一个是mz，后面是其他的spectrum_mz
                    top5_spectrum_mz.extend(remaining_mz[:4])  # 最多再添加4个，总共5个
        
        return {
            'mz': matched_mz,
            'top5_spectrum_mz': top5_spectrum_mz,
            'RT_Diff': min_rt_diff if min_rt_diff != float('inf') else None,
            'matched_peak_num': matched_peak_num
        }
    
    def analyze_sample_peaks(self) -> Dict[str, Any]:
        """
        分析样品峰信息，提取Area_Sum最大的峰并匹配质谱信息
        
        Returns:
            Dict: 包含正负离子模式样品峰分析结果的字典
        """
        print(f"\n{'=' * 80}")
        print("分析样品峰信息")
        print(f"{'=' * 80}")
        
        sample_analysis = {
            'sample_pos_analysis': {},
            'sample_neg_analysis': {}
        }
        
        # 分析样品正离子
        if self.sample_pos_data:
            print("\n分析样品正离子峰:")
            pos_analysis = {}
            
            # 获取ESI信息用于匹配
            esi_info = self.sample_pos_data.get('ESI_Info')
            
            # 从DAD 210nm峰提取
            if 'DAD_Peaks_210nm' in self.sample_pos_data and self.sample_pos_data['DAD_Peaks_210nm'] is not None:
                dad210_peaks = self.extract_sample_peaks(
                    self.sample_pos_data['DAD_Peaks_210nm'], 'DAD_210nm'
                )
                if not dad210_peaks.empty:
                    # 为每个峰匹配质谱信息
                    dad210_peaks = self._match_spectrum_to_sample_peaks(dad210_peaks, esi_info)
                    pos_analysis['DAD_210nm'] = dad210_peaks
            
            # 从DAD 254nm峰提取
            if 'DAD_Peaks_254nm' in self.sample_pos_data and self.sample_pos_data['DAD_Peaks_254nm'] is not None:
                dad254_peaks = self.extract_sample_peaks(
                    self.sample_pos_data['DAD_Peaks_254nm'], 'DAD_254nm'
                )
                if not dad254_peaks.empty:
                    # 为每个峰匹配质谱信息
                    dad254_peaks = self._match_spectrum_to_sample_peaks(dad254_peaks, esi_info)
                    pos_analysis['DAD_254nm'] = dad254_peaks
            
            sample_analysis['sample_pos_analysis'] = pos_analysis
        
        # 分析样品负离子
        if self.sample_neg_data:
            print("\n分析样品负离子峰:")
            neg_analysis = {}
            
            # 获取ESI信息用于匹配
            esi_info = self.sample_neg_data.get('ESI_Info')
            
            # 从DAD 210nm峰提取
            if 'DAD_Peaks_210nm' in self.sample_neg_data and self.sample_neg_data['DAD_Peaks_210nm'] is not None:
                dad210_peaks = self.extract_sample_peaks(
                    self.sample_neg_data['DAD_Peaks_210nm'], 'DAD_210nm'
                )
                if not dad210_peaks.empty:
                    # 为每个峰匹配质谱信息
                    dad210_peaks = self._match_spectrum_to_sample_peaks(dad210_peaks, esi_info)
                    neg_analysis['DAD_210nm'] = dad210_peaks
            
            # 从DAD 254nm峰提取
            if 'DAD_Peaks_254nm' in self.sample_neg_data and self.sample_neg_data['DAD_Peaks_254nm'] is not None:
                dad254_peaks = self.extract_sample_peaks(
                    self.sample_neg_data['DAD_Peaks_254nm'], 'DAD_254nm'
                )
                if not dad254_peaks.empty:
                    # 为每个峰匹配质谱信息
                    dad254_peaks = self._match_spectrum_to_sample_peaks(dad254_peaks, esi_info)
                    neg_analysis['DAD_254nm'] = dad254_peaks
            
            sample_analysis['sample_neg_analysis'] = neg_analysis
        
        return sample_analysis
    
    def _match_spectrum_to_sample_peaks(self, peak_df: pd.DataFrame, esi_info: pd.DataFrame) -> pd.DataFrame:
        """
        为样品峰数据匹配质谱信息（mz和top5_spectrum_mz）
        
        Args:
            peak_df: 峰数据DataFrame
            esi_info: ESI质谱信息DataFrame
            
        Returns:
            pd.DataFrame: 添加了mz、top5_spectrum_mz等列的峰数据
        """
        if peak_df is None or peak_df.empty:
            return peak_df
        
        if esi_info is None or esi_info.empty:
            print("    ESI信息为空，无法匹配质谱信息")
            return peak_df
        
        # 复制数据
        result_df = peak_df.copy()
        
        # 为每个峰匹配质谱信息
        mz_values = []
        top5_spectrum_mz_list = []
        rt_diffs = []
        matched_peak_nums = []
        
        for idx, peak_row in result_df.iterrows():
            peak_rt = self._parse_rt_value(peak_row.get('RT'))
            
            if peak_rt is not None:
                match_result = self._match_top5_spectrum_to_peak(peak_rt, esi_info)
                mz_values.append(match_result['mz'])
                top5_spectrum_mz_list.append(match_result['top5_spectrum_mz'])
                rt_diffs.append(match_result['RT_Diff'])
                matched_peak_nums.append(match_result['matched_peak_num'])
            else:
                mz_values.append(None)
                top5_spectrum_mz_list.append([])
                rt_diffs.append(None)
                matched_peak_nums.append(None)
        
        result_df['mz'] = mz_values
        result_df['top5_spectrum_mz'] = top5_spectrum_mz_list
        result_df['RT_Diff'] = rt_diffs
        result_df['matched_ESI_Peak'] = matched_peak_nums
        
        # 统计匹配成功的数量
        matched_count = sum(1 for mz in mz_values if mz is not None)
        print(f"    成功匹配 {matched_count}/{len(result_df)} 个峰的质谱信息")
        
        return result_df
    
    def print_sample_analysis(self, sample_analysis: Dict[str, Any]):
        """
        打印样品峰分析结果
        
        Args:
            sample_analysis: 样品峰分析结果字典
        """
        print(f"\n{'=' * 80}")
        print("样品峰分析结果")
        print(f"{'=' * 80}")
        
        # 打印正离子样品分析
        if sample_analysis['sample_pos_analysis']:
            print("\n【样品正离子峰分析】")
            for peak_type, df in sample_analysis['sample_pos_analysis'].items():
                print(f"\n{peak_type}:")
                if not df.empty:
                    self._print_sample_peaks_detail(df)
                else:
                    print("  无数据")
        else:
            print("\n【样品正离子】无分析数据")
        
        # 打印负离子样品分析
        if sample_analysis['sample_neg_analysis']:
            print("\n【样品负离子峰分析】")
            for peak_type, df in sample_analysis['sample_neg_analysis'].items():
                print(f"\n{peak_type}:")
                if not df.empty:
                    self._print_sample_peaks_detail(df)
                else:
                    print("  无数据")
        else:
            print("\n【样品负离子】无分析数据")
    
    def _print_sample_peaks_detail(self, df: pd.DataFrame):
        """
        打印样品峰的详细信息
        
        Args:
            df: 样品峰DataFrame
        """
        for idx, row in df.iterrows():
            print(f"\n  Peak {row.get('Peak', 'N/A')}:")
            print(f"    RT: {row.get('RT', 'N/A')}")
            print(f"    Area_Sum: {row.get('Area_Sum', 'N/A')}")
            print(f"    mz: {row.get('mz', 'N/A')}")
            
            top5_mz = row.get('top5_spectrum_mz', [])
            if top5_mz and len(top5_mz) > 0:
                top5_str = ', '.join([f"{mz:.4f}" for mz in top5_mz])
                print(f"    Top5 spectrum_mz: [{top5_str}]")
            else:
                print(f"    Top5 spectrum_mz: 无数据")
            
            print(f"    RT_Diff: {row.get('RT_Diff', 'N/A')}")
    
    def save_sample_analysis(self, sample_analysis: Dict[str, Any], 
                           output_dir: str = ".", 
                           prefix: str = "sample_analysis"):
        """
        保存样品峰分析结果
        
        Args:
            sample_analysis: 样品峰分析结果字典
            output_dir: 输出目录
            prefix: 输出文件前缀
        """
        os.makedirs(output_dir, exist_ok=True)
        
        print(f"\n{'=' * 80}")
        print("保存样品峰分析结果")
        print(f"{'=' * 80}")
        
        # 保存正离子样品分析（已注释，不生成中间CSV文件）
        # if sample_analysis['sample_pos_analysis']:
        #     for peak_type, df in sample_analysis['sample_pos_analysis'].items():
        #         if not df.empty:
        #             filename = os.path.join(output_dir, f"{prefix}_pos_{peak_type}.csv")
        #             # 将top5_spectrum_mz列表转换为字符串以便保存
        #             df_to_save = df.copy()
        #             if 'top5_spectrum_mz' in df_to_save.columns:
        #                 df_to_save['top5_spectrum_mz'] = df_to_save['top5_spectrum_mz'].apply(
        #                     lambda x: '; '.join([f"{mz:.4f}" for mz in x]) if x else ''
        #                 )
        #             df_to_save.to_csv(filename, index=False, encoding='utf-8')
        #             print(f"已保存: {filename}")
        
        # 保存负离子样品分析（已注释，不生成中间CSV文件）
        # if sample_analysis['sample_neg_analysis']:
        #     for peak_type, df in sample_analysis['sample_neg_analysis'].items():
        #         if not df.empty:
        #             filename = os.path.join(output_dir, f"{prefix}_neg_{peak_type}.csv")
        #             # 将top5_spectrum_mz列表转换为字符串以便保存
        #             df_to_save = df.copy()
        #             if 'top5_spectrum_mz' in df_to_save.columns:
        #                 df_to_save['top5_spectrum_mz'] = df_to_save['top5_spectrum_mz'].apply(
        #                     lambda x: '; '.join([f"{mz:.4f}" for mz in x]) if x else ''
        #                 )
        #             df_to_save.to_csv(filename, index=False, encoding='utf-8')
        #             print(f"已保存: {filename}")
    
    def annotate_interferences(self, 
                               sample_analysis: Dict[str, Any], 
                               interferences: Dict[str, Any]) -> Dict[str, Any]:
        """
        综合空白信息和样品信息，对样品峰进行干扰物备注
        
        Args:
            sample_analysis: 样品峰分析结果
            interferences: 空白干扰物信息
            
        Returns:
            Dict: 添加了干扰物备注的样品峰分析结果
        """
        print(f"\n{'=' * 80}")
        print("对样品峰进行干扰物备注")
        print(f"{'=' * 80}")
        
        annotated_analysis = {
            'sample_pos_analysis': {},
            'sample_neg_analysis': {}
        }
        
        # 处理正离子模式
        if sample_analysis['sample_pos_analysis']:
            print("\n处理正离子模式样品峰...")
            blank_interferences = interferences.get('blank_pos_interferences', {})
            
            for peak_type in ['DAD_210nm', 'DAD_254nm']:
                if peak_type in sample_analysis['sample_pos_analysis']:
                    sample_peaks = sample_analysis['sample_pos_analysis'][peak_type]
                    blank_peaks = blank_interferences.get(peak_type)
                    
                    annotated_peaks = self._annotate_peaks_with_interferences(
                        sample_peaks, blank_peaks, peak_type, 'positive'
                    )
                    annotated_analysis['sample_pos_analysis'][peak_type] = annotated_peaks
        
        # 处理负离子模式
        if sample_analysis['sample_neg_analysis']:
            print("\n处理负离子模式样品峰...")
            blank_interferences = interferences.get('blank_neg_interferences', {})
            
            for peak_type in ['DAD_210nm', 'DAD_254nm']:
                if peak_type in sample_analysis['sample_neg_analysis']:
                    sample_peaks = sample_analysis['sample_neg_analysis'][peak_type]
                    blank_peaks = blank_interferences.get(peak_type)
                    
                    annotated_peaks = self._annotate_peaks_with_interferences(
                        sample_peaks, blank_peaks, peak_type, 'negative'
                    )
                    annotated_analysis['sample_neg_analysis'][peak_type] = annotated_peaks
        
        return annotated_analysis
    
    def _annotate_peaks_with_interferences(self, 
                                          sample_peaks: pd.DataFrame, 
                                          blank_peaks: pd.DataFrame,
                                          peak_type: str,
                                          ion_mode: str) -> pd.DataFrame:
        """
        为样品峰添加干扰物备注
        
        Args:
            sample_peaks: 样品峰DataFrame
            blank_peaks: 空白干扰峰DataFrame
            peak_type: 峰类型
            ion_mode: 离子模式
            
        Returns:
            pd.DataFrame: 添加了备注的样品峰DataFrame
        """
        if sample_peaks is None or sample_peaks.empty:
            return sample_peaks
        
        print(f"  处理{ion_mode}模式 {peak_type}...")
        
        # 复制数据
        annotated_peaks = sample_peaks.copy()
        
        # 添加备注列
        remarks = []
        annotated_mz_list = []
        annotated_top5_list = []
        
        for idx, sample_row in annotated_peaks.iterrows():
            sample_rt = self._parse_rt_value(sample_row.get('RT'))
            rt_diff = sample_row.get('RT_Diff')
            sample_mz = sample_row.get('mz')
            sample_top5 = sample_row.get('top5_spectrum_mz', [])
            
            # 检查是否有对应的MS信号
            if rt_diff is not None and rt_diff > 1:
                remarks.append("没有对应MS信号")
                annotated_mz_list.append(sample_mz)
                annotated_top5_list.append(sample_top5)
                continue
            
            # 查找RT接近的空白峰
            matched_blank_peaks = self._find_rt_matched_blank_peaks(
                sample_rt, blank_peaks, rt_tolerance=1.0
            )
            
            if matched_blank_peaks.empty:
                remarks.append("")
                annotated_mz_list.append(sample_mz)
                annotated_top5_list.append(sample_top5)
                continue
            
            # 收集所有空白峰的mz值（排除没有对应MS信号的空白峰）
            blank_mz_list = []
            for _, blank_row in matched_blank_peaks.iterrows():
                blank_rt_diff = blank_row.get('RT_Diff')
                
                # 如果空白峰的RT_Diff > 1，说明该空白峰也没有对应的MS信号，跳过
                if blank_rt_diff is not None and blank_rt_diff > 1:
                    continue
                
                blank_mz = blank_row.get('mz')
                if blank_mz is not None:
                    blank_mz_list.append(blank_mz)
            
            # 标注mz
            annotated_mz = self._annotate_mz_value(sample_mz, blank_mz_list)
            annotated_mz_list.append(annotated_mz)
            
            # 标注top5_spectrum_mz
            annotated_top5 = self._annotate_top5_mz(sample_top5, blank_mz_list)
            annotated_top5_list.append(annotated_top5)
            
            # 生成备注
            interference_count = sum(1 for mz in [annotated_mz] + annotated_top5 if '（干扰物）' in str(mz))
            if interference_count > 0:
                remarks.append(f"检测到{interference_count}个干扰物信号")
            else:
                remarks.append("")
        
        # 添加新列
        annotated_peaks['Remark'] = remarks
        annotated_peaks['mz_annotated'] = annotated_mz_list
        annotated_peaks['top5_spectrum_mz_annotated'] = annotated_top5_list
        
        print(f"    完成{len(annotated_peaks)}个峰的标注")
        
        return annotated_peaks
    
    def _find_rt_matched_blank_peaks(self, 
                                     sample_rt: float, 
                                     blank_peaks: pd.DataFrame, 
                                     rt_tolerance: float = 1.0) -> pd.DataFrame:
        """
        查找RT接近的空白峰
        
        Args:
            sample_rt: 样品峰的RT
            blank_peaks: 空白峰DataFrame
            rt_tolerance: RT容差
            
        Returns:
            pd.DataFrame: RT接近的空白峰
        """
        if blank_peaks is None or blank_peaks.empty or sample_rt is None:
            return pd.DataFrame()
        
        matched_peaks = []
        
        for idx, blank_row in blank_peaks.iterrows():
            blank_rt = self._parse_rt_value(blank_row.get('RT'))
            
            if blank_rt is not None:
                rt_diff = abs(sample_rt - blank_rt)
                if rt_diff < rt_tolerance:
                    matched_peaks.append(blank_row)
        
        if matched_peaks:
            return pd.DataFrame(matched_peaks)
        else:
            return pd.DataFrame()
    
    def _annotate_mz_value(self, mz_value: float, blank_mz_list: list, mz_tolerance: float = 1.0) -> str:
        """
        为单个mz值添加干扰物标注
        
        Args:
            mz_value: mz值
            blank_mz_list: 空白峰的mz列表
            mz_tolerance: mz容差
            
        Returns:
            str: 标注后的mz值
        """
        if mz_value is None:
            return None
        
        # 检查是否与任何空白mz接近
        is_interference = False
        for blank_mz in blank_mz_list:
            if abs(mz_value - blank_mz) < mz_tolerance:
                is_interference = True
                break
        
        if is_interference:
            return f"{mz_value:.4f}（干扰物）"
        else:
            return f"{mz_value:.4f}"
    
    def _annotate_top5_mz(self, top5_mz_list: list, blank_mz_list: list, mz_tolerance: float = 1.0) -> list:
        """
        为top5_spectrum_mz列表添加干扰物标注
        
        Args:
            top5_mz_list: top5 mz列表
            blank_mz_list: 空白峰的mz列表
            mz_tolerance: mz容差
            
        Returns:
            list: 标注后的mz列表
        """
        if not top5_mz_list:
            return []
        
        annotated_list = []
        
        for mz_value in top5_mz_list:
            if mz_value is None:
                annotated_list.append(None)
                continue
            
            # 检查是否与任何空白mz接近
            is_interference = False
            for blank_mz in blank_mz_list:
                if abs(mz_value - blank_mz) < mz_tolerance:
                    is_interference = True
                    break
            
            if is_interference:
                annotated_list.append(f"{mz_value:.4f}（干扰物）")
            else:
                annotated_list.append(f"{mz_value:.4f}")
        
        return annotated_list
    
    def print_annotated_analysis(self, annotated_analysis: Dict[str, Any]):
        """
        打印标注后的样品峰分析结果
        
        Args:
            annotated_analysis: 标注后的样品峰分析结果
        """
        print(f"\n{'=' * 80}")
        print("标注后的样品峰分析结果")
        print(f"{'=' * 80}")
        
        # 打印正离子
        if annotated_analysis['sample_pos_analysis']:
            print("\n【正离子模式】")
            for peak_type, df in annotated_analysis['sample_pos_analysis'].items():
                print(f"\n{peak_type}:")
                if not df.empty:
                    self._print_annotated_peaks_detail(df)
                else:
                    print("  无数据")
        else:
            print("\n【正离子模式】无数据")
        
        # 打印负离子
        if annotated_analysis['sample_neg_analysis']:
            print("\n【负离子模式】")
            for peak_type, df in annotated_analysis['sample_neg_analysis'].items():
                print(f"\n{peak_type}:")
                if not df.empty:
                    self._print_annotated_peaks_detail(df)
                else:
                    print("  无数据")
        else:
            print("\n【负离子模式】无数据")
    
    def _print_annotated_peaks_detail(self, df: pd.DataFrame):
        """
        打印标注后的样品峰详细信息
        
        Args:
            df: 标注后的样品峰DataFrame
        """
        for idx, row in df.iterrows():
            print(f"\n  Peak {row.get('Peak', 'N/A')}:")
            print(f"    RT: {row.get('RT', 'N/A')}")
            print(f"    Area_Sum: {row.get('Area_Sum', 'N/A')}")
            
            mz_annotated = row.get('mz_annotated', 'N/A')
            print(f"    mz: {mz_annotated}")
            
            top5_annotated = row.get('top5_spectrum_mz_annotated', [])
            if top5_annotated:
                top5_str = '; '.join([str(mz) for mz in top5_annotated])
                print(f"    Top5 spectrum_mz: {top5_str}")
            else:
                print(f"    Top5 spectrum_mz: 无数据")
            
            remark = row.get('Remark', '')
            if remark:
                print(f"    备注: {remark}")
    
    def _save_annotated_txt_summary(self, annotated_analysis: Dict[str, Any], 
                                   output_dir: str = ".", 
                                   prefix: str = "annotated_sample"):
        """
        保存标注后的样品峰分析结果到统一的TXT文件（以RT为标识）
        
        Args:
            annotated_analysis: 标注后的样品峰分析结果
            output_dir: 输出目录
            prefix: 输出文件前缀
        """
        summary_file = os.path.join(output_dir, f"{prefix}_summary.txt")
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write("样品峰分析结果汇总（标注干扰物信息）\n")
            f.write("=" * 80 + "\n\n")
            
            # 写入正离子模式数据
            if annotated_analysis['sample_pos_analysis']:
                f.write("【正离子模式】\n")
                f.write("-" * 80 + "\n\n")
                
                for peak_type, df in annotated_analysis['sample_pos_analysis'].items():
                    if not df.empty:
                        f.write(f"{peak_type}:\n")
                        f.write("-" * 60 + "\n\n")
                        
                        for idx, row in df.iterrows():
                            rt_value = row.get('RT', 'N/A')
                            f.write(f"RT: {rt_value}\n")
                            f.write(f"  Area_Sum: {row.get('Area_Sum', 'N/A')}\n")
                            
                            # 格式化 top5_spectrum_mz_annotated（保留4位小数）
                            top5_annotated = row.get('top5_spectrum_mz_annotated', [])
                            if top5_annotated:
                                if isinstance(top5_annotated, list):
                                    # 如果是列表，格式化每个元素为4位小数
                                    formatted_mz = []
                                    for mz in top5_annotated:
                                        if isinstance(mz, str):
                                            # 如果是字符串，可能包含"（干扰物）"标记
                                            if '（干扰物）' in mz:
                                                # 提取数字部分
                                                try:
                                                    num_str = mz.replace('（干扰物）', '').strip()
                                                    num = float(num_str)
                                                    formatted_mz.append(f"{num:.4f}（干扰物）")
                                                except:
                                                    formatted_mz.append(mz)
                                            else:
                                                try:
                                                    formatted_mz.append(f"{float(mz):.4f}")
                                                except:
                                                    formatted_mz.append(mz)
                                        else:
                                            formatted_mz.append(f"{float(mz):.4f}")
                                    top5_str = '; '.join(formatted_mz)
                                else:
                                    top5_str = str(top5_annotated)
                                f.write(f"  Top5 spectrum m/z: {top5_str}\n")
                            else:
                                f.write(f"  Top5 spectrum m/z: 无数据\n")
                            
                            # 备注信息
                            remark = row.get('Remark', '')
                            if remark:
                                f.write(f"  备注: {remark}\n")
                            
                            f.write("\n")
                        
                        f.write("\n")
                    else:
                        f.write(f"{peak_type}: 无数据\n\n")
            else:
                f.write("【正离子模式】无数据\n\n")
            
            # 写入负离子模式数据
            if annotated_analysis['sample_neg_analysis']:
                f.write("【负离子模式】\n")
                f.write("-" * 80 + "\n\n")
                
                for peak_type, df in annotated_analysis['sample_neg_analysis'].items():
                    if not df.empty:
                        f.write(f"{peak_type}:\n")
                        f.write("-" * 60 + "\n\n")
                        
                        for idx, row in df.iterrows():
                            rt_value = row.get('RT', 'N/A')
                            f.write(f"RT: {rt_value}\n")
                            f.write(f"  Area_Sum: {row.get('Area_Sum', 'N/A')}\n")
                            
                            # 格式化 top5_spectrum_mz_annotated（保留4位小数）
                            top5_annotated = row.get('top5_spectrum_mz_annotated', [])
                            if top5_annotated:
                                if isinstance(top5_annotated, list):
                                    # 如果是列表，格式化每个元素为4位小数
                                    formatted_mz = []
                                    for mz in top5_annotated:
                                        if isinstance(mz, str):
                                            # 如果是字符串，可能包含"（干扰物）"标记
                                            if '（干扰物）' in mz:
                                                # 提取数字部分
                                                try:
                                                    num_str = mz.replace('（干扰物）', '').strip()
                                                    num = float(num_str)
                                                    formatted_mz.append(f"{num:.4f}（干扰物）")
                                                except:
                                                    formatted_mz.append(mz)
                                            else:
                                                try:
                                                    formatted_mz.append(f"{float(mz):.4f}")
                                                except:
                                                    formatted_mz.append(mz)
                                        else:
                                            formatted_mz.append(f"{float(mz):.4f}")
                                    top5_str = '; '.join(formatted_mz)
                                else:
                                    top5_str = str(top5_annotated)
                                f.write(f"  Top5 spectrum m/z: {top5_str}\n")
                            else:
                                f.write(f"  Top5 spectrum m/z: 无数据\n")
                            
                            # 备注信息
                            remark = row.get('Remark', '')
                            if remark:
                                f.write(f"  备注: {remark}\n")
                            
                            f.write("\n")
                        
                        f.write("\n")
                    else:
                        f.write(f"{peak_type}: 无数据\n\n")
            else:
                f.write("【负离子模式】无数据\n\n")
        
        print(f"已保存TXT汇总文件: {summary_file}")
    
    def save_annotated_analysis(self, annotated_analysis: Dict[str, Any], 
                               output_dir: str = ".", 
                               prefix: str = "annotated_sample"):
        """
        保存标注后的样品峰分析结果（仅TXT汇总）
        
        Args:
            annotated_analysis: 标注后的样品峰分析结果
            output_dir: 输出目录
            prefix: 输出文件前缀
        """
        os.makedirs(output_dir, exist_ok=True)
        
        print(f"\n{'=' * 80}")
        print("保存标注后的样品峰分析结果")
        print(f"{'=' * 80}")
        
        # 不再保存CSV文件，直接生成TXT汇总
        # # 保存正离子
        # if annotated_analysis['sample_pos_analysis']:
        #     for peak_type, df in annotated_analysis['sample_pos_analysis'].items():
        #         if not df.empty:
        #             filename = os.path.join(output_dir, f"{prefix}_pos_{peak_type}.csv")
        #             df_to_save = df.copy()
        #             
        #             # 将top5_spectrum_mz_annotated列表转换为字符串（mz值保留4位小数）
        #             if 'top5_spectrum_mz_annotated' in df_to_save.columns:
        #                 def format_mz_list(x):
        #                     if not x or x == '':
        #                         return ''
        #                     # 如果已经是字符串，先分割再格式化
        #                     if isinstance(x, str):
        #                         try:
        #                             mz_list = [float(mz.strip()) for mz in x.split(';')]
        #                             return '; '.join([f"{mz:.4f}" for mz in mz_list])
        #                         except:
        #                             return x  # 如果转换失败，返回原值
        #                     # 如果是列表，直接格式化
        #                     elif isinstance(x, list):
        #                         return '; '.join([f"{float(mz):.4f}" for mz in x])
        #                     else:
        #                         return str(x)
        #                 
        #                 df_to_save['top5_spectrum_mz_annotated'] = df_to_save['top5_spectrum_mz_annotated'].apply(format_mz_list)
        #             
        #             # 精简输出列：只保留核心信息
        #             columns_to_keep = ['RT', 'Area_Sum', 'RT_Diff', 'mz_annotated', 'top5_spectrum_mz_annotated', 'Remark']
        #             available_columns = [col for col in columns_to_keep if col in df_to_save.columns]
        #             df_to_save = df_to_save[available_columns]
        #             
        #             df_to_save.to_csv(filename, index=False, encoding='utf-8')
        #             print(f"已保存: {filename}")
        
        # # 保存负离子
        # if annotated_analysis['sample_neg_analysis']:
        #     for peak_type, df in annotated_analysis['sample_neg_analysis'].items():
        #         if not df.empty:
        #             filename = os.path.join(output_dir, f"{prefix}_neg_{peak_type}.csv")
        #             df_to_save = df.copy()
        #             
        #             # 将top5_spectrum_mz_annotated列表转换为字符串（mz值保留4位小数）
        #             if 'top5_spectrum_mz_annotated' in df_to_save.columns:
        #                 def format_mz_list(x):
        #                     if not x or x == '':
        #                         return ''
        #                     # 如果已经是字符串，先分割再格式化
        #                     if isinstance(x, str):
        #                         try:
        #                             mz_list = [float(mz.strip()) for mz in x.split(';')]
        #                             return '; '.join([f"{mz:.4f}" for mz in mz_list])
        #                         except:
        #                             return x  # 如果转换失败，返回原值
        #                     # 如果是列表，直接格式化
        #                     elif isinstance(x, list):
        #                         return '; '.join([f"{float(mz):.4f}" for mz in x])
        #                     else:
        #                         return str(x)
        #                 
        #                 df_to_save['top5_spectrum_mz_annotated'] = df_to_save['top5_spectrum_mz_annotated'].apply(format_mz_list)
        #             
        #             # 精简输出列：只保留核心信息
        #             columns_to_keep = ['RT', 'Area_Sum', 'RT_Diff', 'mz_annotated', 'top5_spectrum_mz_annotated', 'Remark']
        #             available_columns = [col for col in columns_to_keep if col in df_to_save.columns]
        #             df_to_save = df_to_save[available_columns]
        #             
        #             df_to_save.to_csv(filename, index=False, encoding='utf-8')
        #             print(f"已保存: {filename}")
        
        # 生成统一的TXT汇总文件
        self._save_annotated_txt_summary(annotated_analysis, output_dir, prefix)

def main():
    """示例用法"""
    # 定义PDF文件路径
    blank_pos = "zhongyao_qtof/qtoftest/blank-pos.pdf"
    blank_neg = "zhongyao_qtof/qtoftest/blank-neg.pdf"
    sample_pos = None  # "zhongyao_qtof/qtoftest/sample-pos.pdf"
    sample_neg = "zhongyao_qtof/qtoftest/20250913105942-z00101-E-8-1_Analysis.pdf"
    
    # 创建分析器并解析所有PDF
    analyzer = BlankRemovalAnalyzer(
        blank_pos_path=blank_pos, 
        blank_neg_path=blank_neg, 
        sample_pos_path=sample_pos, 
        sample_neg_path=sample_neg
    )
    
    # 解析所有PDF文件
    collected_data = analyzer.parse_all_pdfs()
    
    # 提取空白样品干扰物质
    interferences = analyzer.extract_blank_interferences()
    
    # 打印干扰物质摘要
    analyzer.print_interference_summary(interferences)
    
    # 保存干扰物质提取结果
    analyzer.save_interference_results(
        interferences, 
        output_dir="zhongyao_qtof/qtoftest",
        prefix="blank_interference"
    )
    
    print("\n干扰物质提取完成!")
    
    # 分析样品峰信息
    sample_analysis = analyzer.analyze_sample_peaks()
    
    # 打印样品峰分析结果
    analyzer.print_sample_analysis(sample_analysis)
    
    # 保存样品峰分析结果
    analyzer.save_sample_analysis(
        sample_analysis,
        output_dir="zhongyao_qtof/qtoftest",
        prefix="sample_analysis"
    )
    
    print("\n样品峰分析完成!")
    
    # 对样品峰进行干扰物标注
    annotated_analysis = analyzer.annotate_interferences(sample_analysis, interferences)
    
    # 打印标注后的分析结果
    analyzer.print_annotated_analysis(annotated_analysis)
    
    # 保存标注后的分析结果
    analyzer.save_annotated_analysis(
        annotated_analysis,
        output_dir="zhongyao_qtof/qtoftest",
        prefix="annotated_sample"
    )
    
    print("\n干扰物标注完成!")


if __name__ == "__main__":
    main()

