#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中药QTOF PDF报告解析器
使用PyMuPDF (fitz) 库提取PDF中的文本和表格信息
"""

import fitz  # PyMuPDF
import pandas as pd
import re
import os
import logging
from typing import List, Dict, Tuple, Any


class PDFParser:
    """PDF报告解析器类"""
    
    def __init__(self, pdf_path: str):
        """
        初始化PDF解析器
        
        Args:
            pdf_path (str): PDF文件路径
        """
        self.pdf_path = pdf_path
        self.doc = None
        self.text_content = []
        self.text_content_by_page = []  # 按页保存文本内容，用于跨页分析
        self.allocated_mz_markers = {}  # 记录已分配的m/z标记 {page_num: set(marker_indices)}  # 使用set提升查询性能
        self.peak_marker_cache = {}  # 记录每个Peak已分配的标记 {(page_num, peak_num): marker_info}
        
        # 简单缓存机制 - 只缓存最常用的操作
        self._page_text_cache = {}      # 缓存页面文本
        self._page_drawings_cache = {}  # 缓存页面绘图
        
        # Peak位置索引 - 避免重复遍历所有页面
        self._peak_index = {}           # {(peak_num, ion_mode): {'page': page_num, 'line_idx': line_idx, 'line_text': text}}
        self._peak_index_built = False  # 标记索引是否已构建
        
        # 文本位置索引 - 避免重复调用page.search_for()
        self._text_position_index = {}  # {'counts_vs_mz': [{page, x0, y0, x1, y1, text}, ...]}
        self._text_position_index_built = False  # 标记索引是否已构建
        
        # 预编译正则表达式 - 避免重复编译
        self._compiled_patterns = {
            'peak_base': re.compile(r'Peak\s+(\d+)\s+from\s+([\+\-])\s+BPC Scan'),  # 匹配任意Peak
            'single_number': re.compile(r'^\d+(?:\.\d+)?$'),
            'multi_number': re.compile(r'\d+(?:\.\d+)?'),
            'numeric_value': re.compile(r'\d+\.?\d*')
        }
        
        # 配置日志系统
        self.logger = logging.getLogger(f"PDFParser.{os.path.basename(pdf_path)}")
        if not self.logger.handlers:  # 避免重复添加handler
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(levelname)s: %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)  # 默认INFO级别
    
    def set_log_level(self, level: str = 'INFO'):
        """
        设置日志级别
        
        Args:
            level: 日志级别 ('DEBUG', 'INFO', 'WARNING', 'ERROR')
        """
        level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR
        }
        self.logger.setLevel(level_map.get(level.upper(), logging.INFO))
    
    def _get_page_text_cached(self, page_num: int) -> str:
        """缓存版本的页面文本获取"""
        if page_num in self._page_text_cache:
            return self._page_text_cache[page_num]
        
        if not self.doc or page_num >= len(self.doc):
            return ""
        
        page = self.doc[page_num]
        page_text = page.get_text()
        self._page_text_cache[page_num] = page_text
        return page_text
    
    def _get_page_drawings_cached(self, page_num: int):
        """缓存版本的页面绘图获取"""
        if page_num in self._page_drawings_cache:
            return self._page_drawings_cache[page_num]
        
        if not self.doc or page_num >= len(self.doc):
            return []
        
        page = self.doc[page_num]
        drawings = page.get_drawings()
        self._page_drawings_cache[page_num] = drawings
        return drawings

    def open_pdf(self) -> bool:
        """
        打开PDF文件
        
        Returns:
            bool: 是否成功打开
        """
        try:
            self.doc = fitz.open(self.pdf_path)
            self.logger.info(f"成功打开PDF文件: {self.pdf_path}")
            self.logger.info(f"PDF页数: {len(self.doc)}")
            return True
        except Exception as e:
            self.logger.error(f"打开PDF文件失败: {e}")
            return False
    
    def extract_text(self) -> str:
        """
        提取PDF中的所有文本内容
        
        Returns:
            List[str]: 每页的文本内容列表
        """
        if not self.doc:
            print("PDF文件未打开")
            return []
        
        # 按页提取文本，保存页面边界信息
        page_texts = []
        all_lines = []
        
        for page_num, page in enumerate(self.doc):
            page_text = page.get_text()
            page_lines = page_text.split('\n')
            
            # 过滤页面文本，删除页码相关信息
            filtered_page_lines = []
            i = 0
            while i < len(page_lines):
                if page_lines[i].find('MassHunter Qualitative Analysis') >= 0:
                    i += 4
                    if i >= len(page_lines):
                        break
                    else:
                        continue
                filtered_page_lines.append(page_lines[i].strip())
                i += 1
            
            page_texts.append({
                'page_num': page_num + 1,
                'lines': filtered_page_lines
            })
            
            # 添加到总的文本列表中
            all_lines.extend(filtered_page_lines)
        
        self.text_content_by_page = page_texts
        self.text_content = all_lines
        
        # 提取文本后，立即构建索引
        self._build_peak_index()          # Peak位置索引
        self._build_text_position_index() # 文本位置索引（优化search_for()调用）
        
        return self.text_content
    
    def _build_text_position_index(self):
        """
        构建文本位置索引，一次性获取所有关键文本的位置信息
        使用page.get_text("dict")获取带位置的文本，避免后续重复调用page.search_for()
        
        索引结构: {
            'counts_vs_mz': [{'page': page_num, 'x0': x, 'y0': y, 'x1': x, 'y1': y, 'text': text}, ...]
        }
        """
        if self._text_position_index_built:
            return
        
        if not self.doc:
            return
        
        self.logger.debug("开始构建文本位置索引...")
        start_time = __import__('time').time()
        
        # 初始化索引
        self._text_position_index = {
            'counts_vs_mz': []  # 存储所有"Counts vs. Mass-to-Charge"的位置
        }
        
        counts_found = 0
        
        # 遍历所有页面
        for page_num in range(len(self.doc)):
            page = self.doc[page_num]
            
            try:
                # 使用page.get_text("dict")一次性获取页面的所有文本及其位置
                text_dict = page.get_text("dict")
                
                # 遍历所有文本块
                for block in text_dict.get('blocks', []):
                    if block.get('type') == 0:  # 文本块
                        for line in block.get('lines', []):
                            # 拼接该行的所有span文本
                            line_text = ""
                            for span in line.get('spans', []):
                                line_text += span.get('text', '')
                            
                            # 检查是否包含"Counts vs. Mass-to-Charge"
                            if "Counts vs. Mass-to-Charge" in line_text:
                                bbox = line.get('bbox', [0, 0, 0, 0])
                                self._text_position_index['counts_vs_mz'].append({
                                    'page': page_num,
                                    'x0': bbox[0],
                                    'y0': bbox[1],
                                    'x1': bbox[2],
                                    'y1': bbox[3],
                                    'text': line_text.strip()
                                })
                                counts_found += 1
            
            except Exception as e:
                self.logger.warning(f"构建文本索引时处理第{page_num + 1}页失败: {e}")
                continue
        
        self._text_position_index_built = True
        elapsed = __import__('time').time() - start_time
        
        self.logger.info(f"文本位置索引构建完成: 用时{elapsed:.3f}秒")
        self.logger.info(f"  找到 {counts_found} 个'Counts vs. Mass-to-Charge'标记")
        
        # 按页面分组统计
        if self._text_position_index['counts_vs_mz']:
            pages_with_counts = set(item['page'] for item in self._text_position_index['counts_vs_mz'])
            self.logger.info(f"  分布在 {len(pages_with_counts)} 个页面上")
            
            # 显示前3个位置（仅DEBUG模式）
            if self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug("  前3个'Counts vs. Mass-to-Charge'位置:")
                for i, item in enumerate(self._text_position_index['counts_vs_mz'][:3]):
                    self.logger.debug(f"    {i+1}. 第{item['page']+1}页, y={item['y0']:.2f}")
    
    def _build_peak_index(self):
        """
        构建Peak位置索引，遍历所有页面一次，记录所有Peak的位置
        索引结构: {(peak_num, ion_mode): {'page': page_num, 'line_idx': line_idx, 'line_text': text}}
        """
        if self._peak_index_built:
            return
        
        if not self.text_content_by_page:
            return
        
        self.logger.debug("开始构建Peak位置索引...")
        
        # 使用预编译的正则表达式匹配Peak标识
        peak_pattern = self._compiled_patterns['peak_base']
        
        peak_count = 0
        
        # 遍历所有页面
        for page_info in self.text_content_by_page:
            page_num = page_info['page_num']
            page_lines = page_info['lines']
            
            # 遍历当前页面的所有行
            for line_idx, line in enumerate(page_lines):
                line = line.strip()
                
                # 尝试匹配Peak标识
                match = peak_pattern.search(line)
                if match:
                    peak_num = int(match.group(1))
                    ion_sign = match.group(2)
                    ion_mode = 'positive' if ion_sign == '+' else 'negative'
                    
                    # 建立索引
                    index_key = (peak_num, ion_mode)
                    self._peak_index[index_key] = {
                        'page': page_num,
                        'line_idx': line_idx,
                        'line_text': line,
                        'ion_sign': ion_sign
                    }
                    
                    peak_count += 1
        
        self._peak_index_built = True
        self.logger.info(f"Peak位置索引构建完成: 找到 {peak_count} 个Peak标识")
        
        # 打印索引统计信息
        if self._peak_index:
            positive_peaks = sum(1 for k in self._peak_index.keys() if k[1] == 'positive')
            negative_peaks = sum(1 for k in self._peak_index.keys() if k[1] == 'negative')
            self.logger.info(f"  正离子模式Peak: {positive_peaks} 个")
            self.logger.info(f"  负离子模式Peak: {negative_peaks} 个")
            
            # 显示前5个Peak的位置（仅DEBUG模式）
            if self.logger.isEnabledFor(logging.DEBUG):
                sorted_peaks = sorted(self._peak_index.items(), key=lambda x: (x[0][0], x[0][1]))
                self.logger.debug("  前5个Peak位置:")
                for (peak_num, ion_mode), info in sorted_peaks[:5]:
                    self.logger.debug(f"    Peak {peak_num} ({ion_mode}): 第{info['page']}页, 第{info['line_idx']+1}行")

    def extract_key_info(self) -> Dict[str, Any]:
        """
        提取关键信息，包括BPC和DAD的色谱峰表格信息
        支持跨页表格的合并处理
        新模板：1个BPC峰 + 2个DAD峰（210nm和254nm）
        """
        key_info = {"BPC_Peaks": None, "DAD_Peaks_210nm": None, "DAD_Peaks_254nm": None, "ESI_Info": None}
        chromatogram_count = 0
        i = 0
        
        # 用于存储当前正在处理的表格数据
        current_table_data = []
        current_table_type = None  # 'BPC', 'DAD_210nm' 或 'DAD_254nm'
        
        while i < len(self.text_content):
            if self.text_content[i].find('Textbox50') >= 0:
                print(f"发现Textbox50标题")
                
                # 检查是否是跨页延续的表格
                is_continuation = False
                if current_table_data and chromatogram_count > 0:
                    # 检查接下来的Peak编号是否与当前表格的最后一个Peak编号连续
                    is_continuation = self._check_peak_continuation(i + 9, current_table_data)
                    if is_continuation:
                        print(f"检测到跨页表格延续，Peak编号连续")
                    else:
                        print(f"检测到新的表格开始，Peak编号不连续")
                
                if not is_continuation:
                    # 新表格开始
                    # 如果之前有未完成的表格数据，先保存
                    if current_table_data:
                        self._save_table_data(key_info, current_table_data, current_table_type, chromatogram_count - 1)
                    
                    # 重置当前表格数据
                    current_table_data = []
                    # 根据表格顺序确定类型：第1个是BPC，第2个是DAD_210nm，第3个是DAD_254nm
                    if chromatogram_count == 0:
                        current_table_type = 'BPC'
                    elif chromatogram_count == 1:
                        current_table_type = 'DAD_210nm'
                    else:
                        current_table_type = 'DAD_254nm'
                    print(f"开始处理第{chromatogram_count + 1}个表格 ({current_table_type})")
                else:
                    print(f"继续处理跨页表格 ({current_table_type})")
                
                # 跳过标题行（Textbox50 + 表格标题行 + 7个字段名行，共9行）
                i += 9
                
                # 提取表格数据
                while i < len(self.text_content):
                    # 检查是否遇到了新的Textbox50标题（跨页情况）
                    if i < len(self.text_content) and self.text_content[i].find('Textbox50') >= 0:
                        print(f"检测到跨页表格延续，当前已有{len(current_table_data)}行数据")
                        break
                    
                    # 尝试读取连续的8行作为一个数据记录
                    if i + 7 >= len(self.text_content):
                        break
                    
                    # 获取连续8行的数据
                    eight_lines = []
                    valid_data = True
                    
                    for j in range(8):
                        line = self.text_content[i + j].strip()
                        if not line:
                            valid_data = False
                            break
                        eight_lines.append(line)
                    
                    if not valid_data:
                        break
                    
                    # 尝试将这8行数据转换为数值
                    try:
                        peak_data = []
                        for j, line in enumerate(eight_lines):
                            # 尝试转换为数字
                            try:
                                if '.' in line:
                                    peak_data.append(float(line))
                                else:
                                    # 对于第一个字段(Peak)，可能是整数
                                    peak_data.append(int(line))
                            except ValueError:
                                # 如果不能转换为数字，检查是否是有效的数据格式
                                if j == 0:  # Peak字段可能是字符串
                                    peak_data.append(line)
                                else:
                                    # 其他字段如果不是数字，可能表格结束了
                                    valid_data = False
                                    break
                        
                        if valid_data and len(peak_data) == 8:
                            current_table_data.append(peak_data)
                            # print(f"提取数据记录: {peak_data}")
                            i += 8  # 跳过已处理的8行
                        else:
                            # 数据无效，表格可能结束
                            # print(f"数据无效，表格结束。当前8行数据: {eight_lines}")
                            break
                            
                    except Exception as e:
                        print(f"解析数据记录失败，表格结束: {eight_lines}, 错误: {e}")
                        break
                
                # 如果不是跨页延续，增加表格计数
                if not is_continuation:
                    chromatogram_count += 1
                
                # 如果已经找到三个表格，可以结束搜索
                if chromatogram_count >= 3 and not self._has_more_chromatogram_peaks(i):
                    break
            else:
                i += 1
        
        # 保存最后一个表格的数据
        if current_table_data:
            table_index = chromatogram_count - 1 if chromatogram_count > 0 else 0
            self._save_table_data(key_info, current_table_data, current_table_type, table_index)
        
        print(f"总共找到 {chromatogram_count} 个Textbox50表格")
        
        # 继续提取ESI信息
        print("\n开始提取ESI信息...")
        esi_info = self._extract_esi_info(i)
        key_info["ESI_Info"] = esi_info
        
        return key_info
    
    def _save_table_data(self, key_info: Dict[str, Any], table_data: list, table_type: str, table_index: int):
        """
        保存表格数据到key_info中
        
        Args:
            key_info: 存储结果的字典
            table_data: 表格数据列表
            table_type: 表格类型 ('BPC', 'DAD_210nm' 或 'DAD_254nm')
            table_index: 表格索引
        """
        if table_data:
            columns = ['Peak', 'Start', 'RT', 'End', 'Height', 'Area', 'Area_Percent', 'Area_Sum']
            df = pd.DataFrame(table_data, columns=columns)
            
            if table_index == 0:
                key_info["BPC_Peaks"] = df
                print(f"BPC_Peaks表格数据 (共{len(table_data)}行):")
                print(df.to_string(index=False))
            elif table_index == 1:
                key_info["DAD_Peaks_210nm"] = df
                print(f"DAD_Peaks_210nm表格数据 (共{len(table_data)}行):")
                print(df.to_string(index=False))
            elif table_index == 2:
                key_info["DAD_Peaks_254nm"] = df
                print(f"DAD_Peaks_254nm表格数据 (共{len(table_data)}行):")
                print(df.to_string(index=False))
    
    def _has_more_chromatogram_peaks(self, start_index: int) -> bool:
        """
        检查从指定位置开始是否还有更多的Textbox50标题
        
        Args:
            start_index: 开始搜索的索引位置
            
        Returns:
            bool: 如果还有更多的Textbox50返回True，否则返回False
        """
        for i in range(start_index, len(self.text_content)):
            if self.text_content[i].find('Textbox50') >= 0:
                return True
        return False
    
    def _check_peak_continuation(self, start_index: int, current_table_data: list) -> bool:
        """
        检查Peak编号是否连续，判断是否是跨页表格的延续
        
        Args:
            start_index: 开始检查的索引位置（应该是第一个数据行）
            current_table_data: 当前表格已有的数据
            
        Returns:
            bool: 如果Peak编号连续返回True，否则返回False
        """
        if not current_table_data:
            return False
        
        # 获取当前表格最后一个Peak的编号
        try:
            last_peak = current_table_data[-1][0]  # Peak字段是第一个字段
            if isinstance(last_peak, str):
                last_peak_num = int(last_peak)
            else:
                last_peak_num = int(last_peak)
        except (ValueError, IndexError):
            print(f"无法获取最后一个Peak编号: {current_table_data[-1] if current_table_data else 'None'}")
            return False
        
        # 检查接下来的第一个Peak编号
        try:
            if start_index < len(self.text_content):
                next_peak_str = self.text_content[start_index].strip()
                try:
                    next_peak_num = int(next_peak_str)
                    # 检查是否连续（下一个Peak编号应该是当前最后一个+1）
                    is_continuous = (next_peak_num == last_peak_num + 1)
                    print(f"Peak编号检查: 当前最后={last_peak_num}, 下一个={next_peak_num}, 连续={is_continuous}")
                    return is_continuous
                except ValueError:
                    print(f"无法解析下一个Peak编号: {next_peak_str}")
                    return False
        except IndexError:
            print(f"索引超出范围: {start_index}")
            return False
        
        return False
    
    def _extract_esi_info(self, start_index: int) -> pd.DataFrame:
        """
        提取ESI质谱信息，包括基本信息和质谱棒图详细信息
        
        Args:
            start_index (int): 开始搜索的索引位置
            
        Returns:
            pd.DataFrame: ESI信息的DataFrame，包含质谱棒图信息
        """
        esi_data = []
        i = start_index
        
        # 寻找Sample Spectra
        while i < len(self.text_content):
            if 'Sample Spectra' in self.text_content[i]:
                # print(f"找到Sample Spectra位置: 第{i+1}行")
                i += 1
                break
            i += 1
        
        if i >= len(self.text_content):
            print("未找到Sample Spectra")
            return pd.DataFrame()
        
        # 开始提取每个峰的信息
        current_peak = {}
        processed_peaks = set()  # 记录已处理的Peak编号，避免重复
        
        while i < len(self.text_content):
            line = self.text_content[i].strip()
            
            # 提取Peak编号和离子类型
            if 'Peak' in line and 'BPC Scan' in line:
                try:
                    # 提取Peak后的数字
                    peak_match = re.search(r'Peak\s+(\d+)', line)
                    if peak_match:
                        peak_num = int(peak_match.group(1))
                        current_peak['Peak'] = peak_num
                        # print(f"提取Peak编号: {peak_num}")
                    
                    # 提取离子类型（+ 或 -）
                    if 'from +' in line or 'from+' in line:
                        current_peak['IonMode'] = 'positive'
                    elif 'from -' in line or 'from-' in line:
                        current_peak['IonMode'] = 'negative'
                    else:
                        current_peak['IonMode'] = 'positive'  # 默认为positive
                except Exception as e:
                    print(f"提取Peak编号失败: {e}")
            
            # 提取RT信息（在Peak编号之后）
            elif 'ESI Scan (rt:' in line and 'min' in line and 'Frag' in line and 'Peak' in current_peak:
                try:
                    # 提取括号中min前面的RT信息
                    rt_match = re.search(r'ESI Scan \(rt:\s*([^)]*?)\s*min', line)
                    if rt_match:
                        rt_info = rt_match.group(1).strip()
                        current_peak['RT'] = rt_info
                        # print(f"提取RT信息: {rt_info}")
                except Exception as e:
                    print(f"提取RT信息失败: {e}")
            
            # 寻找Ion Type标记
            elif 'Ion Type' in line:
                # print(f"找到Ion Type标记，准备提取m/z和Abund信息")
                
                # 接下来两行分别是m/z和Abund信息
                if i + 2 < len(self.text_content):
                    try:
                        # 下一行是m/z信息
                        mz_line = self.text_content[i + 1].strip()
                        # 再下一行是Abund信息
                        abund_line = self.text_content[i + 2].strip()
                        
                        # 尝试提取数值
                        mz_value = self._extract_numeric_value(mz_line)
                        abund_value = self._extract_numeric_value(abund_line)
                        
                        if mz_value is not None:
                            current_peak['mz'] = mz_value
                        
                        if abund_value is not None:
                            current_peak['Abund'] = abund_value
                        
                        # 如果当前峰信息完整，提取质谱棒图信息
                        if len(current_peak) >= 3 and 'Peak' in current_peak:
                            peak_num = current_peak['Peak']
                            
                            # 避免重复处理同一个Peak
                            if peak_num not in processed_peaks:
                                ion_mode = current_peak.get('IonMode', 'positive')
                                print(f"\n开始提取Peak {peak_num}的质谱棒图信息 (离子模式: {ion_mode})...")
                                
                                # 提取质谱棒图信息
                                spectrum_bars = self._extract_mass_spectrum_bars(peak_num, ion_mode)
                                
                                if spectrum_bars:
                                    print(f"Peak {peak_num}提取到{len(spectrum_bars)}条质谱棒图数据")
                                    
                                    # 将基本信息和质谱棒图信息结合
                                    for bar_data in spectrum_bars:
                                        combined_data = current_peak.copy()
                                        combined_data.update({
                                            'spectrum_mz': bar_data['mz'],
                                            'spectrum_intensity': bar_data['intensity'],
                                            'bar_x_coord': bar_data['x_coord'],
                                            'bar_length': bar_data['length'],
                                            'bar_page': bar_data['page'],
                                            # 添加线性插值参数
                                            'min_mz': bar_data.get('min_mz'),
                                            'max_mz': bar_data.get('max_mz'),
                                            'min_scale_x': bar_data.get('min_scale_x'),
                                            'max_scale_x': bar_data.get('max_scale_x')
                                        })
                                        esi_data.append(combined_data)
                                    
                                    processed_peaks.add(peak_num)
                                else:
                                    # 如果没有找到质谱棒图，保存基本信息
                                    print(f"Peak {peak_num}未找到质谱棒图数据，保存基本信息")
                                    esi_data.append(current_peak.copy())
                                    processed_peaks.add(peak_num)
                            
                            current_peak = {}
                        
                        i += 2  # 跳过已处理的两行
                        
                    except Exception as e:
                        print(f"提取m/z和Abund信息失败: {e}")
            
            i += 1
        
        # 处理最后一个峰（如果存在）
        if current_peak and len(current_peak) >= 3 and 'Peak' in current_peak:
            peak_num = current_peak['Peak']
            if peak_num not in processed_peaks:
                ion_mode = current_peak.get('IonMode', 'positive')
                print(f"\n处理最后一个Peak {peak_num} (离子模式: {ion_mode})...")
                spectrum_bars = self._extract_mass_spectrum_bars(peak_num, ion_mode)
                
                if spectrum_bars:
                    for bar_data in spectrum_bars:
                        combined_data = current_peak.copy()
                        combined_data.update({
                            'spectrum_mz': bar_data['mz'],
                            'spectrum_intensity': bar_data['intensity'],
                            'bar_x_coord': bar_data['x_coord'],
                            'bar_length': bar_data['length'],
                            'bar_page': bar_data['page'],
                            # 添加线性插值参数
                            'min_mz': bar_data.get('min_mz'),
                            'max_mz': bar_data.get('max_mz'),
                            'min_scale_x': bar_data.get('min_scale_x'),
                            'max_scale_x': bar_data.get('max_scale_x')
                        })
                        esi_data.append(combined_data)
                else:
                    esi_data.append(current_peak.copy())
        
        # 转换为DataFrame
        if esi_data:
            df = pd.DataFrame(esi_data)
            
            # 确保列的顺序
            basic_columns = ['Peak', 'RT', 'mz', 'Abund']
            spectrum_columns = ['spectrum_mz', 'spectrum_intensity', 'bar_x_coord', 'bar_length', 'bar_page']
            interpolation_columns = ['min_mz', 'max_mz', 'min_scale_x', 'max_scale_x']
            
            # 只保留存在的列
            all_columns = basic_columns + spectrum_columns + interpolation_columns
            existing_columns = [col for col in all_columns if col in df.columns]
            df = df[existing_columns]
            
            print(f"\nESI信息提取完成，共{len(df)}条记录（包含质谱棒图信息）")
            
            # 显示统计信息
            unique_peaks = df['Peak'].nunique() if 'Peak' in df.columns else 0
            has_spectrum_data = 'spectrum_mz' in df.columns and df['spectrum_mz'].notna().sum() > 0
            
            print(f"包含{unique_peaks}个不同的Peak")
            if has_spectrum_data:
                spectrum_count = df['spectrum_mz'].notna().sum()
                print(f"其中{spectrum_count}条记录包含质谱棒图详细信息")
            
            return df
        else:
            print("未提取到ESI信息")
            return pd.DataFrame()
    
    def _extract_numeric_value(self, line: str) -> float:
        """
        从文本行中提取数值
        
        Args:
            line (str): 文本行
            
        Returns:
            float: 提取的数值，如果提取失败返回None
        """
        try:
            # 使用预编译的正则表达式提取数字（包括小数）
            numbers = self._compiled_patterns['numeric_value'].findall(line)
            if numbers:
                # 返回第一个找到的数字
                return float(numbers[0])
        except Exception as e:
            print(f"提取数值失败: {line}, 错误: {e}")
        return None
    
    
    def _find_counts_vs_mass_position_for_peak(self, page_num: int, peak_num: int, is_cross_page: bool = False) -> Dict[str, float]:
        """
        为指定Peak查找对应的"Counts vs. Mass-to-Charge"文本位置，支持全局标记分配
        【优化】使用预建立的文本位置索引，避免调用page.search_for()
        
        Args:
            page_num (int): 页面编号（m/z标记所在页面）
            peak_num (int): Peak编号
            is_cross_page (bool): 是否为跨页情况
            
        Returns:
            Dict[str, float]: 包含文本位置信息的字典，包括x, y坐标
        """
        if not self.doc or page_num >= len(self.doc):
            return None
        
        # 检查缓存，如果该Peak已经分配过标记，直接返回
        cache_key = (page_num, peak_num)
        if cache_key in self.peak_marker_cache:
            cached_result = self.peak_marker_cache[cache_key]
            return cached_result
        
        # 【优化】从索引中获取该页面的所有"Counts vs. Mass-to-Charge"位置
        # 避免调用page.search_for()，节省大量时间
        counts_on_page = [
            item for item in self._text_position_index.get('counts_vs_mz', [])
            if item['page'] == page_num
        ]
        
        if not counts_on_page:
            print(f"  未找到任何'Counts vs. Mass-to-Charge'标记")
            return None
        
        print(f"  找到{len(counts_on_page)}个'Counts vs. Mass-to-Charge'标记")
        
        # 初始化页面的已分配标记记录（使用set提升查询性能）
        if page_num not in self.allocated_mz_markers:
            self.allocated_mz_markers[page_num] = set()
        
        # 按y坐标排序所有"Counts vs. Mass-to-Charge"标记
        sorted_counts = sorted(enumerate(counts_on_page), key=lambda x: x[1]['y0'])
        
        best_match = None
        best_index = None
        
        if is_cross_page:
            # 跨页情况：选择第一个未分配的标记（通常在页面顶部）
            print(f"  Peak {peak_num}为跨页情况，在第{page_num + 1}页查找m/z标记")
            
            for i, (original_index, counts_item) in enumerate(sorted_counts):
                if original_index not in self.allocated_mz_markers[page_num]:
                    best_match = counts_item
                    best_index = original_index
                    print(f"  Peak {peak_num}跨页情况，选择第{i + 1}个未分配标记")
                    break
        
        else:
            # 同页情况：根据Peak在页面中的相对位置选择标记
            # 【优化】使用_peak_index获取Peak位置，避免search_for()
            # 尝试两种离子模式
            ion_mode = 'positive'
            index_key = (peak_num, ion_mode)
            if index_key not in self._peak_index:
                ion_mode = 'negative'
                index_key = (peak_num, ion_mode)
            
            if index_key not in self._peak_index:
                print(f"  在第{page_num + 1}页未找到Peak {peak_num}标识")
                return None
            
            peak_info = self._peak_index[index_key]
            # 注意：_peak_index中的page是1-based，需要转换为0-based
            if peak_info['page'] - 1 != page_num:
                print(f"  Peak {peak_num}不在第{page_num + 1}页")
                return None
            
            # 从_peak_index获取该页面Peak标识的y坐标（估算）
            # 由于_peak_index只存储了行索引，我们需要另一种方法获取y坐标
            # 使用_text_position_index会更准确，但为了兼容性，这里使用简化方法
            peak_y = None
            ion_sign = peak_info['ion_sign']
            
            # 获取页面中所有Peak的位置（使用_peak_index）
            all_peak_positions = []
            for (p, mode), info in self._peak_index.items():
                if info['page'] == page_num + 1 and info['ion_sign'] == ion_sign:
                    # 使用行号作为y坐标的替代（简化处理）
                    # 注意：这里没有精确的像素坐标，但对于相对位置判断够用
                    all_peak_positions.append((p, info['line_idx']))
            
            # 按y坐标排序所有Peak位置
            all_peak_positions.sort(key=lambda x: x[1])
            
            # 找到当前peak在页面中的位置
            current_peak_index = None
            for i, (p, y) in enumerate(all_peak_positions):
                if p == peak_num:
                    current_peak_index = i
                    break
            
            if current_peak_index is not None:
                print(f"  Peak {peak_num}在页面第{current_peak_index + 1}个位置")
                
                # 找到所有未分配的标记
                # 注意：由于使用文本位置索引，所有标记都已按y坐标排序
                available_markers = []
                for original_index, counts_item in sorted_counts:
                    if original_index not in self.allocated_mz_markers[page_num]:
                        available_markers.append((original_index, counts_item))
                
                print(f"  Peak {peak_num}找到{len(available_markers)}个可用标记")
                
                # 简单策略：选择第一个可用标记
                if available_markers:
                    best_index, best_match = available_markers[0]
                    print(f"  Peak {peak_num}选择第1个可用标记")
                else:
                    print(f"  Peak {peak_num}没有找到可用的m/z标记")
                    return None
            else:
                print(f"  无法确定Peak {peak_num}在页面中的相对位置")
                return None
        
        if best_match and best_index is not None:
            # 标记该标记为已分配（使用set的add方法）
            self.allocated_mz_markers[page_num].add(best_index)
            
            self.logger.debug(f"  为Peak {peak_num}选择'Counts vs. Mass-to-Charge'标记，y={best_match['y0']:.4g}")
            self.logger.debug(f"  页面{page_num + 1}已分配标记: {sorted(self.allocated_mz_markers[page_num])}")
            
            # 创建结果并保存到缓存
            result = {
                'x0': best_match['x0'], 'y0': best_match['y0'],
                'x1': best_match['x1'], 'y1': best_match['y1'],
                'page': page_num,
                'peak_num': peak_num
            }
            
            # 保存到缓存，避免重复分配
            cache_key = (page_num, peak_num)
            self.peak_marker_cache[cache_key] = result
            
            return result
        
        print(f"  未找到合适的'Counts vs. Mass-to-Charge'标记")
        return None
    
    
    def _extract_peak_specific_vertical_lines(self, peak_num: int, page_num: int, chart_boundaries: Dict) -> List[Dict]:
        """
        为指定Peak提取专属的垂直线条（质谱棒），确保底部纵坐标一致
        
        Args:
            peak_num (int): Peak编号
            page_num (int): 页面编号
            chart_boundaries (Dict): 图表边界信息
            
        Returns:
            List[Dict]: 该Peak专属的垂直线条列表，底部纵坐标一致
        """
        if not self.doc or page_num >= len(self.doc):
            return []
        
        page = self.doc[page_num]
        drawings = self._get_page_drawings_cached(page_num)
        
        # 获取Peak专属边界
        peak_boundaries = self._get_peak_specific_boundaries(peak_num, page_num, chart_boundaries)
        
        lower_y = peak_boundaries.get('lower_y', chart_boundaries['lower_y'])
        upper_y = peak_boundaries.get('upper_y', chart_boundaries['upper_y'])
        
        print(f"  Peak {peak_num}专属区域: y={upper_y:.4g} 到 y={lower_y:.4g}")
        
        # 收集所有候选垂直线条
        candidate_lines = []
        
        for drawing in drawings:
            for item in drawing['items']:
                if item[0] == 'l':  # 线条
                    if len(item) >= 3:
                        point1, point2 = item[1], item[2]
                        x0, y0 = point1.x, point1.y
                        x1, y1 = point2.x, point2.y
                        
                        # 判断是否为垂直线条
                        if abs(x0 - x1) <= 0.5:  # 容忍0.5个像素的误差
                            line_top = min(y0, y1)
                            line_bottom = max(y0, y1)
                            
                            # 检查线条是否在Peak的专属区域内
                            if (line_top <= lower_y and line_bottom >= upper_y):
                                # 计算有效长度
                                effective_top = max(line_top, upper_y)
                                effective_bottom = min(line_bottom, lower_y)
                                effective_length = effective_bottom - effective_top
                                
                                if effective_length > 1:  # 长度阈值
                                    candidate_lines.append({
                                        'x': (x0 + x1) / 2,
                                        'y_top': effective_top,
                                        'y_bottom': effective_bottom,
                                        'length': effective_length,
                                        'original_coords': (x0, y0, x1, y1),
                                        'page': page_num,
                                        'peak_num': peak_num
                                    })
        
        if not candidate_lines:
            return []
        
        # 分析底部纵坐标的分布，找出最常见的底部坐标
        bottom_coords = [line['y_bottom'] for line in candidate_lines]
        
        # 使用聚类方法找出最常见的底部坐标
        bottom_clusters = self._cluster_coordinates(bottom_coords, tolerance=2.0)
        
        if not bottom_clusters:
            return candidate_lines  # 如果无法聚类，返回所有候选
        
        # 选择最大的聚类（包含最多线条的底部坐标）
        main_cluster = max(bottom_clusters, key=len)
        main_bottom_y = sum(main_cluster) / len(main_cluster)
        
        print(f"  Peak {peak_num}主要底部坐标: y={main_bottom_y:.4g} (来自{len(main_cluster)}条线)")
        
        # 筛选出底部坐标接近主要坐标的线条
        peak_lines = []
        for line in candidate_lines:
            if abs(line['y_bottom'] - main_bottom_y) <= 2.0:  # 2像素容忍度
                peak_lines.append(line)
        
        print(f"  筛选出{len(peak_lines)}条底部坐标一致的质谱棒")
        
        return peak_lines
    
    def _cluster_coordinates(self, coordinates: List[float], tolerance: float = 2.0) -> List[List[float]]:
        """
        对坐标进行简单聚类，将相近的坐标归为一类
        
        Args:
            coordinates (List[float]): 坐标列表
            tolerance (float): 聚类容忍度
            
        Returns:
            List[List[float]]: 聚类结果，每个子列表是一个聚类
        """
        if not coordinates:
            return []
        
        sorted_coords = sorted([coord for coord in coordinates])
        clusters = []
        current_cluster = [sorted_coords[0]]
        
        for coord in sorted_coords[1:]:
            if coord - current_cluster[-1] <= tolerance:
                current_cluster.append(coord)
            else:
                clusters.append(current_cluster)
                current_cluster = [coord]
        
        clusters.append(current_cluster)
        return clusters
    
    def _find_chart_boundaries(self, page_num: int, counts_position: Dict) -> Dict[str, float]:
        """
        根据"Counts vs. Mass-to-Charge"位置找到图表边界
        使用PyMuPDF的rect信息来直接定位可能的图表边界矩形
        
        Args:
            page_num (int): 页面编号
            counts_position (Dict): "Counts vs. Mass-to-Charge"文本位置
            
        Returns:
            Dict[str, float]: 图表边界信息，包含lower_y和upper_y
        """
        if not self.doc or page_num >= len(self.doc):
            return None
        
        page = self.doc[page_num]
        page_rect = page.rect
        page_width = page_rect.width
        
        # 以"Counts vs. Mass-to-Charge"的y坐标为基准
        base_y = counts_position['y0']
        
        print(f"页面{page_num + 1}: 基准位置y={base_y:.4g}")
        
        # 方法1: 尝试从绘图元素的rect信息中找到合适的边界
        drawings = self._get_page_drawings_cached(page_num)
        candidate_rects = []
        
        for i, drawing in enumerate(drawings):
            if 'rect' in drawing:
                rect = drawing['rect']
                rect_width = rect.x1 - rect.x0
                rect_height = rect.y1 - rect.y0
                
                # 寻找可能的图表边界矩形：
                # 1. 宽度较大（大于页面宽度的30%）
                # 2. 高度合理（50-300像素）
                # 3. 包含基准点或在基准点附近
                if (rect_width > page_width * 0.3 and 
                    50 < rect_height < 300 and
                    abs(rect.y0 - base_y) < 200):  # 在基准点上下200像素范围内
                    
                    candidate_rects.append({
                        'rect': rect,
                        'width': rect_width,
                        'height': rect_height,
                        'distance_to_base': abs((rect.y0 + rect.y1) / 2 - base_y)
                    })
        
        print(f"找到{len(candidate_rects)}个候选边界矩形")
        
        if candidate_rects:
            # 选择距离基准点最近的矩形
            best_rect = min(candidate_rects, key=lambda x: x['distance_to_base'])
            rect = best_rect['rect']
            
            print(f"选择最佳矩形: 位置({rect.x0:.4g}, {rect.y0:.4g}, {rect.x1:.4g}, {rect.y1:.4g})")
            print(f"矩形尺寸: {best_rect['width']:.4g} x {best_rect['height']:.4g}")
            
            return {
                'lower_y': rect.y1,
                'upper_y': rect.y0,
                'page': page_num
            }
        
        # 方法2: 如果没有找到合适的矩形，使用简化的基于基准点的边界
        print("未找到合适的边界矩形，使用基于基准点的默认边界")
        
        # 在基准点上方寻找合适的上边界
        upper_y = base_y - 150  # 默认上边界距离基准点150像素
        lower_y = base_y + 50   # 默认下边界距离基准点50像素
        
        # 尝试通过文本块来优化边界
        try:
            blocks = page.get_text("blocks")
            for block in blocks:
                if len(block) >= 6:
                    x0, y0, x1, y1, text, block_type = block[:6]
                else:
                    # 处理不完整的block，跳过
                    continue
                # 如果找到包含数字的文本块，可能是坐标轴标签
                if block_type == 0 and any(char.isdigit() for char in text):
                    # 调整边界以包含这些文本
                    y0_dp6 = y0
                    y1_dp6 = y1
                    if y0_dp6 < base_y and y0_dp6 > base_y - 200:
                        upper_y = min(upper_y, y0_dp6 - 10)
                    elif y0_dp6 > base_y and y0_dp6 < base_y + 100:
                        lower_y = max(lower_y, y1_dp6 + 10)
        except:
            pass
        
        print(f"使用默认边界: 上边界={upper_y:.4g}, 下边界={lower_y:.4g}")
        return {
            'lower_y': upper_y,
            'upper_y': lower_y,
            'page': page_num
        }
    
    def _calculate_mz_and_intensity(self, vertical_lines: List[Dict], chart_boundaries: Dict, 
                                   page_num: int, reference_intensity: float = None, peak_num: int = None, is_cross_page: bool = False, ion_mode: str = 'positive') -> tuple[List[Dict], Dict]:
        """
        基于刻度信息和参考强度计算每个垂直线条对应的m/z值和强度值
        
        Args:
            vertical_lines (List[Dict]): 垂直线条列表（已按长度排序）
            chart_boundaries (Dict): 图表边界信息
            page_num (int): 页面编号
            reference_intensity (float): 参考强度值（最强信号的强度）
            peak_num (int): Peak编号，用于提取该Peak专用的m/z刻度
            is_cross_page (bool): 是否为跨页情况
            ion_mode (str): 离子模式，'positive' 或 'negative'，默认为 'positive'
            
        Returns:
            List[Dict]: 包含m/z和强度信息的棒图数据
        """
        if not vertical_lines or not chart_boundaries:
            return []
        
        print(f"开始计算{len(vertical_lines)}条垂直线的m/z和强度值")
        
        # 1. 提取m/z刻度信息
        if peak_num is not None:
            # 使用新的按Peak提取m/z刻度的方法
            mz_scales = self._extract_mz_scale_for_peak(peak_num, ion_mode=ion_mode)
        else:
            # 使用原有的方法（向后兼容）
            mz_scales = self._extract_mz_scale_from_page(page_num, chart_boundaries)
        
        # 2. 基于刻度计算m/z值
        lines_with_mz, interpolation_params = self._calculate_mz_from_scales(vertical_lines, mz_scales, peak_num, page_num, chart_boundaries, is_cross_page)
        
        # 3. 基于参考强度计算强度值
        if reference_intensity is not None:
            lines_with_intensity = self._calculate_intensity_from_reference(lines_with_mz, reference_intensity)
        else:
            # 如果没有参考强度，使用线条长度作为相对强度
            print("未提供参考强度，使用线条长度作为相对强度")
            lines_with_intensity = []
            for line in lines_with_mz:
                line_with_intensity = line.copy()
                line_with_intensity['calculated_intensity'] = line['length']
                line_with_intensity['height_ratio'] = 1.0
                lines_with_intensity.append(line_with_intensity)
        
        # 4. 整理结果格式
        results = []
        for line in lines_with_intensity:
            result = {
                'mz': line.get('calculated_mz', 0.0),
                'intensity': line.get('calculated_intensity', 0.0),
                'x_coord': line['x'],
                'y_top': line['y_top'],
                'y_bottom': line['y_bottom'],
                'length': line['length'],
                'height_ratio': line.get('height_ratio', 1.0),
                'page': page_num
            }
            results.append(result)
        
        print(f"完成m/z和强度计算，共{len(results)}条结果")
        
        return results, interpolation_params
    
    def _extract_mz_scale_from_page(self, page_num: int, chart_boundaries: Dict) -> List[Dict]:
        """
        从text_content中提取m/z刻度信息，基于'Counts vs. Mass-to-Charge (m/z)'后面的递增数字序列
        
        Args:
            page_num (int): 页面编号（暂时保留参数兼容性，实际从全部文本中提取）
            chart_boundaries (Dict): 图表边界信息（暂时保留参数兼容性）
            
        Returns:
            List[Dict]: m/z刻度信息列表，包含m/z值
        """
        if not hasattr(self, 'text_content') or not self.text_content:
            # 如果没有text_content，尝试重新提取
            self.text_content = self.extract_text()
        
        if not self.text_content:
            return []
        
        mz_scales = []
        found_mz_section = False
        
        # 遍历所有页面的文本内容
        for page_idx, page_text in enumerate(self.text_content):
            lines = page_text.split('\n')
            
            for line_idx, line in enumerate(lines):
                line = line.strip()
                
                # 检查是否找到了'Counts vs. Mass-to-Charge (m/z)'标记
                if 'Counts vs. Mass-to-Charge (m/z)' in line:
                    found_mz_section = True
                    print(f"在页面{page_idx + 1}找到m/z图表标记")
                    continue
                
                # 如果找到了m/z标记，开始收集后续的数字
                if found_mz_section:
                    # 检查是否为纯数字或数字序列
                    import re
                    
                    # 匹配单个数字
                    single_number_match = re.match(r'^\d+(?:\.\d+)?$', line)
                    if single_number_match:
                        mz_value = float(line)
                        mz_scales.append({
                            'mz_value': mz_value,
                            'page': page_idx + 1,
                            'line': line_idx
                        })
                        continue
                    
                    # 匹配多个空格分隔的数字
                    multi_number_match = re.findall(r'\d+(?:\.\d+)?', line)
                    if len(multi_number_match) >= 2:  # 至少2个数字
                        for num_str in multi_number_match:
                            mz_value = float(num_str)
                            mz_scales.append({
                                'mz_value': mz_value,
                                'page': page_idx + 1,
                                'line': line_idx
                            })
                        continue
                    
                    # 如果遇到非数字行且不是空行，可能已经结束m/z刻度区域
                    if line and not re.search(r'\d', line):
                        # 检查是否是其他图表标记或内容，如果是则停止当前m/z区域的收集
                        if any(keyword in line.lower() for keyword in ['spectrum', 'peak', 'counts vs']):
                            found_mz_section = False
        
        # 去重并按m/z值排序
        unique_mz_values = {}
        for scale in mz_scales:
            mz_val = scale['mz_value']
            if mz_val not in unique_mz_values:
                unique_mz_values[mz_val] = scale
        
        mz_scales = list(unique_mz_values.values())
        mz_scales.sort(key=lambda x: x['mz_value'])
        
        print(f"总共找到{len(mz_scales)}个m/z刻度值")
        if mz_scales:
            print(f"  m/z范围: {mz_scales[0]['mz_value']:.4g} - {mz_scales[-1]['mz_value']:.4g}")
        
        return mz_scales
    
    def _extract_mz_scale_for_peak(self, peak_num: int, page_num: int = None, ion_mode: str = 'positive') -> List[Dict]:
        """
        为指定的Peak提取对应的m/z刻度信息，支持跨页搜索
        每个Peak可能有不同的刻度范围和间隔
        
        Args:
            peak_num (int): Peak编号
            page_num (int): 页面编号（可选，如果不提供则在所有文本中搜索）
            ion_mode (str): 离子模式，'positive' 或 'negative'，默认为 'positive'
            
        Returns:
            List[Dict]: 该Peak对应的m/z刻度信息列表
        """
        if not hasattr(self, 'text_content') or not self.text_content:
            self.text_content = self.extract_text()
        
        if not self.text_content or not hasattr(self, 'text_content_by_page'):
            return []
        
        import re
        
        mz_section_found = False
        mz_scales = []
        
        self.logger.debug(f"为Peak {peak_num}提取m/z刻度（使用索引优化）")
        
        # Step 1: 使用索引快速查找Peak标识位置
        index_key = (peak_num, ion_mode)
        if index_key not in self._peak_index:
            self.logger.warning(f"  未在索引中找到Peak {peak_num} ({ion_mode}模式)标识")
            return []
        
        peak_info = self._peak_index[index_key]
        peak_found_page = peak_info['page']
        peak_found_line_in_page = peak_info['line_idx']
        
        self.logger.debug(f"  从索引中找到Peak {peak_num}标识: 第{peak_found_page}页第{peak_found_line_in_page + 1}行")
        
        # Step 2: 从找到Peak标识的位置开始，搜索m/z标记和刻度数据
        # 可能需要跨页搜索
        
        # m/z图表标记
        mz_markers = [
            'Counts vs. Mass-to-Charge (m/z)',
            'Counts vs. Mass-to-Charge',
            'Mass-to-Charge (m/z)',
            'Mass-to-Charge',
            'm/z'
        ]
        
        # 从Peak标识所在页面开始搜索
        search_started = False
        for page_info in self.text_content_by_page:
            current_page = page_info['page_num']
            page_lines = page_info['lines']
            
            # 如果还没开始搜索，跳过Peak标识之前的页面
            if not search_started:
                if current_page < peak_found_page:
                    continue
                elif current_page == peak_found_page:
                    # 在Peak标识所在页面，从Peak标识位置开始搜索
                    start_line = peak_found_line_in_page + 1
                    search_started = True
                else:
                    # 已经超过了Peak标识所在页面，开始搜索
                    start_line = 0
                    search_started = True
            else:
                start_line = 0
            
            # 在当前页面搜索
            for line_idx in range(start_line, len(page_lines)):
                line = page_lines[line_idx].strip()
                
                # 如果还没找到m/z标记，继续寻找
                if not mz_section_found:
                    for marker in mz_markers:
                        if marker in line:
                            # 检查是否为跨页情况：如果在Peak标识的同一页找到m/z标记
                            # 需要确保m/z标记在Peak标识之后（行号更大）
                            if current_page == peak_found_page:
                                # 在同一页面，m/z标记必须在Peak标识之后
                                if line_idx > peak_found_line_in_page:
                                    mz_section_found = True
                                    self.logger.debug(f"  在第{current_page}页第{line_idx + 1}行找到m/z图表标记: {marker}")
                                    break
                                else:
                                    # m/z标记在Peak标识之前，跳过这个标记
                                    self.logger.debug(f"  在第{current_page}页第{line_idx + 1}行发现m/z标记，但位置在Peak {peak_num}标识之前，跳过")
                                    continue
                            else:
                                # 在不同页面，直接接受
                                mz_section_found = True
                                self.logger.debug(f"  在第{current_page}页第{line_idx + 1}行找到m/z图表标记: {marker}")
                                break
                    
                    if mz_section_found:
                        continue
                
                # 如果找到了m/z标记，开始收集数字
                if mz_section_found:
                    # 匹配单个数字（使用预编译的正则表达式）
                    single_number_match = self._compiled_patterns['single_number'].match(line)
                    if single_number_match:
                        mz_value = float(line)
                        mz_scales.append({
                            'mz_value': mz_value,
                            'page': current_page,
                            'line_in_page': line_idx + 1,
                            'peak': peak_num
                        })
                        continue
                    
                    # 匹配多个空格分隔的数字（使用预编译的正则表达式）
                    multi_number_match = self._compiled_patterns['multi_number'].findall(line)
                    if len(multi_number_match) >= 2:  # 至少2个数字
                        for num_str in multi_number_match:
                            mz_value = float(num_str)
                            mz_scales.append({
                                'mz_value': mz_value,
                                'page': current_page,
                                'line_in_page': line_idx + 1,
                                'peak': peak_num
                            })
                        continue
                    
                    # 如果遇到下一个Peak或其他结束标记，停止收集
                    if line and (
                        re.search(r'Peak\s+\d+\s+from', line) or  # 下一个Peak
                        any(keyword in line.lower() for keyword in ['spectrum', 'chromatogram']) or
                        line.startswith('Sample Spectra')  # 新的Sample Spectra部分
                    ):
                        print(f"  在第{current_page}页第{line_idx + 1}行遇到结束标记，停止收集: {line[:50]}...")
                        return self._finalize_mz_scales(mz_scales, peak_num)
                    
                    # 如果遇到非数字行且不是空行，可能结束了当前Peak的m/z区域
                    if line and not re.search(r'\d', line) and len(line) > 10:
                        # 如果已经收集到了一些数字，可能是结束了
                        if len(mz_scales) > 3:  # 至少收集到几个数字后才考虑结束
                            print(f"  在第{current_page}页第{line_idx + 1}行可能的结束标记: {line[:30]}...")
                            return self._finalize_mz_scales(mz_scales, peak_num)
            
            # 如果在当前页面已经找到了一些m/z数据，并且到了页面末尾
            # 检查是否需要继续到下一页搜索
            if mz_section_found and len(mz_scales) > 0:
                # 如果已经收集到足够的数据，可以结束
                if len(mz_scales) >= 5:  # 假设至少需要5个刻度点
                    break
                # 否则继续到下一页搜索
        
        return self._finalize_mz_scales(mz_scales, peak_num)
    
    def _finalize_mz_scales(self, mz_scales: List[Dict], peak_num: int) -> List[Dict]:
        """
        完成m/z刻度数据的处理：去重、排序、分析
        
        Args:
            mz_scales (List[Dict]): 原始m/z刻度列表
            peak_num (int): Peak编号
            
        Returns:
            List[Dict]: 处理后的m/z刻度列表
        """
        # 去重并按m/z值排序
        unique_mz_values = {}
        for scale in mz_scales:
            mz_val = scale['mz_value']
            if mz_val not in unique_mz_values:
                unique_mz_values[mz_val] = scale
        
        mz_scales = list(unique_mz_values.values())
        mz_scales.sort(key=lambda x: x['mz_value'])
        
        print(f"  Peak {peak_num}找到{len(mz_scales)}个m/z刻度值")
        if mz_scales:
            print(f"    m/z范围: {mz_scales[0]['mz_value']:.4g} - {mz_scales[-1]['mz_value']:.4g}")
            
            # 显示跨页信息
            pages_used = set(scale.get('page', 'unknown') for scale in mz_scales)
            if len(pages_used) > 1:
                print(f"    跨页搜索：数据来自第 {sorted(pages_used)} 页")
            
            # 分析刻度间隔
            if len(mz_scales) > 1:
                intervals = []
                for i in range(1, min(len(mz_scales), 6)):  # 检查前几个间隔
                    interval = mz_scales[i]['mz_value'] - mz_scales[i-1]['mz_value']
                    intervals.append(interval)
                
                if intervals:
                    avg_interval = sum(intervals) / len(intervals)
                    print(f"    平均间隔: {avg_interval:.4g}")
        
        return mz_scales
    
    def _calculate_intensity_from_reference(self, vertical_lines: List[Dict], reference_intensity: float) -> List[Dict]:
        """
        基于参考强度计算其他质谱棒的强度
        最长的竖线为刻度线，第二长的线为最强信号（已知强度），据此计算其他棒的强度
        
        Args:
            vertical_lines (List[Dict]): 垂直线条列表（已按长度排序）
            reference_intensity (float): 已知的最强信号强度值
            
        Returns:
            List[Dict]: 包含计算强度的垂直线条列表
        """
        if len(vertical_lines) < 2:
            return vertical_lines
        
        # 最长的线为刻度线（忽略）
        # 第二长的线为最强信号（参考强度）
        scale_line = vertical_lines[0]  # 最长线（刻度线）
        reference_line = vertical_lines[1]  # 第二长线（最强信号）
        
        reference_height = reference_line['length']
        
        print(f"参考信号: 高度={reference_height:.4g}, 强度={reference_intensity:.4g}")
        
        # 为所有线条计算强度
        result_lines = []
        for i, line in enumerate(vertical_lines):
            if i == 0:
                # 跳过刻度线
                continue
            
            # 基于高度比例计算强度
            height_ratio = line['length'] / reference_height
            calculated_intensity = reference_intensity * height_ratio
            
            # 添加计算的强度信息
            line_with_intensity = line.copy()
            line_with_intensity['calculated_intensity'] = calculated_intensity
            line_with_intensity['height_ratio'] = height_ratio
            
            result_lines.append(line_with_intensity)
        
        print(f"基于参考强度计算了{len(result_lines)}条质谱棒的强度")
        
        return result_lines
    
    def _find_scale_lines_for_peak(self, peak_num: int, page_num: int, counts_position: Dict, expected_count: int, chart_boundaries: Dict = None) -> List[Dict]:
        """
        为指定Peak查找专属的刻度线（短竖线）
        
        Args:
            peak_num (int): Peak编号
            page_num (int): 页面编号
            counts_position (Dict): "Counts vs. Mass-to-Charge"文本位置
            expected_count (int): 期望的刻度线数量
            chart_boundaries (Dict): 图表边界信息，用于限制搜索范围
            
        Returns:
            List[Dict]: 该Peak专属的刻度线信息列表，按x坐标排序
        """
        if not self.doc or page_num >= len(self.doc):
            return []
        
        page = self.doc[page_num]
        
        # 仅在峰专属图表下边界（lower_y）的下方与该峰专属轴标题上方之间搜索短竖线
        if chart_boundaries:
            chart_left = chart_boundaries.get('left_x', 40)
            chart_right = chart_boundaries.get('right_x', 590)
            # 使用峰专属边界的lower_y作为下边界基准
            peak_boundaries = self._get_peak_specific_boundaries(peak_num, page_num, chart_boundaries)
            lower_y_base = peak_boundaries.get('lower_y', chart_boundaries.get('lower_y', counts_position['y0'] - 30))
        else:
            chart_left, chart_right = 40, 590
            lower_y_base = counts_position['y0'] - 30
        
        # y坐标带：位于图表下边界下方少量（更大y），且位于轴标题上方（更小y）
        # 注意：PDF坐标系y向下为正，需要保证 y_min_band < y_max_band
        band_low = lower_y_base + 2
        band_high = counts_position['y0'] - 2
        y_min_band = min(band_low, band_high)
        y_max_band = max(band_low, band_high)
        x_min_band = chart_left - 5
        x_max_band = chart_right + 5
        
        print(f"在第{page_num + 1}页为Peak {peak_num}查找专属刻度线")
        print(f"搜索带: x={x_min_band:.4g}-{x_max_band:.4g}, y={y_min_band:.4g}-{y_max_band:.4g}")
        
        # 收集候选短竖线
        candidates = []
        for drawing in self._get_page_drawings_cached(page_num):
            for item in drawing.get("items", []):
                if item[0] == "l":
                    p0, p1 = item[1], item[2]
                    if abs(p0.x - p1.x) <= 2:  # 垂直
                        x_val = (p0.x + p1.x) / 2.0
                        y0 = min(p0.y, p1.y)
                        y1 = max(p0.y, p1.y)
                        if x_min_band <= x_val <= x_max_band and y0 >= y_min_band and y1 <= y_max_band:
                            length = y1 - y0
                            # 刻度线为短竖线：3-20像素
                            if 3 <= length <= 20:
                                candidates.append({
                                    'x': x_val,
                                    'y_top': y0,
                                    'y_bottom': y1,
                                    'length': length,
                                    'peak_num': peak_num
                                })
        print(f"候选短竖线: {len(candidates)} 条")
        if not candidates:
            raise RuntimeError(f"未在搜索带内找到刻度线候选（Peak {peak_num}, page {page_num + 1}）")
        
        # 以(y_top, y_bottom)聚类，寻找上端/下端一致的一排线
        from collections import defaultdict
        groups = defaultdict(list)
        def q(v: float) -> int:
            # 1像素量化，允许极小抖动
            return int(round(v))
        for c in candidates:
            key = (q(c['y_top']), q(c['y_bottom']))
            groups[key].append(c)
        
        def uniform_score(xs: List[float]) -> float:
            if len(xs) < 3:
                return 0.0
            xs = sorted(v for v in xs)
            intervals = [xs[i] - xs[i-1] for i in range(1, len(xs))]
            avg = sum(intervals) / len(intervals)
            if avg <= 0:
                return 0.0
            max_dev = max(abs(d - avg) for d in intervals)
            return max(0.0, 1.0 - max_dev / avg)
        
        # 评估每个组：数量多且x间距均匀
        best_group = None
        best_score = -1.0
        for (yt, yb), lines in groups.items():
            if len(lines) < 4:
                continue
            xs = [l['x'] for l in lines]
            score = uniform_score(xs)
            # 只接受均匀度 >= 0.6 的组
            if score >= 0.6:
                # 兼顾数量与均匀度
                composite = score + min(len(lines), 12) / 20.0
                if composite > best_score:
                    best_score = composite
                    best_group = lines
        
        if not best_group:
            # 回退：选择x均匀度最高的组
            for (yt, yb), lines in groups.items():
                if len(lines) < 3:
                    continue
                xs = [l['x'] for l in lines]
                score = uniform_score(xs)
                composite = score + min(len(lines), 12) / 20.0
                if composite > best_score:
                    best_score = composite
                    best_group = lines
        
        if not best_group:
            raise RuntimeError(f"未识别到均匀的刻度线组（Peak {peak_num}, page {page_num + 1}）")
        if not best_group:
            raise RuntimeError(f"未选择到任何可用的刻度线组（Peak {peak_num}, page {page_num + 1}）")
        
        best_group.sort(key=lambda d: d['x'])
                # 去除过近的重复（绘制重叠）
        dedup = [best_group[0]]
        for item in best_group[1:]:
            if abs(item['x'] - dedup[-1]['x']) > 2.0:
                dedup.append(item)
        # 将x统一保留到四位有效数字
        for d in dedup:
            pass  # x值已经是正确的精度
        print(f"选中刻度线: {len(dedup)} 条; x范围 {dedup[0]['x']:.4f}-{dedup[-1]['x']:.4f}")
        # 最终均匀性报告
        if len(dedup) >= 3:
            xs = [l['x'] for l in dedup]
            xs.sort()
            intervals = [xs[i] - xs[i-1] for i in range(1, len(xs))]
            avg = sum(intervals) / len(intervals)
            max_dev = max(abs(d - avg) for d in intervals)
            print(f"  均匀性: 平均间隔={avg:.4g}, 最大偏差={max_dev:.4g}, 得分={uniform_score(xs):.2f}")
        return dedup
    
    def _select_best_scale_lines(self, candidates: List[Dict], expected_count: int, peak_num: int) -> List[Dict]:
        """
        从候选刻度线中选择最佳的刻度线集合
        
        Args:
            candidates (List[Dict]): 刻度线候选列表
            expected_count (int): 期望的刻度线数量
            peak_num (int): Peak编号
            
        Returns:
            List[Dict]: 选择的最佳刻度线列表
        """
        if not candidates:
            return []
        
        # 1. 去除x坐标太接近的重复线条
        filtered_candidates = [candidates[0]]
        for candidate in candidates[1:]:
            if candidate['x'] - filtered_candidates[-1]['x'] > 3:  # 至少相距3个点
                filtered_candidates.append(candidate)
        
        print(f"  去重后剩余{len(filtered_candidates)}条候选")
        if filtered_candidates:
            # 检查去重后的候选是否均匀分布
            if len(filtered_candidates) > 2:
                intervals = []
                for i in range(1, len(filtered_candidates)):
                    interval = filtered_candidates[i]['x'] - filtered_candidates[i-1]['x']
                    intervals.append(interval)
                
                avg_interval = sum(intervals) / len(intervals)
                max_deviation = max(abs(interval - avg_interval) for interval in intervals) if intervals else 0
                
                print(f"  去重后间隔校验: 平均={avg_interval:.4g}, 最大偏差={max_deviation:.4g}, 偏差率={max_deviation/avg_interval*100:.4g}%")
                
                if max_deviation/avg_interval > 0.5:  # 偏差超过50%说明分布很不均匀
                    print(f"  ⚠️  去重后候选分布不均匀，前10个间隔:")
                    for i, interval in enumerate(intervals[:10]):
                        print(f"    间隔{i+1}: {interval:.4g}")
            
            # 打印前15个去重后的候选x坐标
            filtered_x_coords = [f"{line['x']:.4g}" for line in filtered_candidates[:15]]
            print(f"  去重后前15个x坐标: [{', '.join(filtered_x_coords)}]")
        
        # 2. 如果候选数量合适，直接使用
        if len(filtered_candidates) <= expected_count * 1.2:  # 在期望数量的120%以内
            return filtered_candidates
        
        # 3. 如果候选太多，智能识别真正的主刻度线
        if expected_count > 0:
            # 尝试按长度分组，识别主刻度线
            main_scale_lines = self._identify_main_scale_lines(filtered_candidates, expected_count)
            
            if main_scale_lines and len(main_scale_lines) >= expected_count * 0.7:
                # 如果找到足够的主刻度线，使用它们
                selected_lines = main_scale_lines[:expected_count]
                print(f"  ✓ 识别出{len(main_scale_lines)}条主刻度线，选择前{len(selected_lines)}条")
                return selected_lines
            else:
                # 备用方案：按索引均匀选择
                step = len(filtered_candidates) / expected_count
                selected_lines = []
                for i in range(expected_count):
                    idx = int(i * step)
                    if idx < len(filtered_candidates):
                        selected_lines.append(filtered_candidates[idx])
                
                print(f"  使用备用方案：从{len(filtered_candidates)}条中按索引选择{len(selected_lines)}条")
                return selected_lines
        
        # 4. 如果无法确定期望数量，返回所有筛选后的候选
        return filtered_candidates
    
    def _identify_main_scale_lines(self, candidates: List[Dict], expected_count: int) -> List[Dict]:
        """
        从候选刻度线中智能识别真正的主刻度线
        
        Args:
            candidates (List[Dict]): 候选刻度线列表（已按x坐标排序）
            expected_count (int): 期望的主刻度线数量
            
        Returns:
            List[Dict]: 识别出的主刻度线列表
        """
        if len(candidates) < 3:
            return candidates
        
        print(f"  开始智能识别主刻度线...")
        
        # 1. 按长度分组，找出最可能是主刻度线的长度范围
        lengths = [c['length'] for c in candidates]
        avg_length = sum(lengths) / len(lengths)
        
        # 按长度分组（容忍20%的变化）
        from collections import defaultdict
        length_groups = defaultdict(list)
        
        for candidate in candidates:
            length_key = round(candidate['length'] / avg_length * 10)  # 归一化到10倍精度
            length_groups[length_key].append(candidate)
        
        print(f"  按长度分组: 平均长度={avg_length:.4g}")
        for key, group in sorted(length_groups.items()):
            if len(group) >= 3:  # 只显示有足够成员的组
                group_avg_length = sum(c['length'] for c in group) / len(group)
                print(f"    组{key}: {len(group)}条线, 平均长度={group_avg_length:.4g}")
        
        # 2. 选择最大的长度组作为主刻度线候选
        # 但首先尝试较长的线条组（可能是主刻度线）
        sorted_groups = sorted(length_groups.items(), key=lambda x: (len(x[1]), x[0]), reverse=True)
        
        main_group = None
        for length_key, group in sorted_groups:
            if len(group) >= expected_count * 0.4:  # 至少有期望数量的40%
                # 检查这个组的均匀性潜力
                group.sort(key=lambda x: x['x'])
                if len(group) >= 3:
                    # 快速检查前几个间隔
                    test_intervals = []
                    for i in range(1, min(len(group), 6)):
                        interval = group[i]['x'] - group[i-1]['x']
                        test_intervals.append(interval)
                    
                    if test_intervals:
                        avg_test_interval = sum(test_intervals) / len(test_intervals)
                        max_test_deviation = max(abs(interval - avg_test_interval) for interval in test_intervals)
                        test_uniformity = 1 - (max_test_deviation / avg_test_interval) if avg_test_interval > 0 else 0
                        
                        group_avg_length = sum(c['length'] for c in group) / len(group)
                        print(f"  评估组{length_key}: {len(group)}条线, 平均长度={group_avg_length:.4g}, 初步均匀性={test_uniformity:.2f}")
                        
                        if test_uniformity > 0.3:  # 初步均匀性超过30%
                            main_group = group
                            print(f"  选择组{length_key}作为主刻度线候选")
                            break
        
        if main_group is None:
            main_group = max(length_groups.values(), key=len)
            print(f"  回退到最大组作为主刻度线候选: {len(main_group)}条")
        
        # 3. 在主组中寻找等间隔的子集
        main_group.sort(key=lambda x: x['x'])  # 按x坐标排序
        
        if len(main_group) < expected_count:
            print(f"  主组数量不足，扩展搜索...")
            # 如果主组数量不足，选择第二大组补充
            remaining_groups = [g for g in length_groups.values() if g != main_group]
            if remaining_groups:
                second_group = max(remaining_groups, key=len)
                main_group.extend(second_group)
                main_group.sort(key=lambda x: x['x'])
                print(f"  扩展后候选数量: {len(main_group)}")
        
        # 4. 在主组中寻找最等间隔的子集
        best_subset = self._find_most_uniform_subset(main_group, expected_count)
        
        if best_subset:
            # 验证间隔均匀性
            if len(best_subset) > 2:
                intervals = []
                for i in range(1, len(best_subset)):
                    interval = best_subset[i]['x'] - best_subset[i-1]['x']
                    intervals.append(interval)
                
                avg_interval = sum(intervals) / len(intervals)
                max_deviation = max(abs(interval - avg_interval) for interval in intervals)
                uniformity = 1 - (max_deviation / avg_interval) if avg_interval > 0 else 0
                
                print(f"  最佳子集均匀性: {uniformity:.2f} (1.0为完全均匀)")
                
                if uniformity > 0.5:  # 均匀性超过50%就认为是可接受的主刻度线
                    print(f"  ✓ 找到可接受质量主刻度线: {len(best_subset)}条 (均匀性: {uniformity:.2f})")
                    return best_subset
                else:
                    print(f"  ✗ 主刻度线均匀性不足: {uniformity:.2f}")
        
        return []
    
    def _find_most_uniform_subset(self, candidates: List[Dict], target_count: int) -> List[Dict]:
        """
        从候选中找到最等间隔的子集
        
        Args:
            candidates (List[Dict]): 候选列表（已按x坐标排序）
            target_count (int): 目标数量
            
        Returns:
            List[Dict]: 最等间隔的子集
        """
        if len(candidates) <= target_count:
            return candidates
        
        # 尝试不同的起始点和步长，找到最均匀的子集
        best_subset = None
        best_uniformity = 0
        
        # 计算理想间隔
        total_span = candidates[-1]['x'] - candidates[0]['x']
        ideal_interval = total_span / (target_count - 1) if target_count > 1 else 0
        
        print(f"    理想间隔: {ideal_interval:.4g}")
        
        # 尝试以不同的候选作为起点
        for start_idx in range(min(5, len(candidates))):  # 最多尝试5个起点
            subset = [candidates[start_idx]]
            current_x = candidates[start_idx]['x']
            
            # 贪婪选择最接近理想间隔的下一个点
            for _ in range(target_count - 1):
                target_x = current_x + ideal_interval
                best_candidate = None
                min_distance = float('inf')
                
                # 在剩余候选中找最接近目标位置的
                for candidate in candidates:
                    if candidate['x'] > current_x and candidate not in subset:
                        distance = abs(candidate['x'] - target_x)
                        if distance < min_distance:
                            min_distance = distance
                            best_candidate = candidate
                
                if best_candidate:
                    subset.append(best_candidate)
                    current_x = best_candidate['x']
                else:
                    break
            
            # 评估这个子集的均匀性
            if len(subset) >= target_count * 0.8:  # 至少达到目标数量的80%
                uniformity = self._calculate_uniformity(subset)
                if uniformity > best_uniformity:
                    best_uniformity = uniformity
                    best_subset = subset[:target_count]  # 只取目标数量
        
        return best_subset if best_subset else []
    
    def _calculate_uniformity(self, subset: List[Dict]) -> float:
        """
        计算子集的间隔均匀性
        
        Args:
            subset (List[Dict]): 子集列表
            
        Returns:
            float: 均匀性得分 (0-1，1为完全均匀)
        """
        if len(subset) < 2:
            return 1.0
        
        intervals = []
        for i in range(1, len(subset)):
            interval = subset[i]['x'] - subset[i-1]['x']
            intervals.append(interval)
        
        if not intervals:
            return 1.0
        
        avg_interval = sum(intervals) / len(intervals)
        if avg_interval == 0:
            return 1.0
        
        max_deviation = max(abs(interval - avg_interval) for interval in intervals)
        uniformity = 1 - max_deviation / avg_interval
        
        return max(0, uniformity)
    
    def _get_peak_specific_boundaries(self, peak_num: int, page_num: int, chart_boundaries: Dict) -> Dict:
        """
        为特定Peak获取更精确的边界信息
        
        Args:
            peak_num (int): Peak编号
            page_num (int): 页面编号
            chart_boundaries (Dict): 通用图表边界
            
        Returns:
            Dict: Peak专属的边界信息
        """
        # 基于Peak编号和页面位置，调整边界以避免不同Peak的刻度线混淆
        if not chart_boundaries:
            return {}
        
        # 直接返回原始边界（不需要复制，因为函数不修改边界数据）
        # 为不同Peak调整边界，确保每个Peak有独立的搜索区域
        # 这里可以根据实际PDF布局进一步优化
        
        self.logger.debug(f"  Peak {peak_num}专属边界: {chart_boundaries}")
        return chart_boundaries
    
    def _calculate_mz_from_scales(self, vertical_lines: List[Dict], mz_scales: List[Dict], peak_num: int = None, page_num: int = None, chart_boundaries: Dict = None, is_cross_page: bool = False) -> tuple[List[Dict], Dict]:
        """
        基于m/z刻度信息和实际刻度线计算每个质谱棒的m/z值
        
        Args:
            vertical_lines (List[Dict]): 垂直线条列表（质谱棒）
            mz_scales (List[Dict]): m/z刻度信息列表
            peak_num (int): Peak编号
            page_num (int): 页面编号
            
        Returns:
            List[Dict]: 包含计算m/z值的垂直线条列表
        """
        if len(mz_scales) == 0:
            print("没有m/z刻度信息，无法计算m/z值")
            return vertical_lines
        
        # 尝试使用新的刻度线查找方法
        if peak_num is not None and page_num is not None:
            # 查找Peak专属的"Counts vs. Mass-to-Charge"位置
            counts_position = self._find_counts_vs_mass_position_for_peak(page_num, peak_num, is_cross_page)
            if counts_position:
                # 获取Peak专属边界
                peak_boundaries = self._get_peak_specific_boundaries(peak_num, page_num, chart_boundaries)
                # 查找刻度线，使用Peak专属边界以更精确地定位该Peak的刻度线
                scale_lines = self._find_scale_lines_for_peak(peak_num, page_num, counts_position, len(mz_scales), peak_boundaries)
                
                if len(scale_lines) >= 2:  # 至少需要2条刻度线来建立映射
                    print(f"使用{len(scale_lines)}条刻度线进行m/z计算")
                    
                    # 排序m/z值和刻度线
                    sorted_mz_values = sorted([scale['mz_value'] for scale in mz_scales])
                    sorted_scale_lines = sorted(scale_lines, key=lambda line: line['x'])
                    
                    # 建立刻度线x坐标到m/z值的映射
                    # 处理最后刻度线无对应m/z值的情况：使用有效的刻度线范围
                    min_mz = min(sorted_mz_values)
                    max_mz = max(sorted_mz_values)
                    min_scale_x = sorted_scale_lines[0]['x']
                    
                    # 如果刻度线数量大于m/z值数量，使用倒数第二个刻度线作为最大值
                    if len(sorted_scale_lines) > len(sorted_mz_values):
                        # 使用倒数第二个有效刻度线（对应最后一个m/z值）
                        max_scale_x = sorted_scale_lines[len(sorted_mz_values) - 1]['x']
                        print(f"检测到最后刻度线无对应m/z值，使用倒数第二个刻度线: x={max_scale_x:.4g}")
                    else:
                        max_scale_x = sorted_scale_lines[-1]['x']
                    
                    print(f"刻度映射: x({min_scale_x:.4f}) -> m/z({min_mz:.4f}), x({max_scale_x:.4f}) -> m/z({max_mz:.4f})")
                    
                    # 打印详细的刻度线坐标和对应的m/z值
                    print("  详细刻度映射:")
                    for i, scale_line in enumerate(sorted_scale_lines):
                        x_coord = scale_line['x']
                        if i < len(sorted_mz_values):
                            mz_val = sorted_mz_values[i]
                            print(f"    刻度线{i+1}: x={x_coord:.4f} -> m/z={mz_val:.4f}")
                        else:
                            print(f"    刻度线{i+1}: x={x_coord:.4f} (无对应m/z值)")
                    
                    # 打印m/z值列表
                    mz_values_str = [f"{mz:.4g}" for mz in sorted_mz_values]
                    print(f"  m/z刻度值: [{', '.join(mz_values_str)}]")
                    
                    # 为每个质谱棒计算m/z值
                    result_lines = []
                    for line in vertical_lines:
                        line_x = line['x']
                        
                        # 线性插值计算m/z值
                        if max_scale_x > min_scale_x:
                            ratio = (line_x - min_scale_x) / (max_scale_x - min_scale_x)
                            # 确保ratio在0-1范围内
                            ratio = max(0, min(1, ratio))
                            calculated_mz = min_mz + ratio * (max_mz - min_mz)
                        else:
                            calculated_mz = (min_mz + max_mz) / 2
                        
                        line_with_mz = line.copy()
                        line_with_mz['calculated_mz'] = calculated_mz
                        result_lines.append(line_with_mz)
                    
                    print(f"基于刻度线位置计算了{len(result_lines)}个质谱棒的m/z值")
                    
                    # 打印前5个质谱棒的详细计算结果
                    print("  前5个质谱棒的m/z计算结果:")
                    for i, line in enumerate(result_lines[:5]):
                        x_coord = line['x']
                        mz_val = line['calculated_mz']
                        print(f"    质谱棒{i+1}: x={x_coord} -> m/z={mz_val}")
                    
                    # 准备线性插值参数
                    interpolation_params = {
                        'min_mz': min_mz,
                        'max_mz': max_mz,
                        'min_scale_x': min_scale_x,
                        'max_scale_x': max_scale_x,
                        'peak_num': peak_num,
                        'page_num': page_num + 1 if page_num is not None else None
                    }
                    
                    return result_lines, interpolation_params
                else:
                    raise RuntimeError(f"未找到足够的刻度线用于m/z计算（Peak {peak_num}, page {page_num + 1}）")
            else:
                raise RuntimeError(f"未找到'Counts vs. Mass-to-Charge'位置（Peak {peak_num}, page {page_num + 1}）")
        
        # 不再使用备用方法，返回空结果
        return [], {}
    
    def _extract_mass_spectrum_bars(self, peak_num: int, ion_mode: str = 'positive') -> List[Dict]:
        """
        提取指定Peak的质谱棒图信息，包括Top 10高度的垂直线条，支持跨页搜索
        
        Args:
            peak_num (int): Peak编号
            ion_mode (str): 离子模式，'positive' 或 'negative'，默认为 'positive'
            
        Returns:
            List[Dict]: 质谱棒图信息列表
        """
        all_spectrum_bars = []
        
        # 首先使用跨页搜索找到Peak标识和对应的m/z标记位置
        peak_found_page = None
        mz_marker_page = None
        
        # Step 1: 使用索引快速查找Peak位置
        index_key = (peak_num, ion_mode)
        if index_key not in self._peak_index:
            print(f"未在索引中找到Peak {peak_num}的标识 ({ion_mode} mode)")
            return []
        
        peak_info = self._peak_index[index_key]
        peak_found_page = peak_info['page']  # 1-based索引
        peak_found_line_in_page = peak_info['line_idx']
        
        self.logger.debug(f"从索引中找到Peak {peak_num}的质谱信息: 第{peak_found_page}页 ({ion_mode} mode)")
        
        # Step 1.5: 从Peak标识位置开始搜索m/z标记
        if hasattr(self, 'text_content_by_page') and self.text_content_by_page:
            
            # 使用与_extract_mz_scale_for_peak相同的跨页搜索逻辑
            # 从Peak标识所在页面开始，搜索完整的"Counts vs. Mass-to-Charge (m/z)"标记
            mz_markers = [
                'Counts vs. Mass-to-Charge (m/z)',
                'Counts vs. Mass-to-Charge',
                'Mass-to-Charge (m/z)',
                'Mass-to-Charge'
            ]
            
            search_started = False
            # peak_found_line_in_page已经从索引中获取
            
            # 从Peak标识位置开始跨页搜索m/z标记
            for page_info in self.text_content_by_page:
                current_page = page_info['page_num']
                page_lines = page_info['lines']
                
                # 确定搜索起始位置
                if not search_started:
                    if current_page < peak_found_page:
                        continue
                    elif current_page == peak_found_page:
                        # 在Peak标识所在页面，从Peak标识位置开始搜索
                        start_line = peak_found_line_in_page + 1
                        search_started = True
                    else:
                        # 已经超过了Peak标识所在页面，从页面开头搜索
                        start_line = 0
                        search_started = True
                else:
                    start_line = 0
                
                # 在当前页面搜索m/z标记
                for line_idx in range(start_line, len(page_lines)):
                    line = page_lines[line_idx].strip()
                    for marker in mz_markers:
                        if marker in line:
                            mz_marker_page = current_page - 1  # 转换为0-based索引（用于PDF页面访问）
                            print(f"在第{current_page}页找到Peak {peak_num}的m/z标记: {marker}")
                            break
                    if mz_marker_page is not None:
                        break
                
                if mz_marker_page is not None:
                    break
            
            if mz_marker_page is None:
                print(f"未找到Peak {peak_num}的m/z标记")
                return []
        
        else:
            # 回退到原始方法：遍历所有页面
            ion_sign = '+' if ion_mode == 'positive' else '-'
            for page_num in range(len(self.doc)):
                # 使用缓存版本的文本获取
                page_text = self._get_page_text_cached(page_num)
                
                peak_pattern = f"Peak\\s+{peak_num}\\s+from\\s+\\{ion_sign}\\s+BPC Scan"
                if re.search(peak_pattern, page_text):
                    peak_found_page = page_num + 1  # 转换为1-based索引以保持一致性
                    mz_marker_page = page_num  # 假设在同一页
                    print(f"在第{page_num + 1}页找到Peak {peak_num}的质谱信息 ({ion_mode} mode)")
                    break
            
            if peak_found_page is None:
                print(f"未找到Peak {peak_num}的标识 ({ion_mode} mode)")
                return []
        
        # Step 2: 在m/z标记所在的页面查找"Counts vs. Mass-to-Charge"文本位置和图表边界
        is_cross_page = (peak_found_page != mz_marker_page + 1)  # 判断是否跨页（注意索引转换）
        counts_position = self._find_counts_vs_mass_position_for_peak(mz_marker_page, peak_num, is_cross_page)
        if not counts_position:
            print(f"在第{mz_marker_page + 1}页未找到Peak {peak_num}的'Counts vs. Mass-to-Charge'文本")
            return []
        
        print(f"找到Peak {peak_num}的'Counts vs. Mass-to-Charge'位置: y={counts_position['y0']:.4g}")
        
        # 找到图表边界（在m/z标记所在页面）
        chart_boundaries = self._find_chart_boundaries(mz_marker_page, counts_position)
        if not chart_boundaries:
            print(f"在第{mz_marker_page + 1}页无法确定图表边界")
            return []
        
        print(f"图表边界: lower_y={chart_boundaries['lower_y']:.4g}, upper_y={chart_boundaries['upper_y']:.4g}")
        
        # 为该Peak提取专属的垂直线条（质谱棒）- 在m/z标记所在页面
        peak_vertical_lines = self._extract_peak_specific_vertical_lines(
            peak_num, mz_marker_page, chart_boundaries
        )
        
        if not peak_vertical_lines:
            print(f"在第{mz_marker_page + 1}页未找到Peak {peak_num}的专属垂直线条")
            return []
        
        print(f"找到Peak {peak_num}的{len(peak_vertical_lines)}条专属垂直线条")
        
        # 按长度排序并选择Top 20
        peak_vertical_lines.sort(key=lambda x: x['length'], reverse=True)
        top_20_lines = peak_vertical_lines[1:21]  # 跳过最长的线条（可能是坐标轴）
        
        print(f"选择Peak {peak_num}的Top {len(top_20_lines)}条最高的垂直线条")
        
        # 获取参考强度（从文本中已提取的最强信号强度）
        reference_intensity = None
        
        # 计算m/z和强度值
        spectrum_data, interpolation_params = self._calculate_mz_and_intensity(
            top_20_lines, chart_boundaries, mz_marker_page, reference_intensity, peak_num, is_cross_page, ion_mode
        )
        
        # 为每条数据添加Peak信息和线性插值参数
        for data in spectrum_data:
            data['Peak'] = peak_num
            # 添加线性插值参数
            if interpolation_params:
                data['min_mz'] = interpolation_params.get('min_mz')
                data['max_mz'] = interpolation_params.get('max_mz')
                data['min_scale_x'] = interpolation_params.get('min_scale_x')
                data['max_scale_x'] = interpolation_params.get('max_scale_x')
        
        # 进行同位素峰聚类分析
        clustered_spectrum_data = self._cluster_isotope_peaks(spectrum_data, peak_num)
        
        # 将聚类后的数据添加到结果中
        for data in clustered_spectrum_data:
            all_spectrum_bars.append(data)
        
        print(f"Peak {peak_num}在第{mz_marker_page + 1}页提取到{len(spectrum_data)}条质谱棒图数据，聚类后{len(clustered_spectrum_data)}条")
        
        # 按强度排序返回结果
        all_spectrum_bars.sort(key=lambda x: x['intensity'], reverse=True)
        return all_spectrum_bars
    
    def _cluster_isotope_peaks(self, spectrum_data: List[Dict], peak_num: int) -> List[Dict]:
        """
        对质谱数据进行同位素峰聚类分析
        
        基于同位素峰的特征：
        1. 质量差：常见同位素峰间距约为1 Da (单电荷)、0.5 Da (双电荷)、0.33 Da (三电荷)等
        2. 强度关系：同位素峰强度通常递减，但考虑测量误差允许一定范围
        3. 空间位置：在质谱图中相邻的同位素峰位置应该接近
        4. 测量误差：考虑m/z值0.1-0.5的估算误差
        
        Args:
            spectrum_data (List[Dict]): 原始质谱数据
            peak_num (int): Peak编号
            
        Returns:
            List[Dict]: 聚类后的质谱数据，每个同位素峰组用强度最高的峰代表
        """
        if not spectrum_data:
            return []
        
        self.logger.debug(f"开始对Peak {peak_num}的{len(spectrum_data)}条质谱信号进行同位素峰聚类")
        
        # 1. 按m/z值排序
        sorted_data = sorted(spectrum_data, key=lambda x: x['mz'])
        
        # 2. 同位素峰聚类参数
        # 考虑测量误差0.1-0.5，设置较宽松的容差
        mass_tolerance = 0.6  # m/z容差范围
        
        # 常见同位素质量差（考虑不同电荷态）
        expected_mass_diffs = [
            1.003355,  # 13C vs 12C (单电荷)
            0.501677,  # 13C vs 12C (双电荷) 
            0.334452,  # 13C vs 12C (三电荷)
            1.995796,  # 34S vs 32S (单电荷)
            0.997898,  # 34S vs 32S (双电荷)
            1.006277,  # 15N vs 14N (单电荷)
            0.503139,  # 15N vs 14N (双电荷)
            2.004245,  # 37Cl vs 35Cl (单电荷)
            1.002123,  # 37Cl vs 35Cl (双电荷)
        ]
        
        # 3. 初始化聚类结果
        clusters = []
        used_indices = set()
        
        # 4. 优化的聚类算法：使用滑动窗口减少比较次数
        # 时间复杂度从O(n²)优化到O(n*k)，其中k是窗口大小（通常很小）
        for i, base_peak in enumerate(sorted_data):
            if i in used_indices:
                continue
                
            # 创建新的聚类组，以当前峰为起点
            cluster = [i]
            used_indices.add(i)
            
            # 向后搜索可能的同位素峰
            # 优化：由于数据已按m/z排序，只需搜索到m/z差距超过3.5的位置即可停止
            j = i + 1
            max_search_mz = base_peak['mz'] + 3.5  # 最大搜索范围
            
            while j < len(sorted_data):
                if j in used_indices:  # O(1)查询
                    j += 1
                    continue
                
                candidate = sorted_data[j]
                
                # 如果m/z差距过大，停止搜索（利用排序特性）
                if candidate['mz'] > max_search_mz:
                    break
                
                mz_diff = candidate['mz'] - base_peak['mz']
                
                # 检查是否符合同位素峰特征
                if self._is_potential_isotope_peak(base_peak, candidate, mz_diff, 
                                                 mass_tolerance, expected_mass_diffs):
                    cluster.append(j)
                    used_indices.add(j)
                
                j += 1
            
            clusters.append(cluster)
        
        self.logger.debug(f"识别出{len(clusters)}个潜在同位素峰组")
        
        # 5. 处理每个聚类组，选择强度最高的峰作为代表
        clustered_results = []
        
        for cluster_idx, cluster in enumerate(clusters):
            if len(cluster) == 1:
                # 单峰，直接添加
                peak_data = sorted_data[cluster[0]].copy()
                peak_data['isotope_cluster_id'] = cluster_idx
                peak_data['isotope_cluster_size'] = 1
                clustered_results.append(peak_data)
            else:
                # 多峰组，选择强度最高的峰作为代表
                cluster_peaks = [sorted_data[i] for i in cluster]
                representative_peak = max(cluster_peaks, key=lambda x: x['intensity']).copy()
                
                # 添加聚类信息
                representative_peak['isotope_cluster_id'] = cluster_idx
                representative_peak['isotope_cluster_size'] = len(cluster)
                representative_peak['isotope_cluster_mz_range'] = [
                    min(p['mz'] for p in cluster_peaks),
                    max(p['mz'] for p in cluster_peaks)
                ]
                
                # 计算聚类内所有峰的总强度
                total_intensity = sum(p['intensity'] for p in cluster_peaks)
                representative_peak['isotope_cluster_total_intensity'] = total_intensity
                
                clustered_results.append(representative_peak)
                
                mz_range = representative_peak['isotope_cluster_mz_range']
                if self.logger.isEnabledFor(logging.DEBUG):
                    self.logger.debug(f"同位素峰组{cluster_idx}: {len(cluster)}个峰, "
                          f"m/z范围: {mz_range[0]:.3f}-{mz_range[1]:.3f}, "
                          f"代表峰m/z: {representative_peak['mz']:.3f}, "
                          f"强度: {representative_peak['intensity']:.1f}")
        
        # 6. 按强度重新排序（使用聚类总强度或代表峰强度）
        clustered_results.sort(key=lambda x: x.get('isotope_cluster_total_intensity', x['intensity']), 
                             reverse=True)
        
        self.logger.debug(f"聚类完成，从{len(spectrum_data)}条信号聚类为{len(clustered_results)}条代表性信号")
        
        return clustered_results
    
    def _is_potential_isotope_peak(self, base_peak: Dict, candidate_peak: Dict, 
                                 mz_diff: float, mass_tolerance: float, 
                                 expected_mass_diffs: List[float]) -> bool:
        """
        判断候选峰是否可能是基峰的同位素峰
        
        Args:
            base_peak (Dict): 基峰数据
            candidate_peak (Dict): 候选峰数据
            mz_diff (float): m/z差值
            mass_tolerance (float): 质量容差
            expected_mass_diffs (List[float]): 预期的同位素质量差列表
            
        Returns:
            bool: 是否为潜在的同位素峰
        """
        # 1. 检查m/z差值是否在合理范围内
        is_valid_mass_diff = any(abs(mz_diff - expected) <= mass_tolerance 
                               for expected in expected_mass_diffs)
        
        if not is_valid_mass_diff:
            return False
        
        # 2. 检查强度关系
        # 同位素峰通常比主峰弱，但考虑测量误差，允许较大范围
        intensity_ratio = candidate_peak['intensity'] / base_peak['intensity']
        
        # 允许候选峰强度为基峰的0.1倍到1.5倍（考虑测量误差和重叠峰）
        if intensity_ratio < 0.05 or intensity_ratio > 1.8:
            return False
        
        # 3. 检查峰的空间位置关系
        # 相邻的同位素峰在图中应该比较接近
        if 'x_coord' in base_peak and 'x_coord' in candidate_peak:
            x_coord_diff = abs(candidate_peak['x_coord'] - base_peak['x_coord'])
            if x_coord_diff > 60:  # 如果在图中距离过远，可能不相关
                return False
        
        return True
    
    
    def analyze_top5_peaks(self, key_info: Dict[str, Any]) -> pd.DataFrame:
        """
        分析Top5色谱峰，综合DAD和ESI信息
        优先使用254nm波长的DAD峰，如果不存在则使用210nm波长的DAD峰
        
        Args:
            key_info (Dict[str, Any]): 包含BPC_Peaks, DAD_Peaks_210nm, DAD_Peaks_254nm, ESI_Info的字典
            
        Returns:
            pd.DataFrame: Top5峰的综合分析结果
        """
        print("\n开始分析Top5色谱峰...")
        
        # 选择使用哪个DAD峰数据（优先254nm）
        dad_peaks = None
        wavelength_used = None
        
        if key_info.get("DAD_Peaks_254nm") is not None and not key_info["DAD_Peaks_254nm"].empty:
            dad_peaks = key_info["DAD_Peaks_254nm"]
            wavelength_used = "254nm"
            print("使用254nm波长的DAD峰数据")
        elif key_info.get("DAD_Peaks_210nm") is not None and not key_info["DAD_Peaks_210nm"].empty:
            dad_peaks = key_info["DAD_Peaks_210nm"]
            wavelength_used = "210nm"
            print("使用210nm波长的DAD峰数据")
        else:
            print("DAD_Peaks数据不存在，无法进行分析")
            return pd.DataFrame()
        
        if key_info["ESI_Info"] is None or key_info["ESI_Info"].empty:
            print("ESI_Info数据不存在，无法进行分析")
            return pd.DataFrame()
        
        esi_info = key_info["ESI_Info"]
        
        # print(f"DAD_Peaks数据: {len(dad_peaks)} 个峰")
        # print(f"ESI_Info数据: {len(esi_info)} 个峰")
        
        # 确保Area列存在并且是数值类型
        if 'Area' not in dad_peaks.columns:
            print("DAD_Peaks中没有Area列，无法进行分析")
            return pd.DataFrame()
        
        # 按Area降序排列，选择Top5
        dad_peaks_sorted = dad_peaks.sort_values('Area', ascending=False)
        top5_dad = dad_peaks_sorted.head(5).copy()
        
        # print(f"选择Area最大的前5个峰:")
        # print(top5_dad[['Peak', 'RT', 'Area', 'Area_Percent']].to_string(index=False))
        
        # 为每个Top5峰找到最接近的ESI峰
        result_data = []
        
        for idx, dad_row in top5_dad.iterrows():
            dad_rt = self._parse_rt_value(dad_row['RT'])
            dad_peak = dad_row['Peak']
            dad_area = dad_row['Area']
            dad_area_percent = dad_row['Area_Percent']
            
            # print(f"\n处理DAD峰 {dad_peak}, RT: {dad_rt if dad_rt is not None else 'N/A':.4g}, Area: {dad_area:.4g}")
            
            # 找到RT最接近的ESI峰
            best_esi_match = None
            min_rt_diff = float('inf')
            
            for esi_idx, esi_row in esi_info.iterrows():
                esi_rt = self._parse_rt_value(esi_row['RT'])
                
                if dad_rt is not None and esi_rt is not None:
                    rt_diff = abs(dad_rt - esi_rt)
                    if rt_diff < min_rt_diff:
                        min_rt_diff = rt_diff
                        best_esi_match = esi_row
            
            # 构建结果记录
            result_record = {
                'DAD_Peak': dad_peak,
                'RT': dad_row['RT'],
                'Area_Percent': dad_area_percent,
                'Wavelength': wavelength_used,
                'mz': None,
                'Abund': None,
                'RT_Diff': None
            }
            
            if best_esi_match is not None:
                result_record['mz'] = best_esi_match.get('mz', None)
                result_record['Abund'] = best_esi_match.get('Abund', None)
                result_record['RT_Diff'] = min_rt_diff
                
                # print(f"匹配到ESI峰: RT={best_esi_match['RT']}, mz={best_esi_match.get('mz', 'N/A')}, Abund={best_esi_match.get('Abund', 'N/A')}, RT差值={min_rt_diff:.4g}")
            else:
                print("未找到匹配的ESI峰")
            
            result_data.append(result_record)
        
        # 创建结果DataFrame
        if result_data:
            result_df = pd.DataFrame(result_data)
            
            # print(f"\nTop5色谱峰分析结果:")
            # print(result_df.to_string(index=False))
            
            return result_df
        else:
            print("未生成分析结果")
            return pd.DataFrame()
    
    def _parse_rt_value(self, rt_str) -> float:
        """
        解析RT字符串为数值，支持多种格式：
        - 单个数值: "20.284"
        - 范围: "3.549-3.871"
        - 逗号分隔的多个值: "0.763, 0.851-0.892"
        - 复杂组合: "1.690-1.772, 1.962"、"5.254, 5.337"
        - 包含省略号: "1.234...5.678" -> 去除"..."后处理
        
        Args:
            rt_str: RT字符串
            
        Returns:
            float: 所有数值的平均值，如果解析失败返回None
        """
        try:
            if isinstance(rt_str, (int, float)):
                return float(rt_str)
            
            rt_str = str(rt_str).strip()
            if not rt_str:
                return None
            
            # 去除字符串中的三个点
            rt_str = rt_str.replace('...', '')
            
            # 收集所有数值
            all_values = []
            
            # 按逗号分割
            comma_parts = [part.strip() for part in rt_str.split(',')]
            
            for part in comma_parts:
                if not part:
                    continue
                
                # 检查是否包含范围（短横线）
                if '-' in part:
                    # 处理范围，如 "3.549-3.871"
                    range_parts = part.split('-')
                    if len(range_parts) == 2:
                        try:
                            start = float(range_parts[0].strip())
                            end = float(range_parts[1].strip())
                            all_values.extend([start, end])
                        except ValueError:
                            print(f"无法解析范围: {part}")
                            continue
                else:
                    # 单个数值
                    try:
                        value = float(part)
                        all_values.append(value)
                    except ValueError:
                        print(f"无法解析数值: {part}")
                        continue
            
            # 计算平均值
            if all_values:
                avg_value = sum(all_values) / len(all_values)
                # print(f"RT解析: '{rt_str}' -> 数值{all_values} -> 平均值{avg_value:.4g}")
                return avg_value
            else:
                print(f"RT字符串中未找到有效数值: {rt_str}")
                return None
                
        except Exception as e:
            print(f"解析RT值失败: {rt_str}, 错误: {e}")
            return None
    
    
    def save_results_to_file_with_data(self, key_info: dict, top5_analysis=None, output_file: str = None):
        """
        将已提取的结果保存到文件（避免重复解析和计算）
        
        Args:
            key_info (dict): 已提取的关键信息
            top5_analysis (pd.DataFrame): 已计算的Top5分析结果，默认为None
            output_file (str): 输出文件路径，默认为None（自动生成）
        """
        if not output_file:
            base_name = os.path.splitext(os.path.basename(self.pdf_path))[0]
            output_file = f"{base_name}_extracted_data.txt"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"PDF文件: {self.pdf_path}\n")
            f.write("=" * 80 + "\n\n")
            
            # 写入BPC_Peaks表格信息
            if key_info["BPC_Peaks"] is not None:
                f.write("BPC_Peaks色谱峰信息:\n")
                f.write("-" * 50 + "\n")
                f.write(key_info["BPC_Peaks"].to_string(index=False))
                f.write("\n\n")
            else:
                f.write("未找到BPC_Peaks色谱峰信息\n\n")
            
            # 写入DAD_Peaks表格信息（210nm）
            if key_info.get("DAD_Peaks_210nm") is not None:
                f.write("DAD_Peaks色谱峰信息 (210nm波长):\n")
                f.write("-" * 50 + "\n")
                f.write(key_info["DAD_Peaks_210nm"].to_string(index=False))
                f.write("\n\n")
            else:
                f.write("未找到DAD_Peaks_210nm色谱峰信息\n\n")
            
            # 写入DAD_Peaks表格信息（254nm）
            if key_info.get("DAD_Peaks_254nm") is not None:
                f.write("DAD_Peaks色谱峰信息 (254nm波长):\n")
                f.write("-" * 50 + "\n")
                f.write(key_info["DAD_Peaks_254nm"].to_string(index=False))
                f.write("\n\n")
            else:
                f.write("未找到DAD_Peaks_254nm色谱峰信息\n\n")
            
            # 写入ESI信息
            if key_info["ESI_Info"] is not None and not key_info["ESI_Info"].empty:
                f.write("ESI质谱信息:\n")
                f.write("-" * 50 + "\n")
                
                # 创建ESI信息的副本用于格式化输出
                esi_info_formatted = key_info["ESI_Info"].copy()
                
                # 格式化spectrum_mz列为四位小数
                if 'spectrum_mz' in esi_info_formatted.columns:
                    esi_info_formatted['spectrum_mz'] = esi_info_formatted['spectrum_mz'].apply(
                        lambda x: f"{x:.4f}" if pd.notna(x) and isinstance(x, (int, float)) else x
                    )
                
                # 格式化线性插值参数列为四位小数
                for col in ['min_mz', 'max_mz', 'min_scale_x', 'max_scale_x']:
                    if col in esi_info_formatted.columns:
                        esi_info_formatted[col] = esi_info_formatted[col].apply(
                            lambda x: f"{x:.4f}" if pd.notna(x) and isinstance(x, (int, float)) else x
                        )
                
                f.write(esi_info_formatted.to_string(index=False))
                f.write("\n\n")
                
            else:
                f.write("未找到ESI质谱信息\n\n")
            
            # 使用已计算的Top5峰分析结果，或重新计算（如果未提供）
            if top5_analysis is None:
                top5_analysis = self.analyze_top5_peaks(key_info)
            
            if top5_analysis is not None and not top5_analysis.empty:
                f.write("Top5色谱峰综合分析结果:\n")
                f.write("-" * 50 + "\n")
                f.write(top5_analysis.to_string(index=False))
                f.write("\n\n")
                
                # 保存为CSV格式
                top5_csv_file = f"{os.path.splitext(output_file)[0]}_Top5_Analysis.csv"
                top5_analysis.to_csv(top5_csv_file, index=False, encoding='utf-8')
                f.write(f"Top5分析结果已保存到CSV文件: {top5_csv_file}\n\n")
            else:
                f.write("无法进行Top5峰分析\n\n")
        
        print(f"结果已保存到: {output_file}")
    
    def close(self):
        """关闭PDF文档"""
        if self.doc:
            self.doc.close()
            print("PDF文档已关闭")
        
        # 清理缓存
        self._page_text_cache.clear()
        self._page_drawings_cache.clear()


def main():
    """主函数 - 示例用法"""
    # PDF文件路径
    pdf_file = "zhongyao_qtof/qtoftest/20250912133754-z00101-E-1-4_Analysis.pdf"
    
    print("开始PDF解析测试...")
    print(f"目标文件: {pdf_file}")
    
    # 检查文件是否存在
    if not os.path.exists(pdf_file):
        print(f"文件不存在: {pdf_file}")
        return
    
    # 创建解析器实例
    parser = PDFParser(pdf_file)
    
    try:
        # 打开PDF
        if not parser.open_pdf():
            return
        
        print("\n" + "=" * 80)
        print("开始提取文本内容...")
        print("=" * 80)
        
        # 提取文本
        text_content = parser.extract_text()
        print(f"提取到 {len(text_content)} 行文本内容")
        
        print("\n" + "=" * 80)
        print("开始提取色谱峰关键信息...")
        print("=" * 80)
        
        # 提取关键信息
        key_info = parser.extract_key_info()
        
        print("\n" + "=" * 80)
        print("进行Top5峰综合分析...")
        print("=" * 80)
        
        # 进行Top5峰分析
        top5_results = parser.analyze_top5_peaks(key_info)
        
        print("\n" + "=" * 80)
        print("保存结果到文件...")
        print("=" * 80)
         
        # 保存结果到文件（传入已提取的数据，避免重复解析和计算）
        parser.save_results_to_file_with_data(key_info, top5_results)
        
    except Exception as e:
        print(f"解析过程中发生错误: {e}")
    
    finally:
        # 关闭PDF文档
        parser.close()


if __name__ == "__main__":
    main()

