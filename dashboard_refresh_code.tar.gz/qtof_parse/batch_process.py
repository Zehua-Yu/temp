#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量处理qtoftest文件夹中的PDF文件
提取Top5峰信息并生成汇总CSV文件
"""

import os
import pandas as pd
from .pdf_parser import PDFParser
from typing import List, Dict, Any
import traceback


class BatchPDFProcessor:
    """批量PDF处理器"""
    
    def __init__(self, root_folder: str):
        """
        初始化批量处理器
        
        Args:
            root_folder (str): 要处理的根文件夹路径
        """
        self.root_folder = root_folder
        self.results = []
        
    def find_pdf_files(self) -> List[str]:
        """
        递归查找所有PDF文件
        
        Returns:
            List[str]: PDF文件路径列表
        """
        pdf_files = []
        
        if not os.path.exists(self.root_folder):
            print(f"文件夹不存在: {self.root_folder}")
            return pdf_files
        
        print(f"开始搜索PDF文件: {self.root_folder}")
        
        for root, dirs, files in os.walk(self.root_folder):
            for file in files:
                if file.lower().endswith('.pdf'):
                    pdf_path = os.path.join(root, file)
                    pdf_files.append(pdf_path)
                    print(f"找到PDF文件: {pdf_path}")
        
        print(f"总共找到 {len(pdf_files)} 个PDF文件")
        return pdf_files
    
    def process_single_pdf(self, pdf_path: str) -> Dict[str, Any]:
        """
        处理单个PDF文件
        
        Args:
            pdf_path (str): PDF文件路径
            
        Returns:
            Dict[str, Any]: 处理结果
        """
        filename = os.path.basename(pdf_path)
        print(f"\n{'='*60}")
        print(f"正在处理: {filename}")
        print(f"{'='*60}")
        
        result = {
            'filename': filename,
            'filepath': pdf_path,
            'status': 'failed',
            'error': None,
            'top5_peaks': None
        }
        
        try:
            # 创建解析器实例
            parser = PDFParser(pdf_path)
            
            # 打开PDF
            if not parser.open_pdf():
                result['error'] = "无法打开PDF文件"
                return result
            
            # 提取文本
            text_content = parser.extract_text()
            if not text_content:
                result['error'] = "无法提取文本内容"
                parser.close()
                return result
            
            # 提取关键信息
            key_info = parser.extract_key_info()
            
            # 进行Top5峰分析
            top5_analysis = parser.analyze_top5_peaks(key_info)
            
            if not top5_analysis.empty:
                result['status'] = 'success'
                result['top5_peaks'] = top5_analysis
                print(f"成功提取Top5峰信息，共 {len(top5_analysis)} 个峰")
            else:
                result['error'] = "无法提取Top5峰信息"
                print("未能提取到Top5峰信息")
            
            # 关闭PDF
            parser.close()
            
        except Exception as e:
            result['error'] = str(e)
            print(f"处理PDF时发生错误: {e}")
            traceback.print_exc()
        
        return result
    
    def process_all_pdfs(self) -> pd.DataFrame:
        """
        批量处理所有PDF文件
        
        Returns:
            pd.DataFrame: 汇总结果
        """
        # 查找所有PDF文件
        pdf_files = self.find_pdf_files()
        
        if not pdf_files:
            print("没有找到PDF文件")
            return pd.DataFrame()
        
        # 处理每个PDF文件
        all_results = []
        
        for i, pdf_path in enumerate(pdf_files, 1):
            print(f"\n[{i}/{len(pdf_files)}] 处理进度")
            result = self.process_single_pdf(pdf_path)
            
            # 创建单行记录，包含Top5峰信息
            record = {
                'filename': result['filename'],
                'filepath': result['filepath']
            }
            
            if result['status'] == 'success' and result['top5_peaks'] is not None:
                # 处理Top5峰信息，每个峰作为一列
                top5_df = result['top5_peaks']
                
                # 为每个rank创建峰信息字符串
                for rank in range(1, 6):  # rank 1-5
                    if rank <= len(top5_df):
                        # 获取对应rank的峰数据
                        peak_data = top5_df.iloc[rank-1]
                        
                        # 格式化峰信息字符串
                        peak_info = self._format_peak_info(
                            peak_data.get('RT', ''),
                            peak_data.get('Area_Percent', ''),
                            peak_data.get('mz', ''),
                            peak_data.get('Abund', ''),
                            peak_data.get('RT_Diff', '')
                        )
                        record[f'rank{rank}_peak'] = peak_info
                    else:
                        # 如果没有足够的峰数据，填入空字符串
                        record[f'rank{rank}_peak'] = ''
            else:
                # 处理失败的记录，所有峰信息列填入空字符串
                for rank in range(1, 6):
                    record[f'rank{rank}_peak'] = ''
                record['error'] = result.get('error', '未知错误')
            
            all_results.append(record)
        
        # 创建汇总DataFrame
        if all_results:
            summary_df = pd.DataFrame(all_results)
            return summary_df
        else:
            return pd.DataFrame()
    
    def _format_peak_info(self, rt, area_percent, mz, abund, rt_diff):
        """
        格式化峰信息为字符串
        
        Args:
            rt: 保留时间
            area_percent: 面积百分比
            mz: 质荷比
            abund: 丰度
            rt_diff: 保留时间差异
            
        Returns:
            str: 格式化的峰信息字符串
        """
        # 确保所有值都是字符串，空值用空字符串替代
        rt_str = str(rt) if rt and str(rt) != 'nan' else ''
        area_percent_str = str(area_percent) if area_percent and str(area_percent) != 'nan' else ''
        mz_str = str(mz) if mz and str(mz) != 'nan' else ''
        abund_str = str(abund) if abund and str(abund) != 'nan' else ''
        rt_diff_str = str(rt_diff) if rt_diff and str(rt_diff) != 'nan' else ''
        
        # 按照指定格式组合信息
        # peak_info = f"rt: {rt_str}, area_percent: {area_percent_str}, mz: {mz_str}, abund: {abund_str}, rt_diff: {rt_diff_str}"
        peak_info = f"rt: {rt_str}, mz: {mz_str}"
        return peak_info
    
    def save_summary_csv(self, summary_df: pd.DataFrame, output_file: str = "qtof_top5_peaks_summary.csv"):
        """
        保存汇总结果到CSV文件
        
        Args:
            summary_df (pd.DataFrame): 汇总结果
            output_file (str): 输出文件名
        """
        if summary_df.empty:
            print("没有数据可保存")
            return
        
        try:
            summary_df.to_csv(output_file, index=False, encoding='utf-8-sig')
            print(f"\n汇总结果已保存到: {output_file}")
            print(f"总共处理了 {len(summary_df['filename'].unique())} 个PDF文件")
            print(f"成功提取峰信息的文件数: {len(summary_df[summary_df['peak_rank'] > 0]['filename'].unique())}")
            
            # 显示统计信息
            success_files = summary_df[summary_df['peak_rank'] > 0]['filename'].unique()
            failed_files = summary_df[summary_df['peak_rank'] == 0]['filename'].unique()
            
            print(f"\n成功处理的文件:")
            for filename in success_files:
                print(f"  - {filename}")
            
            if len(failed_files) > 0:
                print(f"\n处理失败的文件:")
                for filename in failed_files:
                    error_info = summary_df[summary_df['filename'] == filename]['error'].iloc[0]
                    print(f"  - {filename}: {error_info}")
            
        except Exception as e:
            print(f"保存CSV文件失败: {e}")


def main(pdf_url=None):
    """主函数"""
    # 获取pdf文件名
    from pathlib import Path
    name_without_ext = Path(pdf_url).stem  # .stem 自动去掉后缀并返回文件名主体

    # 设置要处理的文件夹路径
    qtoftest_folder = "/app4/downloads/"+ name_without_ext
    output_path = qtoftest_folder+"/qtof_top5_peaks_summary.csv"
    # 检查文件夹是否存在
    if not os.path.exists(qtoftest_folder):
        print(f"文件夹不存在: {qtoftest_folder}")
        print("请确保qtoftest文件夹存在并包含PDF文件")
        return
    
    print("=" * 80)
    print("QTOF PDF批量处理工具")
    print("=" * 80)
    
    # 创建批量处理器
    processor = BatchPDFProcessor(qtoftest_folder)
    
    try:
        # 批量处理所有PDF文件
        summary_results = processor.process_all_pdfs()
        
        # 保存汇总结果
        if not summary_results.empty:
            processor.save_summary_csv(summary_results, output_path)
            
            # 显示前几行结果预览
            print(f"\n结果预览（前10行）:")
            print(summary_results.head(10).to_string(index=False))
            return output_path
        else:
            print("没有生成任何结果")
            return None
    
    except Exception as e:
        print(f"批量处理过程中发生错误: {e}")
        traceback.print_exc()
        return None


if __name__ == "__main__":
    main()
