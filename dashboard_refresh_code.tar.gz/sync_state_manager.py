#!/usr/bin/env python3
"""
同步状态管理器
支持Redis和文件两种存储方式
"""

import os
import json
from typing import Dict, Any, Optional, List
from loguru import logger
from config import Config
from datetime import datetime

try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    logger.warning("Redis模块未安装，将使用文件存储")


class SyncStateManager:
    """同步状态管理器"""
    
    def __init__(self):
        """初始化状态管理器"""
        self.use_redis = Config.REDIS_ENABLED
        self.state_file = os.path.join(Config.LOCAL_DOWNLOAD_DIR, '.sync_state.json')
        
        if self.use_redis:
            if not REDIS_AVAILABLE:
                raise ImportError("Redis模块未安装，但配置要求使用Redis。请安装: pip install redis")
            
            self._init_redis()
            logger.info("使用Redis存储同步状态")
        else:
            logger.info("使用文件存储同步状态")
    
    def _init_redis(self):
        """初始化Redis连接"""
        try:
            # 构建连接参数
            redis_params = {
                'host': Config.REDIS_HOST,
                'port': Config.REDIS_PORT,
                'db': Config.REDIS_DB,
                'decode_responses': True
            }
            
            # 添加用户名和密码（如果配置了）
            if Config.REDIS_USERNAME:
                redis_params['username'] = Config.REDIS_USERNAME
            if Config.REDIS_PASSWORD:
                redis_params['password'] = Config.REDIS_PASSWORD
            
            self.redis_client = redis.Redis(**redis_params)
            
            # 测试连接
            self.redis_client.ping()
            logger.info(f"Redis连接成功: {Config.REDIS_HOST}:{Config.REDIS_PORT}")
        except Exception as e:
            logger.error(f"Redis连接失败: {e}")
            raise ConnectionError(f"Redis连接失败: {e}。请检查Redis配置和网络连接。")
    
    def _get_redis_key(self, key: str) -> str:
        """获取Redis键名"""
        return f"{Config.REDIS_KEY_PREFIX}:{key}"
    
    def load_sync_state(self) -> Dict[str, Any]:
        """加载同步状态（兼容性方法）"""
        if self.use_redis:
            return self._load_all_from_redis()
        else:
            return self._load_from_file()
    
    def save_sync_state(self, state: Dict[str, Any]):
        """保存同步状态（兼容性方法）"""
        if self.use_redis:
            self._save_all_to_redis(state)
        else:
            self._save_to_file(state)
    
    def _load_all_from_redis(self) -> Dict[str, Any]:
        """从Redis加载所有状态（兼容性方法）"""
        try:
            result = {}
            # 扫描所有处理器类型的键
            pattern = f"{Config.REDIS_KEY_PREFIX}:*:files:*"
            for key in self.redis_client.scan_iter(match=pattern):
                # 解析键格式: prefix:processor_type:files:file_hash
                parts = key.split(':')
                if len(parts) >= 4:
                    processor_type = parts[1]
                    file_hash = ':'.join(parts[3:])  # 支持文件名中的冒号
                    
                    data = self.redis_client.get(key)
                    if data:
                        sync_info = json.loads(data)
                        # 重构原始文件名
                        original_name = sync_info.get('original_name', file_hash)
                        result[original_name] = sync_info
            return result
        except Exception as e:
            logger.error(f"从Redis加载状态失败: {e}")
            return {}
    
    def _save_all_to_redis(self, state: Dict[str, Any]):
        """保存所有状态到Redis（兼容性方法）"""
        try:
            for file_name, sync_info in state.items():
                processor_type = sync_info.get('processor_type', 'unknown')
                self.set_file_sync_info(file_name, sync_info, processor_type)
        except Exception as e:
            logger.error(f"保存状态到Redis失败: {e}")
    
    def _load_from_file(self) -> Dict[str, Any]:
        """从文件加载状态"""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"从文件加载状态失败: {e}")
        return {}
    
    def _save_to_file(self, state: Dict[str, Any]):
        """保存状态到文件"""
        try:
            os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"保存状态到文件失败: {e}")
    
    def get_sync_info(self, object_name: str) -> Optional[Dict[str, Any]]:
        """获取特定文件的同步信息"""
        if self.use_redis:
            return self._get_file_sync_info_from_redis(object_name)
        else:
            state = self.load_sync_state()
            return state.get(object_name)
    
    def set_sync_info(self, object_name: str, sync_info: Dict[str, Any]):
        """设置特定文件的同步信息"""
        if self.use_redis:
            processor_type = sync_info.get('processor_type', 'unknown')
            self.set_file_sync_info(object_name, sync_info, processor_type)
        else:
            state = self.load_sync_state()
            state[object_name] = sync_info
            self.save_sync_state(state)
    
    def get_file_sync_info(self, file_name: str, processor_type: str = None) -> Optional[Dict[str, Any]]:
        """获取单个文件的同步信息
        
        Args:
            file_name: 文件名
            processor_type: 处理器类型，如果未提供则搜索所有类型
            
        Returns:
            同步信息字典或None
        """
        if self.use_redis:
            return self._get_file_sync_info_from_redis(file_name, processor_type)
        else:
            state = self.load_sync_state()
            return state.get(file_name)
    
    def set_file_sync_info(self, file_name: str, sync_info: Dict[str, Any], processor_type: str):
        """设置单个文件的同步信息
        
        Args:
            file_name: 文件名
            sync_info: 同步信息
            processor_type: 处理器类型
        """
        if self.use_redis:
            self._set_file_sync_info_to_redis(file_name, sync_info, processor_type)
        else:
            state = self.load_sync_state()
            state[file_name] = sync_info
            self.save_sync_state(state)
    
    def _get_file_sync_info_from_redis(self, file_name: str, processor_type: str = None) -> Optional[Dict[str, Any]]:
        """从Redis获取单个文件的同步信息"""
        try:
            if processor_type:
                # 直接查询指定处理器类型
                file_hash = self._get_file_hash(file_name)
                key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:files:{file_hash}"
                data = self.redis_client.get(key)
                if data:
                    return json.loads(data)
            else:
                # 搜索所有处理器类型
                file_hash = self._get_file_hash(file_name)
                pattern = f"{Config.REDIS_KEY_PREFIX}:*:files:{file_hash}"
                for key in self.redis_client.scan_iter(match=pattern):
                    data = self.redis_client.get(key)
                    if data:
                        return json.loads(data)
            return None
        except Exception as e:
            logger.error(f"从Redis获取文件同步信息失败: {e}")
            return None
    
    def _set_file_sync_info_to_redis(self, file_name: str, sync_info: Dict[str, Any], processor_type: str):
        """设置单个文件的同步信息到Redis"""
        try:
            file_hash = self._get_file_hash(file_name)
            key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:files:{file_hash}"
            
            # 添加原始文件名到同步信息中
            sync_info_with_name = sync_info.copy()
            sync_info_with_name['original_name'] = file_name
            sync_info_with_name['processor_type'] = processor_type
            
            self.redis_client.set(key, json.dumps(sync_info_with_name, ensure_ascii=False))
            
            # 设置过期时间（可选，比如30天）
            # self.redis_client.expire(key, 30 * 24 * 3600)
            
        except Exception as e:
            logger.error(f"设置文件同步信息到Redis失败: {e}")
    
    def _get_file_hash(self, file_name: str) -> str:
        """获取文件名的哈希值（用作Redis key的一部分）"""
        import hashlib
        return hashlib.md5(file_name.encode('utf-8')).hexdigest()
    
    def get_processor_files(self, processor_type: str) -> Dict[str, Dict[str, Any]]:
        """获取指定处理器类型的所有文件"""
        if self.use_redis:
            return self._get_processor_files_from_redis(processor_type)
        else:
            state = self.load_sync_state()
            return {k: v for k, v in state.items() if v.get('processor_type') == processor_type}
    
    def _get_processor_files_from_redis(self, processor_type: str) -> Dict[str, Dict[str, Any]]:
        """从Redis获取指定处理器类型的所有文件"""
        try:
            result = {}
            pattern = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:files:*"
            for key in self.redis_client.scan_iter(match=pattern):
                data = self.redis_client.get(key)
                if data:
                    sync_info = json.loads(data)
                    original_name = sync_info.get('original_name')
                    if original_name:
                        result[original_name] = sync_info
            return result
        except Exception as e:
            logger.error(f"从Redis获取处理器文件失败: {e}")
            return {}
    
    def remove_sync_info(self, object_name: str):
        """移除特定文件的同步信息"""
        if self.use_redis:
            self._remove_file_sync_info_from_redis(object_name)
        else:
            state = self.load_sync_state()
            if object_name in state:
                del state[object_name]
                self.save_sync_state(state)
    
    def _remove_file_sync_info_from_redis(self, file_name: str):
        """从Redis移除文件同步信息"""
        try:
            file_hash = self._get_file_hash(file_name)
            pattern = f"{Config.REDIS_KEY_PREFIX}:*:files:{file_hash}"
            deleted_count = 0
            for key in self.redis_client.scan_iter(match=pattern):
                self.redis_client.delete(key)
                deleted_count += 1
            if deleted_count > 0:
                logger.info(f"从Redis移除文件同步信息: {file_name} (删除{deleted_count}个键)")
        except Exception as e:
            logger.error(f"从Redis移除文件同步信息失败: {e}")
    
    def clear_sync_state(self):
        """清除所有同步状态"""
        if self.use_redis:
            try:
                pattern = f"{Config.REDIS_KEY_PREFIX}:*:files:*"
                keys = list(self.redis_client.scan_iter(match=pattern))
                if keys:
                    self.redis_client.delete(*keys)
                    logger.info(f"Redis同步状态已清除 (删除{len(keys)}个键)")
                else:
                    logger.info("Redis中没有同步状态需要清除")
            except Exception as e:
                logger.error(f"清除Redis状态失败: {e}")
        else:
            try:
                if os.path.exists(self.state_file):
                    os.remove(self.state_file)
                    logger.info("文件同步状态已清除")
            except Exception as e:
                logger.error(f"清除文件状态失败: {e}")
    
    def clear_processor_state(self, processor_type: str):
        """清除指定处理器类型的同步状态"""
        if self.use_redis:
            try:
                pattern = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:files:*"
                keys = list(self.redis_client.scan_iter(match=pattern))
                if keys:
                    self.redis_client.delete(*keys)
                    logger.info(f"Redis中{processor_type}处理器状态已清除 (删除{len(keys)}个键)")
                else:
                    logger.info(f"Redis中没有{processor_type}处理器状态需要清除")
            except Exception as e:
                logger.error(f"清除Redis处理器状态失败: {e}")
        else:
            state = self.load_sync_state()
            original_count = len(state)
            state = {k: v for k, v in state.items() if v.get('processor_type') != processor_type}
            self.save_sync_state(state)
            removed_count = original_count - len(state)
            logger.info(f"文件中{processor_type}处理器状态已清除 (移除{removed_count}个记录)")
    
    def get_storage_info(self) -> Dict[str, Any]:
        """获取存储信息"""
        return {
            'storage_type': 'redis' if self.use_redis else 'file',
            'redis_enabled': Config.REDIS_ENABLED,
            'redis_available': REDIS_AVAILABLE,
            'state_file': self.state_file if not self.use_redis else None,
            'redis_config': {
                'host': Config.REDIS_HOST,
                'port': Config.REDIS_PORT,
                'db': Config.REDIS_DB,
                'username': Config.REDIS_USERNAME,
                'password': '***' if Config.REDIS_PASSWORD else None,
                'key_prefix': Config.REDIS_KEY_PREFIX
            } if self.use_redis else None
        } 

    def set_file_sync_success(self, file_name: str, source_prefix: str, processor_type: str, table_name: str):
        """设置文件同步成功标记（简化版本）
        
        Args:
            file_name: 文件名
            source_prefix: 数据源前缀
            processor_type: 处理器类型
            table_name: 目标表名
        """
        if self.use_redis:
            self._set_file_success_to_redis(file_name, source_prefix, processor_type, table_name)
        else:
            # 文件存储模式仍保持原有逻辑
            state = self.load_sync_state()
            state[file_name] = {
                'synced_at': datetime.now().isoformat(),
                'source_prefix': source_prefix,
                'processor_type': processor_type,
                'table_name': table_name,
                'status': 'success'
            }
            self.save_sync_state(state)
    
    def check_file_sync_success(self, file_name: str, source_prefix: str, processor_type: str, table_name: str) -> bool:
        """检查文件是否已成功同步（简化版本）
        
        Args:
            file_name: 文件名
            source_prefix: 数据源前缀
            processor_type: 处理器类型
            table_name: 目标表名
            
        Returns:
            True表示已成功同步，False表示需要处理
        """
        if self.use_redis:
            return self._check_file_success_in_redis(file_name, source_prefix, processor_type, table_name)
        else:
            # 文件存储模式检查
            state = self.load_sync_state()
            file_info = state.get(file_name)
            return (file_info is not None 
                    and file_info.get('status') == 'success'
                    and file_info.get('source_prefix') == source_prefix
                    and file_info.get('processor_type') == processor_type
                    and file_info.get('table_name') == table_name)
    
    def _set_file_success_to_redis(self, file_name: str, source_prefix: str, processor_type: str, table_name: str):
        """在Redis中设置文件成功标记"""
        try:
            file_hash = self._get_file_hash(file_name)
            # 简化的键格式：只包含处理器类型和文件标志
            key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}"
            
            # 只保存简单的成功标记
            self.redis_client.set(key, "1")
            
        except Exception as e:
            logger.error(f"设置文件成功标记到Redis失败: {e}")
    
    def _check_file_success_in_redis(self, file_name: str, source_prefix: str, processor_type: str, table_name: str) -> bool:
        """在Redis中检查文件成功标记"""
        try:
            file_hash = self._get_file_hash(file_name)
            key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}"
            
            # 检查键是否存在且值为"1"
            value = self.redis_client.get(key)
            return value == "1"
            
        except Exception as e:
            logger.error(f"从Redis检查文件成功标记失败: {e}")
            return False

    def check_file_needs_sync(self, file_name: str, source_prefix: str, processor_type: str, table_name: str, 
                             current_etag: str = None, current_size: int = None, current_last_modified: str = None) -> bool:
        """检查文件是否需要同步（基于ETag和其他属性）
        
        Args:
            file_name: 文件名
            source_prefix: 数据源前缀
            processor_type: 处理器类型  
            table_name: 目标表名
            current_etag: 当前文件的ETag
            current_size: 当前文件大小
            current_last_modified: 当前文件修改时间
            
        Returns:
            True表示需要同步，False表示不需要
        """
        if self.use_redis:
            return self._check_file_needs_sync_in_redis(file_name, source_prefix, processor_type, table_name,
                                                       current_etag, current_size, current_last_modified)
        else:
            # 文件存储模式 - 回退到简单的成功标记检查
            return not self.check_file_sync_success(file_name, source_prefix, processor_type, table_name)

    def _check_file_needs_sync_in_redis(self, file_name: str, source_prefix: str, processor_type: str, table_name: str,
                                       current_etag: str = None, current_size: int = None, current_last_modified: str = None) -> bool:
        """在Redis中检查文件是否需要同步"""
        try:
            file_hash = self._get_file_hash(file_name)
            key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}"
            
            # 获取存储的文件信息
            stored_data = self.redis_client.get(key)
            if not stored_data:
                # 没有记录，需要同步
                return True
            
            # 简化版本只存储"1"，需要向后兼容
            if stored_data == "1":
                # 旧版本简化格式，如果有ETag信息则需要升级检查
                if current_etag:
                    logger.debug(f"检测到简化格式存储，但提供了ETag，建议升级到详细格式: {file_name}")
                # 简化格式认为已同步
                return False
            
            try:
                # 尝试解析为JSON格式（详细信息）
                stored_info = json.loads(stored_data)
                
                # 检查ETag - 最重要的变化检测
                if current_etag and stored_info.get('etag'):
                    if current_etag != stored_info.get('etag'):
                        logger.info(f"文件内容已变化（ETag不同）: {file_name}")
                        logger.debug(f"  存储ETag: {stored_info.get('etag')}")
                        logger.debug(f"  当前ETag: {current_etag}")
                        return True
                
                # 检查文件大小
                if current_size is not None and stored_info.get('size') is not None:
                    if current_size != stored_info.get('size'):
                        logger.info(f"文件大小已变化: {file_name}")
                        logger.debug(f"  存储大小: {stored_info.get('size')}")
                        logger.debug(f"  当前大小: {current_size}")
                        return True
                
                # 检查修改时间
                if current_last_modified and stored_info.get('last_modified'):
                    if current_last_modified != stored_info.get('last_modified'):
                        logger.debug(f"文件修改时间已变化: {file_name}")
                        # 注意：修改时间变化不一定需要重新同步，因为可能只是时间戳变化
                        # 这里只记录日志，最终决定还是基于ETag
                
                # 所有检查都通过，不需要同步
                return False
                
            except json.JSONDecodeError:
                # 不是JSON格式，可能是其他格式，保守起见认为需要同步
                logger.warning(f"无法解析存储的文件信息格式: {file_name}")
                return True
            
        except Exception as e:
            logger.error(f"从Redis检查文件同步需求失败: {e}")
            # 出错时保守起见，认为需要同步
            return True

    def set_file_sync_success_with_details(self, file_name: str, source_prefix: str, processor_type: str, table_name: str,
                                          etag: str = None, size: int = None, last_modified: str = None, 
                                          processing_stats: Dict = None):
        """设置文件同步成功标记（包含详细信息）
        
        Args:
            file_name: 文件名
            source_prefix: 数据源前缀
            processor_type: 处理器类型
            table_name: 目标表名
            etag: 文件ETag
            size: 文件大小
            last_modified: 文件修改时间
            processing_stats: 处理统计信息
        """
        if self.use_redis:
            self._set_file_success_with_details_to_redis(file_name, source_prefix, processor_type, table_name,
                                                        etag, size, last_modified, processing_stats)
        else:
            # 文件存储模式
            state = self.load_sync_state()
            state[file_name] = {
                'synced_at': datetime.now().isoformat(),
                'source_prefix': source_prefix,
                'processor_type': processor_type,
                'table_name': table_name,
                'status': 'success',
                'etag': etag,
                'size': size,
                'last_modified': last_modified,
                'processing_stats': processing_stats
            }
            self.save_sync_state(state)

    def _set_file_success_with_details_to_redis(self, file_name: str, source_prefix: str, processor_type: str, table_name: str,
                                               etag: str = None, size: int = None, last_modified: str = None,
                                               processing_stats: Dict = None):
        """在Redis中设置文件成功标记（包含详细信息）"""
        try:
            file_hash = self._get_file_hash(file_name)
            key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}"
            
            # 构建详细信息
            detailed_info = {
                'synced_at': datetime.now().isoformat(),
                'source_prefix': source_prefix,
                'table_name': table_name,
                'status': 'success',
                'original_name': file_name  # 保存原始文件名，便于调试
            }
            
            # 添加MinIO对象属性
            if etag:
                detailed_info['etag'] = etag
            if size is not None:
                detailed_info['size'] = size  
            if last_modified:
                detailed_info['last_modified'] = last_modified
            if processing_stats:
                detailed_info['processing_stats'] = processing_stats
            
            # 保存到Redis
            self.redis_client.set(key, json.dumps(detailed_info))
            logger.debug(f"已保存文件详细同步信息: {file_name} (ETag: {etag})")
            
        except Exception as e:
            logger.error(f"设置文件详细成功标记到Redis失败: {e}")
    
    def remove_file_success_mark(self, file_name: str, source_prefix: str = None, processor_type: str = None, table_name: str = None):
        """移除文件成功标记
        
        Args:
            file_name: 文件名
            source_prefix: 数据源前缀，如果为None则删除所有匹配的前缀
            processor_type: 处理器类型，如果为None则删除所有类型
            table_name: 目标表名，如果为None则删除所有表
        """
        if self.use_redis:
            self._remove_file_success_from_redis(file_name, source_prefix, processor_type, table_name)
        else:
            # 文件存储模式
            state = self.load_sync_state()
            if file_name in state:
                del state[file_name]
                self.save_sync_state(state)
    
    def _remove_file_success_from_redis(self, file_name: str, source_prefix: str = None, processor_type: str = None, table_name: str = None):
        """从Redis移除文件成功标记"""
        try:
            file_hash = self._get_file_hash(file_name)
            
            if processor_type:
                # 删除指定处理器类型的标记
                key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}"
                self.redis_client.delete(key)
            else:
                # 删除所有处理器类型的标记
                pattern = f"{Config.REDIS_KEY_PREFIX}:*:{file_hash}"
                keys = list(self.redis_client.scan_iter(match=pattern))
                if keys:
                    self.redis_client.delete(*keys)
                    
        except Exception as e:
            logger.error(f"从Redis移除文件成功标记失败: {e}")
    
    def clear_all_success_marks(self, source_prefix: str = None, processor_type: str = None, table_name: str = None):
        """清除成功标记
        
        Args:
            source_prefix: 数据源前缀（忽略，保持API兼容性）
            processor_type: 处理器类型，如果为None则清除所有类型
            table_name: 目标表名（忽略，保持API兼容性）
        """
        if self.use_redis:
            try:
                if processor_type:
                    pattern = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:*"
                else:
                    pattern = f"{Config.REDIS_KEY_PREFIX}:*"
                    
                keys = list(self.redis_client.scan_iter(match=pattern))
                if keys:
                    self.redis_client.delete(*keys)
                    logger.info(f"Redis中清除了{len(keys)}个成功标记")
                else:
                    logger.info("Redis中没有匹配的成功标记需要清除")
                    
            except Exception as e:
                logger.error(f"清除Redis成功标记失败: {e}")
        else:
            # 文件存储模式保持原有逻辑
            if processor_type:
                state = self.load_sync_state()
                original_count = len(state)
                state = {k: v for k, v in state.items() 
                        if not (v.get('processor_type') == processor_type 
                               and (not source_prefix or v.get('source_prefix') == source_prefix)
                               and (not table_name or v.get('table_name') == table_name))}
                self.save_sync_state(state)
                removed_count = original_count - len(state)
                logger.info(f"文件中清除了{removed_count}个匹配的成功标记")
            else:
                self.clear_sync_state()
    
    def get_success_stats(self) -> Dict[str, Any]:
        """获取成功标记统计信息"""
        if self.use_redis:
            try:
                pattern = f"{Config.REDIS_KEY_PREFIX}:*"
                keys = list(self.redis_client.scan_iter(match=pattern))
                
                # 按处理器类型分组统计
                stats = {}
                for key in keys:
                    parts = key.split(':')
                    if len(parts) >= 3:  # prefix:processor_type:file_hash
                        processor_type = parts[1]
                        stats[processor_type] = stats.get(processor_type, 0) + 1
                
                return {
                    'storage_type': 'redis',
                    'total_success_files': len(keys),
                    'by_processor_type': stats
                }
            except Exception as e:
                logger.error(f"获取Redis成功标记统计失败: {e}")
                return {'storage_type': 'redis', 'error': str(e)}
        else:
            state = self.load_sync_state()
            success_files = {k: v for k, v in state.items() if v.get('status') == 'success'}
            
            # 按处理器类型分组统计
            stats = {}
            for file_info in success_files.values():
                processor_type = file_info.get('processor_type', 'unknown')
                stats[processor_type] = stats.get(processor_type, 0) + 1
            
            return {
                'storage_type': 'file',
                'total_success_files': len(success_files),
                'by_processor_type': stats
            } 

    def check_file_needs_sync_with_etag(self, file_name: str, processor_type: str, 
                                       current_etag: str = None, current_size: int = None) -> bool:
        """检查文件是否需要同步（优化版本：基于文件名+ETag）
        
        Args:
            file_name: 文件名（包含完整路径）
            processor_type: 处理器类型
            current_etag: 当前文件的ETag
            current_size: 当前文件大小（可选，用于额外验证）
            
        Returns:
            True表示需要同步，False表示不需要
        """
        if not current_etag:
            # 没有ETag信息，保守起见认为需要同步
            logger.debug(f"没有ETag信息，需要同步: {file_name}")
            return True
        
        if self.use_redis:
            return self._check_file_needs_sync_with_etag_in_redis(file_name, processor_type, current_etag, current_size)
        else:
            # 文件存储模式暂时回退到文件名检查
            state = self.load_sync_state()
            file_info = state.get(file_name)
            if not file_info:
                return True
            
            stored_etag = file_info.get('etag')
            if stored_etag and stored_etag != current_etag:
                logger.info(f"文件内容已变化（ETag不同）: {file_name}")
                return True
            
            return False

    def _check_file_needs_sync_with_etag_in_redis(self, file_name: str, processor_type: str, 
                                                 current_etag: str, current_size: int = None) -> bool:
        """在Redis中检查文件是否需要同步（基于文件名+ETag）"""
        try:
            file_hash = self._get_file_hash(file_name)
            
            # 新的键格式：processor_type:file_hash:etag
            current_key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}:{current_etag}"
            
            # 检查当前ETag的键是否存在
            if self.redis_client.exists(current_key):
                logger.debug(f"文件未变化，跳过同步: {file_name} (ETag: {current_etag})")
                return False
            
            # 检查是否存在其他ETag版本的键（表示文件内容已变化）
            pattern = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}:*"
            existing_keys = list(self.redis_client.scan_iter(match=pattern))
            
            if existing_keys:
                # 存在其他ETag版本，说明文件内容已变化
                logger.info(f"检测到文件内容变化: {file_name}")
                logger.debug(f"  当前ETag: {current_etag}")
                logger.debug(f"  已存在版本数: {len(existing_keys)}")
                
                # 可选：清理旧版本的键（保持Redis整洁）
                for old_key in existing_keys:
                    self.redis_client.delete(old_key)
                    logger.debug(f"  清理旧版本键: {old_key}")
                
                return True
            
            # 没有任何记录，需要同步
            logger.debug(f"首次处理文件: {file_name}")
            return True
            
        except Exception as e:
            logger.error(f"从Redis检查文件同步需求失败: {e}")
            return True

    def set_file_sync_success_with_etag(self, file_name: str, processor_type: str,
                                       etag: str, size: int = None, processing_stats: Dict = None):
        """设置文件同步成功标记（基于文件名+ETag）
        
        Args:
            file_name: 文件名（包含完整路径）
            processor_type: 处理器类型
            etag: 文件ETag
            size: 文件大小
            processing_stats: 处理统计信息
        """
        if not etag:
            logger.warning(f"没有ETag信息，使用简化方式保存: {file_name}")
            # 回退到旧方式
            self.set_file_sync_success(file_name, "", processor_type, "")
            return
        
        if self.use_redis:
            self._set_file_success_with_etag_to_redis(file_name, processor_type, etag, size, processing_stats)
        else:
            # 文件存储模式
            state = self.load_sync_state()
            state[file_name] = {
                'synced_at': datetime.now().isoformat(),
                'processor_type': processor_type,
                'status': 'success',
                'etag': etag,
                'size': size,
                'processing_stats': processing_stats
            }
            self.save_sync_state(state)

    def _set_file_success_with_etag_to_redis(self, file_name: str, processor_type: str,
                                           etag: str, size: int = None, processing_stats: Dict = None):
        """在Redis中设置文件成功标记（基于文件名+ETag）"""
        try:
            file_hash = self._get_file_hash(file_name)
            
            # 键格式：processor_type:file_hash:etag
            key = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}:{etag}"
            
            # 只保存简单的成功标记，键的存在就表示已成功处理
            self.redis_client.set(key, "1")
            logger.debug(f"已保存文件同步标记: {file_name} (ETag: {etag})")
            
        except Exception as e:
            logger.error(f"设置文件ETag成功标记到Redis失败: {e}")

    def get_file_sync_history(self, file_name: str, processor_type: str) -> List[str]:
        """获取文件的同步历史记录（所有ETag版本）
        
        Args:
            file_name: 文件名
            processor_type: 处理器类型
            
        Returns:
            ETag列表
        """
        if not self.use_redis:
            return []
        
        try:
            file_hash = self._get_file_hash(file_name)
            pattern = f"{Config.REDIS_KEY_PREFIX}:{processor_type}:{file_hash}:*"
            
            etags = []
            for key in self.redis_client.scan_iter(match=pattern):
                # 从键中提取ETag (格式: prefix:processor_type:file_hash:etag)
                parts = key.split(':')
                if len(parts) >= 4:
                    etag = ':'.join(parts[3:])  # 支持ETag中包含冒号的情况
                    etags.append(etag)
            
            return etags
            
        except Exception as e:
            logger.error(f"获取文件同步历史失败: {e}")
            return [] 