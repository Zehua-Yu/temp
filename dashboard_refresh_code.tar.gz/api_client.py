#!/usr/bin/env python3
"""
API客户端模块 - 参考飞书多维表格API格式
"""

import json
import requests
from typing import Dict, Any, List, Optional
from loguru import logger
from config import Config


class APIClient:
    """API客户端类 - 参考飞书多维表格API格式"""
    
    def __init__(self):
        """初始化API客户端"""
        self.base_url = Config.API_BASE_URL
        self.api_key = Config.API_KEY
        self.timeout = Config.API_TIMEOUT
        
        # 设置请求头 - 参考飞书API格式
        self.headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
            'User-Agent': 'MinIO-Sync-Service/1.0'
        }
    
    def _make_request(self, method: str, endpoint: str, data: Dict = None, params: Dict = None) -> Dict:
        """
        发送HTTP请求
        
        Args:
            method: HTTP方法
            endpoint: API端点
            data: 请求数据
            params: 查询参数
            
        Returns:
            响应数据
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self.headers,
                json=data,
                params=params,
                timeout=self.timeout
            )
            
            # 记录请求和响应信息
            logger.debug(f"API请求: {method} {url}")
            if data:
                logger.debug(f"请求数据: {data}")
            
            response.raise_for_status()
            result = response.json()
            
            logger.debug(f"API响应: {result}")
            return result
            
        except requests.exceptions.RequestException as e:
            error_msg = f"API请求失败: {e}"
            if hasattr(e, 'response') and e.response is not None:
                error_msg += f" - 错误响应: {e.response.text}"
            raise Exception(error_msg)
    
    def create_record(self, table_name: str, data: Dict[str, Any]) -> Dict:
        """
        创建记录 - 参考飞书多维表格API
        
        Args:
            table_name: 表名
            data: 数据字典
            
        Returns:
            创建结果
        """
        # 实际API格式: POST /api/{table_name}:create
        endpoint = f"/api/{table_name}:create"
        
        try:
            # 直接发送数据，不需要fields包装
            result = self._make_request('POST', endpoint, data=data)
            logger.info(f"成功创建记录到表 {table_name}")
            return result
        except Exception as e:
            # 保留原始错误信息
            raise Exception(f"创建记录失败: {e}")
    
    def update_record(self, table_name: str, record_id: str, data: Dict[str, Any]) -> Dict:
        """
        更新记录 - 参考飞书多维表格API
        
        Args:
            table_name: 表名
            record_id: 记录ID
            data: 更新数据
            
        Returns:
            更新结果
        """
        # 实际API格式: POST /api/{table_name}:update
        endpoint = f"/api/{table_name}:update"
        
        try:
            # filterByTk作为查询参数，数据作为请求体
            params = {'filterByTk': record_id}
            
            result = self._make_request('POST', endpoint, data=data, params=params)
            logger.info(f"成功更新记录 {record_id} 到表 {table_name}")
            return result
        except Exception as e:
            logger.error(f"更新记录失败: {e}")
            raise
    
    def get_record(self, table_name: str, record_id: str) -> Optional[Dict]:
        """
        获取记录 - 参考飞书多维表格API
        
        Args:
            table_name: 表名
            record_id: 记录ID
            
        Returns:
            记录数据，如果不存在则返回None
        """
        # 实际API格式: GET /api/{table_name}:get
        endpoint = f"/api/{table_name}:get"
        
        try:
            params = {'id': record_id}
            result = self._make_request('GET', endpoint, params=params)
            # 实际API响应格式: {"data": {...}}
            return result.get('data')
        except Exception as e:
            logger.error(f"获取记录失败: {e}")
            return None
    
    def list_records(self, table_name: str, filters: Dict = None, limit: int = 100) -> List[Dict]:
        """
        列出记录 - 参考飞书多维表格API
        
        Args:
            table_name: 表名
            filters: 过滤条件
            limit: 限制数量
            
        Returns:
            记录列表
        """
        # 实际API格式: GET /api/{table_name}:list
        endpoint = f"/api/{table_name}:list"
        params = {'page_size': limit}
        
        if filters:
            # 直接添加过滤参数
            params.update(filters)
        
        try:
            result = self._make_request('GET', endpoint, params=params)
            # 实际API响应格式: {"data": [...]} 或 {"data": None}
            data = result.get('data')
            return data if data is not None else []
        except Exception as e:
            logger.error(f"列出记录失败: {e}")
            return []
    
    def delete_record(self, table_name: str, record_id: str) -> bool:
        """
        删除记录 - 参考飞书多维表格API
        
        Args:
            table_name: 表名
            record_id: 记录ID
            
        Returns:
            是否删除成功
        """
        # 实际API格式: POST /api/{table_name}:delete
        endpoint = f"/api/{table_name}:delete"
        
        try:
            data = {'id': record_id}
            result = self._make_request('POST', endpoint, data=data)
            logger.info(f"成功删除记录 {record_id} 从表 {table_name}")
            return True
        except Exception as e:
            logger.error(f"删除记录失败: {e}")
            return False
    
    def batch_create_records(self, table_name: str, records: List[Dict[str, Any]], unique_fields: List[str] = None) -> Dict[str, int]:
        """
        批量创建记录 - 优先插入，失败时尝试更新
        
        Args:
            table_name: 表名
            records: 记录列表
            unique_fields: 唯一字段列表，用于更新操作
            
        Returns:
            包含成功创建和更新数量的字典
        """
        # 实际API格式: 逐个创建记录
        # 由于没有批量创建端点，我们逐个创建
        
        try:
            # 逐个创建记录
            created_count = 0
            updated_count = 0
            
            for i, record in enumerate(records):
                try:
                    # 跳过None值（可能是由去重逻辑产生的）
                    if record is None:
                        logger.debug(f"跳过None记录 (索引 {i+1})")
                        continue
                        
                    # 清理特殊标记字段（创建时不需要）
                    create_data = record.copy()
                    if '_update_start_time' in create_data:
                        create_data.pop('_update_start_time')
                    
                    # 优先尝试创建
                    self.create_record(table_name, create_data)
                    created_count += 1
                    logger.debug(f"批量处理进度: 创建 {created_count}, 更新 {updated_count}, 总计 {i+1}/{len(records)}")
                except Exception as create_error:
                    # 创建失败，检查是否是主键冲突
                    error_msg = str(create_error).lower()
                    logger.debug(f"创建失败，错误信息: {error_msg}")
                    if unique_fields and ("already exists" in error_msg or "duplicate" in error_msg or "conflict" in error_msg):
                        # 尝试更新现有记录
                        try:
                            # 跳过None值（可能是由去重逻辑产生的）
                            if record is None:
                                logger.debug(f"跳过None记录查询 (索引 {i+1})")
                                continue
                                
                            # 构建查询条件
                            query_params = {}
                            for field in unique_fields:
                                if field in record:
                                    query_params[field] = record[field]
                            
                            if query_params:
                                # 查找现有记录
                                filter_params = {'filter': json.dumps(query_params)}
                                existing_records = self.list_records(table_name, filter_params)
                                
                                if existing_records:
                                    # 更新现有记录 - 使用唯一字段作为ID
                                    existing_record = existing_records[0]
                                    # 优先使用第一个唯一字段的值作为记录ID
                                    record_id = None
                                    if unique_fields:
                                        for unique_field in unique_fields:
                                            record_id = existing_record.get(unique_field)
                                            if record_id:
                                                break
                                    
                                    # 处理时间字段的特殊更新逻辑
                                    # 跳过None值（可能是由去重逻辑产生的）
                                    if record is None:
                                        logger.debug(f"跳过None记录更新 (索引 {i+1})")
                                        continue
                                        
                                    update_data = record.copy()
                                    
                                    # 检查是否需要特殊处理 start_datetime
                                    if '_update_start_time' in update_data:
                                        update_start_time = update_data.pop('_update_start_time')
                                        if not update_start_time and 'start_datetime' in update_data:
                                            # 不更新 start_datetime，保持原有值
                                            update_data.pop('start_datetime')
                                            logger.debug(f"保持原有 start_datetime，只更新 stop_datetime")
                                    
                                    if record_id and self.update_record(table_name, record_id, update_data):
                                        updated_count += 1
                                        logger.debug(f"更新记录成功: {record_id} (使用字段: {unique_field})")
                                        continue
                        
                        except Exception as update_error:
                            logger.error(f"更新记录失败: {update_error}")
                    
                    # 如果更新也失败，记录错误
                    logger.error(f"批量处理失败 (记录 {i+1}): 创建失败 {create_error}")
            
            logger.info(f"批量处理完成: 创建 {created_count}, 更新 {updated_count}, 总计 {len(records)}")
            return {
                'created': created_count,
                'updated': updated_count,
                'total': len(records)
            }
            return success_count
            
        except Exception as e:
            logger.error(f"批量创建失败: {e}")
            return 0
    
    def check_duplicate(self, table_name: str, unique_fields: List[str], data: Dict[str, Any]) -> Optional[str]:
        """
        检查重复记录 - 参考飞书多维表格API
        
        Args:
            table_name: 表名
            unique_fields: 唯一字段列表
            data: 数据字典
            
        Returns:
            重复记录的ID，如果没有重复则返回None
        """
        # 构建查询条件
        filters = {}
        for field in unique_fields:
            if field in data:
                filters[field] = data[field]
        
        if not filters:
            return None
        
        try:
            records = self.list_records(table_name, filters=filters, limit=1)
            if records:
                # 实际API记录格式: {"id": "xxx", ...}
                return records[0].get('id')
            return None
        except Exception as e:
            logger.error(f"检查重复记录失败: {e}")
            return None 