# Digital Dashboard Data Refresh Service

本说明对应项目中的看板数据自动刷写代码。它用于从 MinIO 中定时读取各实验工站导出的 CSV 报告，清洗和映射字段后写入业务平台 API 表，供数字化前端看板展示。当前配置每 5 分钟检查一次数据源。

## 代码用途

这套代码解决的是“仪器/工站产生数据后，自动进入前端看板”的问题。

主要能力：

- 从 MinIO bucket 中按路径前缀扫描 CSV 报告。
- 根据 `SYNC_SOURCES` 配置选择目标表和处理器。
- 校验 CSV 表头，逐行清洗字段，生成稳定记录 ID。
- 支持多类数据源：摇床、离心过滤、离心浓缩、高压/中压制备、QTOF、通用移液、萃取物合并/稀释、打管称重等。
- 对重复文件使用 Redis ETag 状态跳过，避免每轮重复刷写。
- 写入业务平台 API，创建失败且识别为重复记录时自动更新。
- QTOF 数据会额外运行 LCMS 分析，生成 HTML 报告地址并写入 `analyse_address`。

## 相关文件

| 文件/目录 | 作用 |
|---|---|
| `main.py` | 程序入口，加载环境变量，启动同步循环和报告服务 |
| `sync_scheduler.py` | 守护进程模式下的定时调度器 |
| `file_sync.py` | MinIO 文件扫描、下载、ETag 状态判断、同步统计 |
| `data_processor.py` | CSV 校验、行处理、批量上传调度 |
| `data_mapping.py` | 各类数据源 Processor，定义字段映射、清洗、聚合和动态字段 |
| `api_client.py` | 业务平台 API 客户端，负责 create/update/list/delete |
| `minio_client.py` | MinIO 客户端封装 |
| `sync_state_manager.py` | Redis/文件方式保存已处理文件状态 |
| `config.py` | 环境变量配置入口 |
| `report_server.py` | QTOF HTML 分析报告静态服务 |
| `downloadpdf.py` | QTOF UNC 路径翻译、PDF 和 `.d` 目录复制 |
| `qtof_parse/` | QTOF PDF 解析相关代码 |
| `raw_data_extractor/` | QTOF 原始数据分析相关代码 |

## 工作原理

整体数据流：

```text
MinIO CSV
  -> FileSyncService.sync_files()
  -> FileSyncService.sync_specific_source()
  -> DataProcessor.process_csv_file()
  -> 具体 Processor.clean_data()
  -> APIClient.batch_create_records()
  -> POST /api/{table}:create 或 POST /api/{table}:update
  -> 前端看板读取业务平台表数据
```

每轮同步做以下事情：

1. `main.py --sync` 启动后进入循环，默认每 `SYNC_INTERVAL=300` 秒执行一次。
2. `FileSyncService` 读取 `SYNC_SOURCES`，得到一个或多个同步源。
3. 对每个同步源，调用 MinIO 列出匹配前缀下的 CSV 对象。
4. 读取对象的 ETag 和 size，与 Redis 中已成功同步的状态比较。
5. 未处理或文件已变化时，下载 CSV 到 `LOCAL_DOWNLOAD_DIR`。
6. `DataProcessor` 根据 `processor_type` 动态创建对应 Processor。
7. Processor 负责字段映射、字段清洗、ID 生成、去重、聚合和时间字段生成。
8. API 客户端逐条创建记录；如果创建失败且是重复/冲突，则按唯一字段查找后更新。
9. 文件处理完全成功后，把 ETag 写入 Redis，下次文件未变化就跳过。
10. 本地临时 CSV 会被删除。

## 支持的数据源

处理器类型由 `SYNC_SOURCES` 第三个字段决定，格式是：

```text
MinIO对象路径前缀:目标业务表名:处理器类型
```

例如：

```text
REALITY/REPORT/yc/yc_report:sample_new:yc
```

当前代码支持以下处理器：

| processor_type | 处理器类 | 常见用途 | 主要刷写字段 |
|---|---|---|---|
| `yc` | `YCProcessor` | 摇床实验数据 | `id`, `sample_id`, `process_id`, `start_datetime`, `stop_datetime` |
| `chemist` | `ChemistProcessor` | 旧摇床/化学家数据 | `shake_flask_id`, `shake_flask_code`, `shake_flask_sample_info`, `shaking_speed`, `Extraction_temperature`, `Extraction_duration`, `start_time`, `stop_time` |
| `lxgl` | `LXGLProcessor` | 离心过滤 | `id`, `sample_id`, `bottle_tag`, `process_id`, `start_datetime`, `stop_datetime` |
| `lxns` | `LXNSProcessor` | 离心浓缩 | `sample`, `ves_id`, `tray_id`, `method`, `start_time`, `stop_time`, `device_id`, `process_id`, `id` |
| `gfsy` | `GFSYProcessor` | 固方试验/GFSY | `nsp_id`, `concentration_ves_code`, `sample`, `mix_times`, `motor_speed`, `xz_time`, `work_temp`, `rota_dis`, `delay_time`, `vac_var`, `start_time`, `stop_time` |
| `gyzb` | `GYZBProcessor` | 高压制备/HPLC | `id`, `sample_id`, `bottle_tag`, `gy_report`, `process_id`, `start_datetime`, `stop_datetime` |
| `zyzb` | `ZYZBProcessor` | 中压制备/MPLC | `id`, `sample_id`, `bottle_tag`, `zy_report`, `process_id`, `start_datetime`, `stop_datetime` |
| `lcms` | `LCMSProcessor` | QTOF/LCMS | `id`, `sample_id`, `qtof_report`, `data_address`, `bk_report`, `bk_data`, `process_id`, `analyse_address`, `start_datetime`, `stop_datetime` |
| `tyyy` | `TYYYProcessor` | 通用移液/分液 | `id`, `sample_id`, `bottle_tag`, `process_id`, `sample_storage1-6`, `save_amount1-6`, `start_datetime`, `stop_datetime` |
| `zycwhb` | `ZYCWHBProcessor` | 中药萃取物合并 | `id`, `sample_id`, `bottle_tag`, `bottle_merge_tag`, `process_id`, `start_datetime`, `stop_datetime` |
| `zycwxs` | `ZYCWXSProcessor` | 中药萃取物稀释 | `id`, `sample_id`, `bottle_tag`, `If_concentration`, `process_id`, `start_datetime`, `stop_datetime` |
| `gycwfr` | `GYCWFRProcessor` | 高压萃取物分润/分液 | `id`, `sample_id`, `bottle_tag`, `bottle_merge_tag`, `If_concentration`, `process_id`, `start_datetime`, `stop_datetime` |
| `dgcz` | `DGCZProcessor` | 打管称重 | `id`, `sample_id`, `bottle_tag`, `If_mass`, `process_id`, `sample_storage1-6`, `save_amount1-6`, `start_datetime`, `stop_datetime` |

## 配置

配置通过环境变量读取。程序启动时按以下优先级加载：

```text
env_local.txt -> env_test.txt -> .env
```

生产部署建议使用 `.env` 或容器环境变量，不要把真实密钥提交到代码仓库。

关键配置：

```bash
# MinIO
MINIO_ENDPOINT=172.17.15.122:9000
MINIO_ACCESS_KEY=your_access_key
MINIO_SECRET_KEY=your_secret_key
MINIO_BUCKET=venus

# 业务平台 API
API_BASE_URL=http://172.17.15.123:13000
API_KEY=your_api_token
API_TIMEOUT=30

# 同步源，多个源用英文逗号分隔
SYNC_SOURCES=REALITY/REPORT/lcms/QTOF/qtof_report:sample_new:lcms

# 同步间隔，单位秒
SYNC_INTERVAL=300
LOCAL_DOWNLOAD_DIR=./downloads

# Redis 状态
REDIS_ENABLED=true
REDIS_HOST=172.17.15.125
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=your_redis_password
REDIS_KEY_PREFIX=zy_report_syncer

# QTOF 分析结果
ANALYSIS_OUTPUT_DIR=/data/analysis
REPORT_BASE_URL=http://172.17.15.123:7860/analysis
REPORT_SERVER_PORT=7860
```

多个数据源示例：

```bash
SYNC_SOURCES=REALITY/REPORT/yc/yc_report:sample_new:yc,REALITY/REPORT/lxgl/lxgl_report:sample_new:lxgl,REALITY/REPORT/lcms/QTOF/qtof_report:sample_new:lcms
```

## 使用方法

### 安装依赖

```bash
python3 -m venv venv
venv/bin/python -m pip install -r requirements.txt
```

### 测试 MinIO 连接

```bash
venv/bin/python main.py --test
```

### 手动执行同步

注意：当前 `main.py --sync` 实现是启动循环，每 5 分钟同步一次，不是只执行一轮。

```bash
venv/bin/python main.py --sync
```

### 守护进程模式

```bash
venv/bin/python main.py --daemon
```

### 交互式模式

```bash
venv/bin/python main.py --interactive
```

交互式命令：

| 命令 | 作用 |
|---|---|
| `test` | 测试 MinIO 连接 |
| `list` | 列出 MinIO 文件 |
| `sync` | 执行一次同步 |
| `start` | 启动定时同步 |
| `stop` | 停止定时同步 |
| `status` | 查看同步状态 |
| `quit` | 退出 |

## Docker 接入

构建镜像：

```bash
docker build -t dashboard-refresh:latest .
```

启动容器示例：

```bash
docker run -d --name dashboard-refresh \
  --env-file .env \
  -v /data/analysis:/data/analysis \
  -v /mnt/reports/qtof_raw_file:/mnt/reports/qtof_raw_file:ro \
  -v /mnt/reports/qtof_pdf:/mnt/reports/qtof_pdf:ro \
  --restart always \
  dashboard-refresh:latest
```

如果不启用 QTOF/LCMS 分析，可以不挂载 `/data/analysis`、`/mnt/reports/qtof_raw_file`、`/mnt/reports/qtof_pdf`。普通 CSV 数据源只需要 MinIO、业务平台 API 和 Redis 可访问。

## 接入业务系统

### 1. 业务平台 API 要求

业务平台需要提供以下接口格式：

```text
POST /api/{table_name}:create
POST /api/{table_name}:update?filterByTk={record_id}
GET  /api/{table_name}:list
GET  /api/{table_name}:get
POST /api/{table_name}:delete
```

请求头：

```text
Content-Type: application/json
Authorization: Bearer {API_KEY}
```

刷写到哪个表由 `SYNC_SOURCES` 的第二段决定，例如：

```text
REALITY/REPORT/yc/yc_report:sample_new:yc
```

表示把摇床数据写入 `sample_new` 表。

### 2. 前端看板接入

前端看板不直接访问 MinIO。推荐读取业务平台表，例如 `sample_new`。

前端需要关注的常用字段：

| 字段 | 含义 |
|---|---|
| `id` | 稳定记录 ID，用于更新和详情定位 |
| `sample_id` | 样品名 |
| `process_id` | 批次 ID |
| `bottle_tag` | 瓶/管/孔板等条码 |
| `bottle_merge_tag` | 合并后的目标条码 |
| `If_concentration` | 浓度字段，部分分液/稀释数据使用 |
| `If_mass` | 质量字段，打管称重使用 |
| `zy_report` | 中压制备报告地址 |
| `gy_report` | 高压制备报告地址 |
| `qtof_report` | QTOF PDF 报告地址 |
| `analyse_address` | QTOF HTML 分析报告地址 |
| `sample_storage1-6` | 样本保存条码 |
| `save_amount1-6` | 样本保存量 |
| `start_datetime` | 首次写入时间 |
| `stop_datetime` | 最近更新时间 |

### 3. 刷新语义

服务端每 5 分钟刷新一次业务表。前端可以：

- 直接查询业务平台表，按 `stop_datetime` 排序展示最新数据。
- 使用 `process_id` 筛选批次。
- 使用 `analyse_address` 打开 QTOF 详情报告。

## 新增一个数据源

接入新 CSV 数据源通常需要三步。

### 1. 新增 Processor

在 `data_mapping.py` 中继承 `DataSourceProcessor`，实现：

```python
class MyProcessor(DataSourceProcessor):
    def setup_config(self):
        self.table_name = self._target_table_name
        self.source_prefix = self._target_source_prefix
        self.field_mappings = self.get_field_mappings()
        self.cleaners = self.get_cleaners()
        self.required_fields = []
        self.unique_fields = ['id']

    def get_required_columns(self):
        return ['sample', 'process_id']

    def get_field_mappings(self):
        return {
            'sample_id': 'sample',
            'process_id': 'process_id',
            'id': 'id',
        }

    def get_cleaners(self):
        return {
            'sample_id': StringCleaner(max_length=200),
            'process_id': StringCleaner(max_length=100),
            'id': StringCleaner(max_length=200),
        }

    def clean_data(self, raw_data):
        cleaned_data = super().clean_data(raw_data)
        # 在这里生成 id、时间字段、聚合字段等
        return cleaned_data
```

### 2. 注册 processor_type

在 `data_processor.py` 的 `processor_types` 和 `get_or_create_processor()` 中加入新类型。

### 3. 配置 `SYNC_SOURCES`

```bash
SYNC_SOURCES=REALITY/REPORT/my_report:sample_new:my_processor_type
```

## 状态和重复处理

### 文件级

`SyncStateManager` 使用 Redis 保存文件同步成功状态。Key 中包含 `REDIS_KEY_PREFIX`、`processor_type` 和文件名 hash。文件 ETag 或 size 不变时跳过。

### 行级

不同 Processor 有不同策略：

- `YCProcessor` 按 `sample_id` 聚合。
- `LXGLProcessor` 按 `sample_id` 聚合，并合并 `bottle_tag`。
- `GYZBProcessor` 按 `sample_id + bottle_tag + gy_report` 去重。
- `ZYZBProcessor` 按 `sample_id + zy_report` 聚合。
- `LCMSProcessor` 按 `sample_id + qtof_report` 去重。
- `ZYCWXSProcessor` 按 `sample_id + If_concentration` 聚合。
- `DGCZProcessor` 按 `sample_id` 聚合，额外处理保存条码和累计质量。

### API 级

`APIClient.batch_create_records()` 先调用 create。如果服务端返回重复/冲突错误，会按 `unique_fields` 查询旧记录并调用 update。

## QTOF/LCMS 特殊说明

QTOF 数据源除了写表，还会运行算法生成报告：

1. 从 CSV 中读取样品 `.d`、空白 `.d`、样品 PDF、空白 PDF。
2. 将 UNC 路径翻译为容器挂载路径。
3. 复制到本地临时工作目录。
4. 调用 `RawBlankRemovalAnalyzer` 分析空白干扰和样品峰。
5. 生成 `result.json` 和 `sample_report.html`。
6. 将 HTML 地址写入 `analyse_address`。

QTOF 需要容器能访问：

```text
/mnt/reports/qtof_raw_file
/mnt/reports/qtof_pdf
/data/analysis
```

## 常见问题

### 看板没有新数据

检查：

- `SYNC_SOURCES` 是否包含目标 MinIO 前缀。
- MinIO 中是否能列出 CSV。
- CSV 表头是否满足对应 Processor 的 `get_required_columns()`。
- Redis 中是否已有相同 ETag 成功标记。
- 业务平台 API 是否返回认证或字段错误。
- 日志文件 `sync.log` 中是否有 `error_records`。

### 文件每轮都重复处理

通常是以下原因：

- Redis 不可用或 `REDIS_ENABLED=false`。
- CSV 处理有错误，代码不会保存成功 ETag。
- CSV 没有有效处理行，代码不会保存成功 ETag。

### create 成功但 update 失败

检查目标表唯一字段和 Processor 的 `unique_fields` 是否一致。多数看板数据使用 `id`，旧摇床/化学家数据使用 `shake_flask_id`，GFSY 使用 `nsp_id`。

### 新 CSV 表头不一致

修改对应 Processor 的 `get_required_columns()` 和 `get_field_mappings()`。不要只改配置；字段映射由代码决定。

