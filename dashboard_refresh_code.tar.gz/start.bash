#!/bin/bash
# 启动 zy_qtof_2 同步服务容器
set -euo pipefail

IMAGE="zy_syncer:v0.3"
CONTAINER="zhongyao_v2"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd "${SCRIPT_DIR}"

if [ "${SKIP_BUILD:-0}" != "1" ]; then
    echo "构建镜像: ${IMAGE}"
    docker build -t "${IMAGE}" .
else
    echo "跳过镜像构建: ${IMAGE}"
fi

# 如果同名容器已存在，先停掉并删除
if docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER}$"; then
    echo "停止并删除已有容器: ${CONTAINER}"
    docker stop "${CONTAINER}" 2>/dev/null
    docker rm "${CONTAINER}" 2>/dev/null
fi

echo "启动容器: ${CONTAINER}"
docker run -d --name "${CONTAINER}" \
  -p 18080:18080 \
  -v /data/analysis:/data/analysis \
  -v /mnt/reports/qtof_raw_file:/mnt/reports/qtof_raw_file:ro \
  -v /mnt/reports/qtof_pdf:/mnt/reports/qtof_pdf:ro \
  -e REPORT_BASE_URL="${REPORT_BASE_URL:-http://172.17.15.123:18080/analysis}" \
  -e REPORT_SERVER_PORT="${REPORT_SERVER_PORT:-18080}" \
  --restart always \
  "${IMAGE}"

echo "回写已有 LCMS HTML 报告链接到前端表..."
docker exec "${CONTAINER}" \
  python repair_lcms_analyse_address.py \
  --base-url "${REPORT_BASE_URL:-http://172.17.15.123:18080/analysis}"

echo "容器状态:"
docker ps --filter "name=${CONTAINER}"
