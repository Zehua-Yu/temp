import time
import schedule
import threading
from datetime import datetime
from loguru import logger
from file_sync import FileSyncService
from config import Config


class SyncScheduler:
    """同步调度器类"""
    
    def __init__(self):
        """初始化调度器"""
        self.sync_service = FileSyncService()
        self.is_running = False
        self.scheduler_thread = None
    
    def start_scheduler(self):
        """启动调度器"""
        if self.is_running:
            logger.warning("调度器已经在运行中")
            return
        
        # 设置定时任务
        schedule.every(Config.SYNC_INTERVAL).seconds.do(self._sync_job)
        
        # 启动时立即执行一次同步
        logger.info("启动同步调度器，立即执行一次同步")
        self._sync_job()
        
        # 启动调度器线程
        self.is_running = True
        self.scheduler_thread = threading.Thread(target=self._run_scheduler, daemon=True)
        self.scheduler_thread.start()
        
        logger.info(f"同步调度器已启动，同步间隔: {Config.SYNC_INTERVAL} 秒")
    
    def stop_scheduler(self):
        """停止调度器"""
        if not self.is_running:
            logger.warning("调度器未在运行")
            return
        
        self.is_running = False
        schedule.clear()
        logger.info("同步调度器已停止")
    
    def _run_scheduler(self):
        """运行调度器主循环"""
        while self.is_running:
            schedule.run_pending()
            time.sleep(1)
    
    def _sync_job(self):
        """同步任务"""
        try:
            logger.info(f"开始执行定时同步任务 - {datetime.now()}")
            stats = self.sync_service.sync_files()
            logger.info(f"定时同步任务完成 - {stats}")
        except Exception as e:
            logger.error(f"定时同步任务执行失败: {e}")
    
    def run_once(self):
        """手动执行一次同步"""
        logger.info("手动执行同步任务")
        return self.sync_service.sync_files()
    
    def get_status(self):
        """获取调度器状态"""
        return {
            'is_running': self.is_running,
            'sync_interval': Config.SYNC_INTERVAL,
            'next_sync': schedule.next_run(),
            'sync_status': self.sync_service.get_sync_status()
        } 